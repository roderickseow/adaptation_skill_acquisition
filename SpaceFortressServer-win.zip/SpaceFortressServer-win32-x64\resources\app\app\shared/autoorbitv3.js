function mean(lst) {
    var m = 0;
    for (var i=0; i<lst.length;i++) m += lst[i];
    return m / lst.length;
}

function std(lst) {
    var i;
    var m = 0;
    for (i=0; i<lst.length;i++) m += lst[i];
    m = m / lst.length;

    console.log(m);

    if (lst.length > 1) {
        var s = 0;
        for (i=0; i<lst.length;i++) {
            s += Math.pow(lst[i]-m, 2);
        }
        s = Math.sqrt(s / (lst.length-1));
        return s;
    } else if (lst.length > 0) {
        return 0;
    } else {
        return "no";
    }
}


(function (exports) {

var util = typeof require === 'undefined' ? window.util:require('./util');
var flappyTranslate = typeof require === 'undefined' ? window.flappyTranslate:require('./flappyTranslate');
var FlappyTranslate = flappyTranslate.FlappyTranslate;
var V = util.V;
var Vector = util.Vector;
var std_360 = util.std_360;
var cartesian_360 = util.cartesian_360;
var angle_to = util.angle_to;
var angle_diff = util.angle_diff;
var dotProduct = util.dotProduct;
var distance = util.distance;
var mod = util.mod;
var deg2rad = util.deg2rad;
var rad2deg = util.rad2deg;


// FIXME: this should be somewhere else.
function getCurrentTime() {
    var d = new Date;
    return d.getTime();
}

var COLLIDE_FORTRESS = 'fortress';
var COLLIDE_SHIP = 'shell';
var COLLIDE_BIGHEX = 'big-hex';
var COLLIDE_SMALLHEX = 'small-hex';
var COLLIDE_RECTANGLE = 5;

var TURN_CODES = util.TURN_CODES;

var KEY_CODES = ['thrust',
                 'left',
                 'right',
                 'fire'];

function keycode2name(ev) {
    if (ev.which == 76) {
        return 'fire';
    } else if (ev.which == 65) {
        return 'left';
    } else if (ev.which == 68) { // 69) {
        return 'right';
    } else if (ev.which == 87) { // 188) {
        return 'thrust';
    // } else if (ev.which == 81) {
    //     return 'quit';
    } else if (ev.which == 27) {
        return 'quit';
    } else {
        return null;
    }
}

function Rect (x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;

    return this;
}

Rect.prototype = {};

function Timer(time) {
    Object.call(this);
    this.ticks = 0;
    this.time = time || 0;
    this.last_tick = 0;
    return this;
}

Timer.prototype = {};

Timer.prototype.tick = function (ms) {
    this.time += ms;
    this.last_tick = ms;
    this.ticks += 1;
};

Timer.prototype.reset = function () {
    this.time = 0;
    this.ticks = 0;
};

Timer.prototype.elapsed = function () {
    return Math.floor(this.time);
};

Timer.prototype.elapsedTicks = function () {
    return this.ticks;
};

Timer.prototype.subtract = function (ms) {
    this.time -= ms;
};

function KeyState() {
    Object.call(this);

    this.events = [];
    this.keys = {'left': false,
                 'right': false,
                 'thrust': false,
                 'fire': false};
    return this;
}

KeyState.prototype = {};

KeyState.prototype.press = function (which) {
    // ignore repeat events
    if (!this.keys[which]) this.events.push({'type': 1, 'key': which});
    this.keys[which] = true;
};

KeyState.prototype.release = function (which) {
    this.keys[which] = false;
    this.events.push({'type': 0, 'key': which});
};

KeyState.prototype.clear = function () {
    this.events = [];
};

function Wireframe(points, runs, color) {
    Object.call(this);
    this.points = points;
    this.runs = runs;
    this.color = color;
    return this;
}

Wireframe.prototype = {};

// Wireframe.prototype.rotate_translate = function (pair, x, y, angle) {
//     return [ pair[0] * Math.cos(angle) - pair[1] * Math.sin(angle) + x,
//             -pair[1] * Math.sin(angle) + pair[1] * Math.cos(angle) + y];
// }

// Wireframe.prototype.translate_run = function (run, x, y, angle) {
//     var i, new_run = [];
//     for (i=0; i<run.length; i++) {
//         new_run[i] = this.rotate_translate(run[i][0]);
//     }
// };

Wireframe.prototype.draw = function (canvas, x, y, angle) {
    this.drawWithColor(canvas, x, y, angle, this.color);
};

Wireframe.prototype.drawWithColor = function (canvas, x, y, angle, color) {
    var r, i;
    canvas.save();
    canvas.strokeStyle = color;
    canvas.translate(x,y);
    canvas.scale(1,-1);
    canvas.rotate(deg2rad(angle));
    for (r=0; r<this.runs.length; r++) {
        canvas.beginPath();
        canvas.moveTo(this.points[this.runs[r][0]][0], this.points[this.runs[r][0]][1]);
        for (i=1; i<this.runs[r].length; i++) {
            canvas.lineTo(this.points[this.runs[r][i]][0], this.points[this.runs[r][i]][1]);
        }
        canvas.stroke();
    }
    canvas.restore();
};


var missileWireframe = new Wireframe([[0, 0], [-25, 0], [-5, 5], [-5, -5]],
                                     [[0,1], [0, 2], [0, 3]],
                                    '#FFFFFF');
var shellWireframe = new Wireframe([[-8, 0], [0, -6], [16, 0], [0, 6], [-8, 0]],
                                   [[0,1,2,3,0]],
                                   '#FF0000');
var shipWireframe = new Wireframe([[-18,0], [18,0], [0,0], [-18,18], [-18,-18]],
                                  [[0,1], [3, 2, 4]],
                                  '#FFFF00');
var shipFastWireframe = new Wireframe([[-18,0], [18,0], [0,0], [-18,18], [-18,-18], [-14,18], [-14,-18], [4,0], [-22,18], [-22,-18], [-4,0]],
                                      [[0,1], [3, 2, 4], [5,7,6], [8,10,9]],
                                      '#FF0000');

var shipMedWireframe = new Wireframe([[-18,0], [18,0], [0,0], [-18,18], [-18,-18], [-14,18], [-14,-18], [4,0], [-22,18], [-22,-18], [-4,0]],
                                     [[0,1], [3, 2, 4],  [8,10,9]],
                                     '#00FFFF');


var fortressWireframe = new Wireframe([[0, 0], [36, 0], [18, -18], [0,-18], [18,18], [0,18]],
                                      [[0, 1], [3,2,4,5]],
                                     '#FFFF00');

function Entity() {
    Object.call(this);

    this.position = V(0,0);
    this.velocity = V(0,0);
    this.angle = 0;
    this.collision_radius = 0;
    this.alive = true;

    return this;
}

Entity.prototype = {};

function collided(e1, e2) {
    var d = distance(e1.position, e2.position);
    return d <= e1.collision_radius + e2.collision_radius;
}

function outside_game_area(e) {
    return e.position.x < 0 || e.position.x > 710 || e.position.y < 0 || e.position.y > 626;
}

function drawExplosion(canvas, x, y, frame) {
    if (frame >= 0 && frame < 10) {
        var img = g_images['explosion-animation'];
        canvas.save();
        canvas.translate(x,y);
        canvas.scale(1,-1);
        canvas.drawImage(img, frame * 96, 0, 96, 96,
                         -96/2,-96/2,96,96);
        canvas.restore();
    }
}

function drawWireframeExplosion(canvas, x, y) {
    var ofs = 0;
    var radius;
    for (radius=15; radius<70; radius+=8) {
        var angle;
        ofs += 3;
        if (radius < 60) { canvas.strokeStyle = '#FFFF00'; }
        else { canvas.strokeStyle = '#FF0000'; }
        for (angle=0; angle<360; angle += 30) {
            canvas.beginPath();
            canvas.arc(x, y, radius, deg2rad(angle+ofs),deg2rad(angle+ofs+10),false);
            canvas.stroke();
        }
    }
    canvas.strokeStyle = '#FFFF00';
    canvas.beginPath();
    canvas.arc(x, y, 7, 0, Math.PI*2, false);
    canvas.stroke();
}

function Ship(config) {
    Entity.call(this);
    this.startAngle = config.ship.startAngle;
    this.angle = this.startAngle;
    this.startVelocity = V(config.ship.startVelocity.x, config.ship.startVelocity.y);
    this.startPosition = V(config.ship.startPosition.x, config.ship.startPosition.y);
    this.turn_speed = config.ship.turnSpeed;
    this.acceleration = config.ship.acceleration;
    this.collision_radius = config.ship.collisionRadius;
    this.color = config.ship.color;

    this.position.copy(this.startPosition);
    this.velocity.copy(this.startVelocity);
    this.turn_flag = null;
    this.thrust_flag = false;
    this.deathTimer = new Timer();
    this.causeOfDeath = null;

    this.noFirePenaltyTimer = new Timer();
    this.lastMissileTimer = new Timer();
    this.ignoreMissilesTimer = new Timer();
    this.lastMissileIgnoreMissiles = false;

    return this;
}

Ship.prototype = new Entity();

Ship.prototype.reset = function () {
    this.alive = true;
    this.position.copy(this.startPosition);
    this.velocity.copy(this.startVelocity);
    this.angle = this.startAngle;
    this.turn_flag = null;
    this.thrust_flag = false;
};

Ship.prototype.draw = function (canvas) {
    if (this.alive) {
        shipWireframe.drawWithColor(canvas, this.position.x, this.position.y, this.angle, this.color);

        // if (this.thrust_flag)
        //     draw_image(canvas, 'ship-thrust', this.position.x, this.position.y, this.angle);
        // else
        //     draw_image(canvas, 'ship', this.position.x, this.position.y, this.angle);
    } else {
        var frame = Math.floor(this.deathTimer.ticks / 3);
        drawWireframeExplosion(canvas, this.position.x, this.position.y, frame);
    }
};

function Fortress(config) {
    Entity.call(this);
    this.collision_radius = config.fortress.collisionRadius;
    this.sector_size = config.fortress.sectorSize;
    this.lockTime = config.fortress.lockTime;
    this.position.x = 355;
    this.position.y = 315;
    this.angle = 180;

    this.timer = new Timer();
    this.vulnerabilityTimer = new Timer(config.fortress.vlnerTime);
    this.deathTimer = new Timer();

    this.defaultColor = '#FFFF00';
    this.color = this.defaultColor;

    return this;
}

function draw_image(canvas, img, x, y, angle) {
    canvas.save();
    canvas.translate(x,y);
    canvas.scale(1,-1);
    canvas.rotate(deg2rad(angle+90));
    canvas.drawImage(g_images[img], -g_images[img].width/2, -g_images[img].height/2);
    canvas.restore();
}

Fortress.prototype = new Entity();

Fortress.prototype.draw = function (canvas, vlner, strokeColor, fillColor) {
    if (this.alive) {

        var amt = vlner / 10 * this.collision_radius;
        if (amt > this.collision_radius) amt = this.collision_radius;
        // var amt = this.collision_radius - vlner / 10 * this.collision_radius;
        // if (amt < 0) amt = 0;
        canvas.beginPath();
        canvas.arc(this.position.x, this.position.y, amt, 0, Math.PI*2, false);
        // if (vlner >= 10)
        //     canvas.fillStyle = '#CCCCCC';
        // else
        canvas.fillStyle = fillColor;
        canvas.fill();

        canvas.beginPath();
        canvas.arc(this.position.x, this.position.y, this.collision_radius, 0, Math.PI*2, false);
        // if (vlner < 10)
        canvas.strokeStyle = strokeColor;
        // else canvas.strokeStyle = fillColor;
        canvas.stroke();


    } else {
        var frame = Math.floor(this.deathTimer.ticks / 3);
        drawWireframeExplosion(canvas, this.position.x, this.position.y, frame);
    }
};

function Missile(config, x, y, angle) {
    Entity.call(this);

    this.collision_radius = config.missiles.collisionRadius;
    this.speed = config.missiles.speed;

    this.startPosition = V(x,y);
    this.position.x = x;
    this.position.y = y;
    this.angle = angle;
    this.velocity.x = this.speed * Math.cos(deg2rad(angle));
    this.velocity.y = -this.speed * Math.sin(deg2rad(angle));
    return this;
}

Missile.prototype = new Entity();

Missile.prototype.draw = function (canvas) {
    // draw_image(canvas, 'missile', this.position.x, this.position.y, this.angle);
    missileWireframe.draw(canvas, this.position.x, this.position.y, this.angle);
};


function Shell(config, x, y, angle) {
    Entity.call(this);

    this.collision_radius = config.shells.collisionRadius;
    this.speed = config.shells.speed;
    this.acceleration = 0.1;

    this.position.x = x;
    this.position.y = y;
    this.angle = angle;
    this.velocity.x = this.speed * Math.cos(deg2rad(angle));
    this.velocity.y = -this.speed * Math.sin(deg2rad(angle));
    return this;
}

Shell.prototype = new Entity();

Shell.prototype.draw = function (canvas) {
    // draw_image(canvas, 'shell', this.position.x, this.position.y, this.angle);
    shellWireframe.draw(canvas, this.position.x, this.position.y, this.angle);
};

function Hexagon (radius) {
    Object.call(this);
    var x1 = Math.floor(355-radius);
    var x2 = Math.floor(355-radius*0.5);
    var x3 = Math.floor(355+radius*0.5);
    var x4 = Math.floor(355+radius);
    var y1 = 315;
    var y2 = Math.floor(315-radius*Math.sin(Math.PI*2/3));
    var y3 = Math.floor(315+radius*Math.sin(Math.PI*2/3));
    this.points = [V(x1,y1),
                   V(x2,y2),
                   V(x3,y2),
                   V(x4,y1),
                   V(x3,y3),
                   V(x2,y3),
                   V(x1,y1)];
    this.radius = radius;
    return this;
}

Hexagon.prototype = {};

Hexagon.prototype.inside = function (v) {
    var i;
    for (i=0; i<this.points.length-1; i++) {
        var nx, ny, dx, dy;
        nx = -(this.points[i+1].y - this.points[i].y);
        ny =   this.points[i+1].x - this.points[i].x;
        dx = v.x - this.points[i].x;
        dy = v.y - this.points[i].y;
        if (nx * dx + ny * dy < 0) {
            return false;
        }
    }
    return true;
};

Hexagon.prototype.draw = function (canvas) {
    var i;
    canvas.beginPath();
    canvas.strokeStyle = '#00FF00';
    canvas.moveTo(this.points[0].x, this.points[0].y);
    for (i=1; i<this.points.length; i++) {
        canvas.lineTo(this.points[i].x, this.points[i].y);
    }
    canvas.closePath();
    canvas.stroke();
};

function Game(exp, config, gnum) {
    Object.call(this);

    this.exp = exp;

    this.screen_id = 'game';
    this.originalConfig = config;
    this.config = JSON.parse(JSON.stringify(this.originalConfig));

    Game.prototype.applySpeedMultiplier.call(this);

    this.game_number = gnum;

    Game.prototype.init_basic_game_state.call(this);

    this.ship = new Ship(config);
    this.fortress = new Fortress(config);

    this.target = -1;
    this.targetTimer = new Timer();

    this.randomRotation = {};
    this.randomRotation.enabled = false;
    this.randomRotation.delayTimer = new Timer();
    this.randomRotation.delayDuration = 0;

    return this;
}

Game.prototype = {};

Game.prototype.applySpeedMultiplier = function () {
    // Alter certain config values to speed up or slowing down the game.
    var m = this.config.speedMultiplier;

    this.config.orbit.speed = this.originalConfig.orbit.speed * m;
    this.config.missiles.speed = this.originalConfig.missiles.speed * m;
    this.config.orbit.noFireBleedRate = this.originalConfig.orbit.noFireBleedRate * m;

    this.config.orbit.noFirePenaltyThreshold = this.originalConfig.orbit.noFirePenaltyThreshold / m;
    this.config.orbit.distractionBuffer = this.originalConfig.orbit.distractionBuffer / m;

    this.config.fortress.vlnerTime = this.originalConfig.fortress.vlnerTime / m;
    this.config.fortress.explodeDuration = this.originalConfig.fortress.explodeDuration / m;
};

Game.prototype.init_basic_game_state = function () {
    this.collisions = [];
    this.score = {};
    this.score.pnts = 0;
    this.score.raw_pnts = 0;
    this.score.vulnerability = 0;
    this.score.background_highlight = 0;
    this.shells = [];
    this.missiles = [];

    this.keyState = new KeyState();

    this.gameTimer = new Timer();
    this.currentTick = 0;

    this.currentFrameEvents = [];

    this.shipDeaths = 0;

    this.floatingPoints = [];
};

Game.prototype.initCanvas = function (canvas, images) {
    this.canvas = canvas.getContext('2d');
    this.flappyImages = images;
    if (this.config.flappy) {
        this.createFlappyBackground();
    }
}

Game.prototype.getHeaderData = function () {
    // Record game specific data
    return {'type': this.config.game_type,
            'version': 1,
            'bighex': this.bighex.radius,
            'smallhex': this.smallhex.radius,
            'config': this.config,
            // From webgame.js
            'log': ['clock', 'ship_x', 'ship_y', 'ship_angle',
                    'fortress_alive', 'missiles', 'points', 'vulnerability', 'events'],
            'missile_log': ['x', 'y', 'angle']
           };
}

Game.prototype.coreInit = function () {
    if (!this.config.staircase.enabled || !this.exp.bigHex || !this.exp.smallHex) {
        this.exp.bigHex = this.config.bigHex;
        this.exp.smallHex = this.config.smallHex;
    }
    this.bighex = new Hexagon(this.exp.bigHex);
    this.smallhex = new Hexagon(this.exp.smallHex);

    if (this.config.flappy) {
        this.flappyTranslate = new FlappyTranslate();
        this.flappyTranslate.update(this);
    }

    // this.canvas.lineWidth = 1.4;
    this.now = null;
    this.last_tick_time = null;
    this.time_debt = 0;
    this.tinc = 0;

    this.exp.resetGameData(this.game_number);

    var header = this.getHeaderData();
    header.gnum = this.game_number;

    this.exp.gameLogHeader(header);
    this.recordEverything();
};

Game.prototype.addGUI = function () {
    this.gui = new dat.GUI();

    var c = this.gui.add(this.config, 'speedMultiplier', 0.0, 3.0).step(0.01);

    this.gui.add(this.config.orbit, 'speed');
    this.gui.add(this.config.orbit, 'noFirePenaltyThreshold');
    this.gui.add(this.config.fortress, 'vlnerTime');

    this.gui.add(this.config.orbit, 'rotationProbabilityNumerator');
    this.gui.add(this.config.orbit, 'rotationProbabilityDenominator');
    this.gui.add(this.config.orbit, 'rotationDelayMinDuration');
    this.gui.add(this.config.orbit, 'rotationDelayMaxDuration');

    this.gui.addColor(this.config.fortress, 'borderColor');
    this.gui.addColor(this.config.fortress, 'ballColor');
    this.gui.addColor(this.config, 'hexColor');

    var _this = this;
    c.onChange(function (value) {
        _this.applySpeedMultiplier();
        _this.gui.updateDisplay();
    });




    // this.gui.add(this.config, 'game_type');
    // this.gui.add(this.config, 'screen_width');
    // this.gui.add(this.config, 'screen_height');
    // this.gui.add(this.config, 'game_time');
    // this.gui.add(this.config, 'auto_turn');

    // var orbit = this.gui.addFolder('Orbit');
    // orbit.open();
    // orbit.add(this.config.orbit, 'enabled');
    // orbit.add(this.config.orbit, 'discreteTurning');
    // orbit.add(this.config.orbit, 'radius');
    // orbit.add(this.config.orbit, 'speed');
    // orbit.add(this.config.orbit, 'noFirePenaltyThreshold');
    // // orbit.add(this.config.orbit, 'noFireShellThreshold');
    // // orbit.add(this.config.orbit, 'noFirePenalty');
    // // orbit.add(this.config.orbit, 'noFirePenaltyTicks');

    // orbit.add(this.config.orbit, 'noFireBleedRate');


    // // orbit.add(this.config.orbit, 'distractionDuration');
    // // orbit.add(this.config.orbit, 'distractionRange');
    // orbit.add(this.config.orbit, 'distractionBuffer');
    // orbit.add(this.config.orbit, 'minRotation');
    // orbit.add(this.config.orbit, 'maxRotation');
    // // orbit.add(this.config.orbit, 'pulsePoints');
    // // orbit.add(this.config.orbit, 'pulsePointsLabel');
    // // orbit.add(this.config.orbit, 'floatPoints');
    // // orbit.add(this.config.orbit, 'floatPointsTicks');
    // orbit.add(this.config.orbit, 'scoreY');
    // orbit.add(this.config.orbit, 'scoreMode', ['follow', 'below']);

    // // orbit.add(this.config.orbit, 'targetType', ['balloon', 'red']);

    // // orbit.add(this.config.orbit, 'noFireChangeColor');
    // // orbit.add(this.config.orbit, 'noFireColor');

    // // orbit.add(this.config.orbit, 'distractionBonus');
    // // orbit.add(this.config.orbit, 'distractionOffDuration');
    // // orbit.add(this.config.orbit, 'distractionOnDuration');

    // var points = this.gui.addFolder('Points');
    // points.add(this.config, 'destroy_fortress');
    // points.add(this.config, 'ship_death_penalty');
    // points.add(this.config, 'missile_penalty');
    // points.add(this.config, 'max_points');
    // points.add(this.config, 'max_bonus');

    // var fortress = this.gui.addFolder('Fortress');

    // fortress.add(this.config.fortress, 'sectorSize');
    // fortress.add(this.config.fortress, 'lockTime');
    // fortress.add(this.config.fortress, 'vlnerTime');
    // fortress.add(this.config.fortress, 'vlnerThreshold');
    // var _this = this, collision = fortress.add(this.config.fortress, 'collisionRadius');
    // collision.onFinishChange(function (value) {
    //     _this.fortress.collision_radius = value;
    // });
    // fortress.add(this.config.fortress, 'explodeDuration');

    // var hex = this.gui.addFolder('Hexagons');

    // hex.add(this.config, 'bigHex');
    // hex.add(this.config, 'smallHex');

    // var ship = this.gui.addFolder('Ship');
    // ship.add(this.config.ship, 'turnSpeed');
    // ship.add(this.config.ship, 'acceleration');
    // ship.add(this.config.ship, 'collisionRadius');
    // ship.add(this.config.ship, 'explodeDuration');
    // ship.add(this.config.ship, 'startAngle');
    // var pos = ship.addFolder('StartPosition');
    // pos.add(this.config.ship.startPosition, 'x');
    // pos.add(this.config.ship.startPosition, 'y');
    // var vel = ship.addFolder('StartVelocity');
    // vel.add(this.config.ship.startVelocity, 'x');
    // vel.add(this.config.ship.startVelocity, 'y');

    // var shell = this.gui.addFolder('Shells');
    // shell.add(this.config.shells, 'speed');
    // shell.add(this.config.shells, 'collisionRadius');

    // var missiles = this.gui.addFolder('Missiles');
    // missiles.add(this.config.missiles, 'speed');
    // missiles.add(this.config.missiles, 'collisionRadius');

    // var staircase = this.gui.addFolder('Staircase');
    // staircase.add(this.config.staircase, 'enabled');
    // staircase.add(this.config.staircase, 'hexContraction');
    // staircase.add(this.config.staircase, 'hexExpansion');
    // staircase.add(this.config.staircase, 'minHexDistance');

    // var nav = this.gui.addFolder('Navigation');
    // // nav.add(this.config.nav, 'staircase');
    // // nav.add(this.config.nav, 'staircase_delta');
    // // nav.add(this.config.nav, 'staircase_decrease_threshold');
    // // nav.add(this.config.nav, 'staircase_increase_threshold');
    // nav.add(this.config.nav, 'rect_width');
    // nav.add(this.config.nav, 'enter_rectangle');
    // nav.add(this.config.nav, 'min_angle');
    // nav.add(this.config.nav, 'max_angle');
    // nav.add(this.config.nav, 'min_rect_width');

    // var flappy = this.gui.addFolder('Flappy');
    // flappy.add(this.config, 'flappy');
    // flappy.add(this.config, 'flappy_nest');
    // flappy.add(this.config, 'flappy_eggs');
};

Game.prototype.init = function () {
    $("#experiment_area").html('<canvas id="screen-canvas" width="710px" height="600px"></canvas>'+
                               '<div id="abandon" style="display:none"><div style="position: relative; top: -350px; text-align:center; background-color: rgb(230,240,255); border: 5px solid red; font-family: sans-serif; width: 400px; margin-left: auto; margin-right:auto"><div syle=""><p>When you are ready to return to the game, click the button to restart from the beginning.<p><button id="restart">Ready To Restart</div></div></div>');

    $('#restart').on('click', $.proxy(this.reset_after_abandoned, this));

    // this.addGUI();

    this.initCanvas (document.getElementById('screen-canvas'), g_images);

    // this.fireMissileSound = sounds['fire-missile'];
    // this.fireShellSound = sounds['fire-shell'];
    // if (this.config.flappy) this.vlnerResetSound = sounds['clear-eggs'];
    // else this.vlnerResetSound = sounds['vlner-reset'];
    // this.explosionSound = sounds['explosion'];
    // this.lightningSound = sounds['lightning'];
    // this.eggPlacedSound = sounds['egg-placed'];
    // this.shipDestroyedSound = sounds['ship-destroyed'];
    // this.fortressDestroyedSound = sounds['fortress-destroyed'];
    // this.deflateSound = sounds['deflate2'];

    this.request_redraw();
    this.addEventListeners();

    this.coreInit();
};

Game.prototype.addEventListeners = function () {
    $(document).on('keydown', $.proxy(this.keydown_event, this));
    $(document).on('keyup', $.proxy(this.keyup_event, this));
};

Game.prototype.clearEvents = function () {
    $(document).off('keydown', $.proxy(this.keydown_event));
    $(document).off('keyup', $.proxy(this.keyup_event));
};

Game.prototype.play = function (x) {
    // if (typeof x !== 'undefined') x.play();
};

Game.prototype.keydown_event = function(ev) {
    var sym = keycode2name(ev);
    if (sym == 'quit' && isDebugMode()) {
        ev.preventDefault();
        this.cancel_redraw();
        this.clearEvents();
    } else if (sym !== null) {
        this.keyState.press(sym);
        ev.preventDefault();
    }
    exp.lg('keydown', {which: ev.which, r: ev.originalEvent.repeat ? 1:undefined});
};

Game.prototype.keyup_event = function (ev) {
    var sym = keycode2name(ev);
    if (sym !== null) {
        this.keyState.release(sym);
        ev.preventDefault();
    }
    exp.lg('keyup', {which: ev.which});
};

Game.prototype.getKeyState = function () {
    var keys = [];
    for (i=0; i<KEY_CODES.length; i++) {
        if (this.keyState.keys[KEY_CODES[i]]) keys.push(KEY_CODES[i]);
    }
    return keys;
}

Game.prototype.getWorldState = function (override) {
    var ret;
    var fmt = 'sf';
    if (override && override !== 'native') {
        fmt = override;
    }
    if (fmt === 'json') {
        ret = this.getWorldStateForJSON();
    } else {
        ret = this.getWorldStateForNormal();
    }
    return ret;
}

Game.prototype.getWorldStateForJSON = function () {
    var missiles = [], shells = [];
    var i;

    for (i=0; i<this.missiles.length; i++) {
        missiles.push([parseFloat(this.missiles[i].position.x.toFixed(3)), parseFloat(this.missiles[i].position.y.toFixed(3)), Math.round(this.missiles[i].angle)
                      ]);
    }

    for (i=0; i<this.shells.length; i++) {
        shells.push([parseFloat(this.shells[i].position.x.toFixed(3)), parseFloat(this.shells[i].position.y.toFixed()), Math.floor(this.shells[i].angle)
                    ]);
    }

    var line = [this.gameTimer.elapsed(),
                // ship
                // this.ship.alive?1:0,
                // We want 3 decimals of precision
                parseFloat(this.ship.position.x.toFixed(3)),
                parseFloat(this.ship.position.y.toFixed(3)),
                // Math.round(this.ship.velocity.x * 1000),
                // Math.round(this.ship.velocity.y * 1000),
                Math.floor(this.ship.angle),
                // fortress
                this.fortress.alive?1:0,
                // Math.floor(this.fortress.angle),
                missiles,
                // shells,
                this.score.pnts,
                parseFloat(this.score.vulnerability.toFixed(1)),
                // this.ship.thrust_flag?1:0,
                // game.TURN_CODES.indexOf(this.ship.turn_flag)
                // this.keyState.keys['thrust']?1:0,
                // this.keyState.keys['left']?1:0,
                // this.keyState.keys['right']?1:0,
                // this.keyState.keys['fire']?1:0,
               ];

    line.push(this.currentFrameEvents);

    return line;
};

Game.prototype.getWorldStateForNormal = function () {
    var missiles = [], shells = [];
    var i;

    for (i=0; i<this.missiles.length; i++) {
        missiles.push({x: this.missiles[i].position.x,
                       y: this.missiles[i].position.y,
                       vx: this.missiles[i].velocity.x,
                       vy: this.missiles[i].velocity.y,
                       orientation: this.missiles[i].angle});
    }

    for (i=0; i<this.shells.length; i++) {
        shells.push({x: this.shells[i].position.x,
                     y: this.shells[i].position.y,
                     vx: this.shells[i].velocity.x,
                     vy: this.shells[i].velocity.y,
                     orientation: this.shells[i].angle});
    }

    var line = {'time': this.gameTimer.elapsed(),
                // ship
                'ship': {'alive': this.ship.alive,
                         'x': this.ship.position.x,
                         'y': this.ship.position.y,
                         'vx': this.ship.velocity.x,
                         'vy': this.ship.velocity.y,
                         'orientation': this.ship.angle},
                'fortress': {'alive': this.fortress.alive,
                             'x': this.fortress.position.x,
                             'y': this.fortress.position.y,
                             'orientation': this.fortress.angle},
                'bighex': this.bighex.radius,
                'smallhex': this.smallhex.radius,
                'missiles': missiles,
                'shells': shells,
                'rawpnts': this.score.raw_pnts,
                'pnts': this.score.pnts,
                'vlner': parseFloat(this.score.vulnerability.toFixed(1)),
                'keys': this.getKeyState(),
                'events': this.currentFrameEvents};

    return line;
};

Game.prototype.getWorldStateForModel = function (next_clock) {
    if (this.config.flappy) return this.flappyTranslate.getWorldStateForModel(this, next_clock);
    else                    return this.getWorldStateForModelNormal(next_clock);
};

Game.prototype.commonFixWorldStateForModel = function (state) {
    // Turn them into symbols
    for (let i=0; i<state['keys'].length; i++) {
        state['keys'][i] = ':' + state['keys'][i];
    }
    state['collisions'] = Array(this.collisions.length);
    for (let i=0; i<this.collisions.length; i++) {
        state['collisions'][i] = ':' + this.collisions[i];
    }

    state['screen-type'] = 'game';
    state['mode'] = 'events';
};

Game.prototype.getWorldStateForModelNormal = function (next_clock) {
    var state = this.getWorldState();

    this.commonFixWorldStateForModel(state);

    for (let i=0; i<this.missiles.length; i++) {
        state['missiles'][i].vx = this.missiles[i].velocity.x;
        state['missiles'][i].vy = this.missiles[i].velocity.y;
    }
    for (let i=0; i<this.shells.length; i++) {
        state['shells'][i].vx = this.shells[i].velocity.x;
        state['shells'][i].vy = this.shells[i].velocity.y;
    }

    var diff = this.ship.angle - angle_to(this.ship.position, this.fortress.position);
    if (diff > 180) diff -= 360;
    if (diff < -180) diff += 360;
    state['ship']['angle'] = diff;
    state['ship']['distance-from-fortress'] = distance(this.ship.position, this.fortress.position);
    state['ship']['vdir'] = angle_diff(this.ship.velocity.angle(),
                                       angle_to(this.ship.position, this.fortress.position));
    state['ship']['speed'] = this.ship.velocity.norm();
    state['active'] = true;
    state['isomorph'] = null;
    state['current-time'] = state['time'];
    state['time'] = next_clock;
    // backwards compatibility
    delete state['events'];
    state['mine'] = null;
    state['bonus'] = null;
    state['game'] = 'fortress';
    state['iff'] = null;
    state['cntrl'] = 0;
    state['speed'] = 0;
    state['shots'] = Infinity;
    state['intrvl'] = [];
    state['vlcty'] = 0;
    state['crew'] = 0;
    return state;
};

Game.prototype.recordEverything = function () {
    // this.exp.lg(undefined, {s: this.getWorldState(this.logFormat)});
    this.exp.gameLog(this.getWorldState(this.logFormat));
};

Game.prototype.recordMinimal = function () {
    this.recordFrameEvents();
    if (this.exp.gameKeyLog[this.exp.gameKeyLog.length-1][0] == this.currentTick) {
        this.recordWorldState(true);
    }
};

Game.prototype.addEvent = function (tag, extra) {
    // console.log(tag, extra);
    if (extra) {
        this.currentFrameEvents.push([tag, extra]);
    } else {
        this.currentFrameEvents.push(tag);
    }
};

Game.prototype.addFloatingPoints = function (amt) {
    if (this.config.orbit.floatPoints)
        this.floatingPoints.push({tick: 0,
                                  x: this.ship.position.x,
                                  y: this.ship.position.y-20,
                                  value: amt});
};

Game.prototype.penalize = function (amt) {
    this.addFloatingPoints(amt*-1);
    this.score.raw_pnts -= amt;
    if (this.score.pnts > 0) this.score.background_highlight = 1.0;
    this.score.pnts -= amt;
    if (this.score.pnts < 0) this.score.pnts = 0;
};

Game.prototype.reward = function (amt) {
    this.addFloatingPoints(amt);
    this.score.raw_pnts += amt;
    this.score.pnts += amt;
    this.score.background_highlight = 1.0;
};

Game.prototype.resetLastMissileTimer = function () {
    this.ship.lastMissileTimer.reset();
    this.startedDeflating = false;
};

Game.prototype.monitor_ship_respawn = function () {
    if (this.ship.alive === false && this.ship.deathTimer.elapsed() >= this.config.ship.explodeDuration) {
        this.ship.reset();
        this.fortress.timer.reset();
        this.resetLastMissileTimer();
        this.ship.lastMissileIgnoreMissiles = false;
        this.addEvent('ship-respawn');
    }
};


Game.prototype.maybeScheduleRandomRotation = function () {
    var r = Math.random() * this.config.orbit.rotationProbabilityDenominator;

    // console.log('rr odds', r);

    if (r < this.config.orbit.rotationProbabilityNumerator) {
        var d = this.config.orbit.rotationDelayMaxDuration - this.config.orbit.rotationDelayMinDuration;
        this.randomRotation.delayDuration = Math.floor(this.config.orbit.rotationDelayMinDuration + Math.random() * d);
        this.randomRotation.delayTimer.reset();
        this.randomRotation.enabled = true;
        this.addEvent('schedule-random-rotation');
        // console.log('random rotation scheduled', this.randomRotation.delayDuration);
    }
};

Game.prototype.update_fortress = function () {
    var dx = this.ship.position.x - this.fortress.position.x;
    var dy = -(this.ship.position.y - this.fortress.position.y);
    var angle_to_ship = mod(rad2deg(Math.atan2(dy, dx)), 360);

    if (!this.fortress.alive && this.fortress.deathTimer.elapsed() > this.config.fortress.explodeDuration) {
        this.fortress.alive = true;
        if (!this.ship.lastMissileIgnoreMissiles) this.resetLastMissileTimer();
        this.ship.noFirePenaltyTimer.reset();
        this.addEvent('fortress-respawn');
        this.maybeScheduleRandomRotation();
    }

    if (this.ship.alive) {
        this.fortress.angle = mod(Math.floor(angle_to_ship / this.fortress.sector_size) * this.fortress.sector_size, 360);
    }
    if (this.fortress.angle !== this.fortress.last_angle) {
        this.fortress.last_angle = this.fortress.angle;
        this.fortress.timer.reset();
    }

    // if (this.fortress.alive &&
    //     this.ship.alive &&
    //     this.ship.lastMissileTimer.elapsed() > this.config.orbit.noFireShellThreshold &&
    //     this.shells.length === 0) {
    //     // if (this.ship.noFirePenaltyTimer.elapsed() >= this.config.orbit.noFirePenaltyDuration) {
    //     //     this.ship.noFirePenaltyTimer.reset();
    //         // Shoot a shell at here the ship will be
    //         var ticks = this.config.orbit.radius / this.config.shells.speed;
    //         var a_inc = Math.PI*2 / (this.config.orbit.radius * 2 * Math.PI / this.config.orbit.speed);
    //         var a = Math.atan2(dy, dx) - a_inc * ticks;

    //         this.shells.push(new Shell(this.config, this.fortress.position.x, this.fortress.position.y, rad2deg(a)));
    //         if (this.config.flappy) this.play(this.lightningSound);
    //         else this.play(this.fireShellSound);
    //         this.addEvent('fortress-fired');
    // }

    // if (this.fortress.timer.elapsed() >= this.fortress.lockTime && this.ship.alive && this.fortress.alive) {
    //     this.shells.push(new Shell(this.config, this.fortress.position.x, this.fortress.position.y, angle_to_ship));
    //     this.fortress.timer.reset();
    //     if (this.config.flappy) this.play(this.lightningSound);
    //     else this.play(this.fireShellSound);
    //     this.addEvent('fortress-fired');
    // }
};

Game.prototype.process_key_state = function () {
    var e;
    for (e=0; e<this.keyState.events.length; e++) {
        var evt = this.keyState.events[e];
        this.addEvent((evt['type']===1 ? 'hold':'release') + '-' + evt['key']);
        this.process_key_event(evt);
    }
    this.keyState.clear();
};

Game.prototype.process_key_event = function (evt) {
    if (evt['type'] == 1) {
        this.last_keypress_time = this.last_tick_time;
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.turn_flag = evt['key'];
        } else if (evt['key'] == 'thrust') {
            this.ship.thrust_flag = true;
        } else if (evt['key'] == 'fire') {
            this.fire_missile();
        }
    } else {
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.turn_flag = null;
        } else if (evt['key'] == 'thrust') {
            this.ship.thrust_flag = false;
        }
    }
};

Game.prototype.fire_missile = function () {
    if (this.ship.alive) {
        var m = new Missile(this.config, this.ship.position.x, this.ship.position.y, this.ship.angle);
        this.missiles.push(m);
        this.addEvent('missile-fired');
    }
};

Game.prototype.kill_ship = function (cause) {
    if (this.ship.alive) {
        this.penalize(this.config.ship_death_penalty);
        this.ship.alive = false;
        this.ship.causeOfDeath = cause;
        this.shipDeaths += 1;
        this.ship.deathTimer.reset();
        if (this.config.flappy) this.play(this.shipDestroyedSound);
        else this.play(this.explosionSound);
    }
};

Game.prototype.move_ship = function () {
    if (this.config.auto_turn) {
        this.ship.angle = Math.floor(angle_to(this.ship.position, this.fortress.position));
        //console.log(this.ship.position.x, this.ship.position.y, this.fortress.position.x, this.fortress.position.y, angle_to(this.ship.position, this.fortress.position));
    } else if (this.config.orbit.enabled) {
        if (this.ship.turn_flag === 'right') {
            this.ship.angle = mod(this.ship.angle - this.ship.turn_speed, 360);
            this.ship.turn_flag = null;
        } else if (this.ship.turn_flag === 'left') {
            this.ship.angle = mod(this.ship.angle + this.ship.turn_speed, 360);
            this.ship.turn_flag = null;
        }
    } else {
        var delta = this.ship.turn_speed;
        if (this.config.flappy) delta *= -1;
        if (this.ship.turn_flag === 'right') {
            this.ship.angle = mod(this.ship.angle - delta, 360);
        } else if (this.ship.turn_flag === 'left') {
            this.ship.angle = mod(this.ship.angle + delta, 360);
        }
    }

    if (this.ship.lastMissileIgnoreMissiles &&
        this.ship.ignoreMissilesTimer.elapsed() > this.config.orbit.distractionBuffer) {
        this.ship.lastMissileIgnoreMissiles = false;
    }

    if (this.randomRotation.enabled && this.randomRotation.delayTimer.elapsed() >= this.randomRotation.delayDuration) {
        this.randomRotation.enabled = false;
        var range = this.config.orbit.maxRotation - this.config.orbit.minRotation;
        var rot = Math.floor(Math.random() * range*2) - range;
        if (rot < 0) rot -= this.config.orbit.minRotation;
        else rot += this.config.orbit.minRotation;
        // console.log('rotate!', this.ship.angle, rot); //, this.ship.lastMissileTimer.time);
        this.ship.angle = mod(this.ship.angle + rot, 360);
        this.ship.ignoreMissilesTimer.reset();
        this.ship.lastMissileIgnoreMissiles = true;
        if (this.ship.lastMissileTimer.elapsed() > this.config.orbit.noFirePenaltyThreshold)
            this.ship.lastMissileTimer.time = this.config.orbit.noFirePenaltyThreshold;
        this.ship.lastMissileTimer.subtract(this.config.orbit.distractionBuffer);
        this.startedDeflating = false;
        this.addEvent('random-rotation');
        // console.log('and now', this.ship.angle); //, this.ship.lastMissileTimer.time);
    }

    if (this.config.orbit.enabled) {
        var a_inc = Math.PI*2 / (this.config.orbit.radius * 2 * Math.PI / this.config.orbit.speed);
        var a = Math.atan2(this.ship.position.y-this.fortress.position.y,
                           this.ship.position.x-this.fortress.position.x) +a_inc;
        this.ship.position.x = this.fortress.position.x + this.config.orbit.radius * Math.cos(a);
        this.ship.position.y = this.fortress.position.y + this.config.orbit.radius * Math.sin(a);
    } else {
        if (this.ship.thrust_flag) {
            this.ship.velocity.x += this.ship.acceleration * Math.cos(deg2rad(this.ship.angle));
            this.ship.velocity.y += this.ship.acceleration * Math.sin(deg2rad(this.ship.angle));
        }
        this.ship.position.x += this.ship.velocity.x;
        this.ship.position.y -= this.ship.velocity.y;
    }
};

Game.prototype.update_ship = function () {
    if (this.ship.alive) {
        this.move_ship();
        if (!this.bighex.inside(this.ship.position)) {
            this.kill_ship(COLLIDE_BIGHEX);
            this.collisions.push(COLLIDE_BIGHEX);
            this.addEvent('explode-bighex');
        } else if (this.smallhex.inside(this.ship.position)) {
            this.kill_ship(COLLIDE_SMALLHEX);
            this.collisions.push(COLLIDE_SMALLHEX);
            this.addEvent('explode-smallhex');
        }
        if (this.fortress.alive &&
            this.ship.lastMissileTimer.elapsed() > this.config.orbit.noFirePenaltyThreshold) {
            if (!this.startedDeflating) {
                if (this.score.vulnerability > 0) {
                    this.play('deflate');
                    this.addEvent('start-deflating');
                }
                this.startedDeflating = true;
            }
            // if (this.ship.noFirePenaltyTimer.elapsedTicks() >= this.config.orbit.noFirePenaltyTicks) {
            //     if (this.config.orbit.noFireChangeColor)
            //         this.fortress.color = this.config.orbit.noFireColor;
            //     this.ship.noFirePenaltyTimer.reset();
            //     this.addEvent('nofire-penalty');
            //     this.penalize(this.config.orbit.noFirePenalty);
            // }
            if (this.score.vulnerability > 10) this.score.vulnerability = 10;
            this.score.vulnerability -= this.config.orbit.noFireBleedRate;
            if (this.score.vulnerability < 0) this.score.vulnerability = 0;
        } else {
            this.fortress.color = this.fortress.defaultColor;
        }
    }
};

Game.prototype.update_missiles = function () {
    var i;
    for (i=0; i<this.missiles.length; i++) {
        this.missiles[i].position.add(this.missiles[i].velocity);
        if (collided (this.missiles[i], this.fortress)) {
            if (!this.ship.lastMissileIgnoreMissiles) this.resetLastMissileTimer();
            this.missiles[i].alive = false;
            this.collisions.push(COLLIDE_FORTRESS);
            this.addEvent('hit-fortress');
            if (this.fortress.alive) {
                if (this.fortress.vulnerabilityTimer.elapsed() >= this.config.fortress.vlnerTime) {
                    this.play('inflate');
                    this.score.vulnerability = Math.round(this.score.vulnerability+1);
                    this.addEvent('vlner-increased');
                    if (this.config.flappy) this.play(this.eggPlacedSound);
                } else {
                    if (this.score.vulnerability >= this.config.fortress.vlnerThreshold + 1) {
                        this.ship.lastMissileIgnoreMissiles = false;
                        this.fortress.alive = false;
                        this.fortress.deathTimer.reset();
                        this.reward(this.config.destroy_fortress);
                        if (this.config.flappy) this.play(this.fortressDestroyedSound);
                        else this.play('explosion');
                        this.addEvent('fortress-destroyed');
                    } else {
                        this.play('vlner-reset');
                        this.addEvent('vlner-reset');
                    }
                    this.score.vulnerability = 0;
                }
                this.fortress.vulnerabilityTimer.reset();
            }
        } else if (this.target >= 0 &&
                   util.lines_intersection_point(this.missiles[i].startPosition,
                                                 this.missiles[i].position,
                                                 this.bighex.points[this.target],
                                                 this.bighex.points[(this.target+1)%this.bighex.points.length])[0] === util.INTERSECTION_INSIDE) {
            this.missiles[i].alive = false;
            this.reward(this.config.orbit.distractionBonus);
            this.target = -1;
            this.targetTimer.reset();
        } else if (outside_game_area(this.missiles[i])) {
            this.penalize(this.config.missile_penalty);
            this.missiles[i].alive = false;
            this.addEvent('missile-out-of-world');
        }
    }
    var alive = [];
    for (i=0; i<this.missiles.length; i++) {
        if (this.missiles[i].alive) {
            alive.push(this.missiles[i]);
        }
    }
    this.missiles = alive;
};

Game.prototype.update_shells = function () {
    var i;
    for (i=0; i<this.shells.length; i++) {
        this.shells[i].position.add(this.shells[i].velocity);
        if (this.ship.alive && collided (this.shells[i], this.ship)) {
            this.collisions.push(COLLIDE_SHIP);
            this.shells[i].alive = false;
            this.kill_ship(COLLIDE_SHIP);
            this.addEvent('shell-hit-ship');
        } else if (outside_game_area(this.shells[i])) {
            this.shells[i].alive = false;
        }
    }
    var alive = [];
    for (i=0; i<this.shells.length; i++) {
        if (this.shells[i].alive) {
            alive.push(this.shells[i]);
        }
    }
    this.shells = alive;
};

Game.prototype.update_target = function () {
    if (this.target < 0) {
        if (this.targetTimer.elapsed() > this.config.orbit.distractionOffDuration) {
            this.target = Math.floor(Math.random() * (this.bighex.points.length-1));
            this.targetTimer.reset();
            this.addEvent('new-target-'+this.target);
        }
    } else {
        if (this.targetTimer.elapsed() > this.config.orbit.distractionOnDuration) {
            this.addEvent('target-gone');
            this.target = -1;
            this.targetTimer.reset();
        }
    }
};

Game.prototype.draw = function () {
    if (this.config.flappy) this.drawFlappy();
    else this.drawNormal();
};

Game.prototype.drawNormal = function () {
    var i;

    this.canvas.fillStyle = '#000000';
    this.canvas.fillRect(0, 0, 710, 626);
    // this.canvas.drawImage(g_images['bg'], 0, 0);

    this.canvas.save();
    this.canvas.lineWidth = 1.5;
    this.canvas.translate(0,-50);

    this.canvas.textAlign = 'center';
    this.canvas.textBaseline = 'middle';
    this.canvas.font = "16px sans-serif";
    this.canvas.fillStyle = "#FFFFFF";
    this.canvas.fillText(this.score.pnts, 710/2, this.config.orbit.scoreY);

    this.canvas.strokeStyle = this.config.hexColor;
    this.canvas.beginPath();
    this.canvas.arc(355, 315, this.bighex.radius, 0, Math.PI*2);
    this.canvas.stroke();

    // this.bighex.draw(this.canvas);
    // this.smallhex.draw(this.canvas);

    this.ship.draw(this.canvas);
    this.fortress.draw(this.canvas, this.score.vulnerability,
                       this.config.fortress.borderColor,
                       this.config.fortress.ballColor);
    for (i=0; i<this.shells.length; i++) {
        if (!collided(this.shells[i], this.fortress)) {
            this.shells[i].draw(this.canvas);
        }
    }
    for (i=0; i<this.missiles.length; i++) {
        this.missiles[i].draw(this.canvas);
    }

    if (this.target >= 0) {
        this.canvas.beginPath();
        this.canvas.moveTo(this.bighex.points[this.target].x, this.bighex.points[this.target].y);
        this.canvas.lineTo(this.bighex.points[(this.target+1)%this.bighex.points.length].x,
                           this.bighex.points[(this.target+1)%this.bighex.points.length].y);
        this.canvas.lineWidth = 4;
        this.canvas.strokeStyle = '#FFFFFF';
        this.canvas.stroke();
    }

    this.canvas.restore();

    // this.draw_score([{title: 'PNTS', value: this.score.pnts},
    //                  {title: 'VLNER', value: Math.floor(this.score.vulnerability)}]);
};

Game.prototype.drawFlappyBricks = function (ctx, img, y) {
    var w = img.width;
    for (var i=0; i<6; i++) {
        ctx.drawImage(img, i*120, y);
    }
};

Game.prototype.createFlappyBackground = function () {
    this.bg = document.createElement('canvas');
    // console.log(this.flappyImages);
    this.bg.width = this.flappyImages['hills'].width*6;
    this.bg.height = 300;
    var ctx = this.bg.getContext('2d');

    ctx.drawImage(this.flappyImages['bg'], 0, 0, this.flappyImages['bg'].width, this.flappyImages['bg'].height,
                  0, 26,
                  this.bg.width, this.flappyImages['bg'].height-40);
    // Hexagons
    for(var i=0, j=0;
        i<this.bg.width;
        i += this.flappyImages['hills'].width,
        j += this.flappyImages['ceiling'].width) {
        ctx.drawImage(this.flappyImages['hills'], i, 226);
    }
    this.drawFlappyBricks(ctx, this.flappyImages['topclouds'], 20);
    this.drawFlappyBricks(ctx, this.flappyImages['bricks'], 277);

    this.bgData = ctx.getImageData(0, 0, this.bg.width, this.bg.height);

    // this.drawFlappyBricks(ctx, this.flappyImages['darkbricks'], 26);
    // this.drawFlappyBricks(ctx, this.flappyImages['darkbricks'], 277);
    this.darkData = ctx.getImageData(0, 0, this.bg.width, this.bg.height);
};

Game.prototype.drawFlappyBird = function () {
    this.canvas.save();
    this.canvas.translate(Math.round(this.flappyTranslate.ship.x), Math.round(this.flappyTranslate.ship.y));
    if (this.config.auto_turn) {
        if (this.ship.alive && this.ship.thrust_flag) this.canvas.rotate(deg2rad(-8));
    } else {
        this.canvas.rotate(-(deg2rad(this.flappyTranslate.ship.orientation-90)));
    }
    if (this.ship.alive) {
        this.canvas.drawImage(this.flappyImages['bird'], Math.round(-this.flappyImages['bird'].width/2), Math.round(-this.flappyImages['bird'].height/2));
    } else {
        var img = 'deadbird';
        if (this.ship.causeOfDeath === COLLIDE_SHIP) img = 'scorchedbird';
        this.canvas.drawImage(this.flappyImages[img], Math.round(-this.flappyImages[img].width/2), Math.round(-this.flappyImages[img].height/2));
    }
    this.canvas.restore();
};

Game.prototype.drawFlappyNest = function (neggs) {
    var img = this.flappyImages['egg']
    if (!this.fortress.alive) {
        neggs = 10;
        img = this.flappyImages['hatchedegg'];
    }
    // sp = relative.polar(relative);
    // p = V(0,0);
    var x=0, y=0;
    if (neggs<=4) { x=0; y=0; }
    else if (neggs<=7) { x=5; y=5; }
    else if (neggs<=9) { x=10; y=10; }
    else { x=15; y=15; }
    for (var i=neggs; i>0; i--) {
        this.canvas.drawImage(img,
                              this.flappyTranslate.fortress.x-this.flappyImages.nest.width/2 + x,
                              // gp.y+p.y-y-35
                              this.flappyTranslate.fortress.y-y-img.height-15);
        x += 10;
        if (i==5) { x=0; y=0; }
        if (i==8) { x=5; y=5; }
        if (i==10) { x=10; y=10; }
        if (i>10) { x=15; y=15; }
    }
    // this.canvas.drawImage(this.flappyImages['nest'], gp.x+p.x+sp.x-this.flappyImages['nest'].width/2, gp.y+p.y);
    this.canvas.drawImage(this.flappyImages.cloud, this.flappyTranslate.fortress.x-this.flappyImages.cloud.width/2, this.flappyTranslate.fortress.y);
    this.canvas.drawImage(this.flappyImages.pedestal, this.flappyTranslate.fortress.x-this.flappyImages.pedestal.width/2, this.flappyTranslate.fortress.y - 46);
};

Game.prototype.drawFlappyLightning = function (proj) {
    // var p = position.polar(relative);
    // this.canvas.drawImage( this.flappyImages.lightning, Math.round(gp.x+p.x), Math.round(gp.y+p.y) );
    this.canvas.drawImage( this.flappyImages.lightning, Math.round(proj.x-this.flappyImages.lightning.width/2), Math.round(proj.y-this.flappyImages.lightning.height/2) );
}

Game.prototype.drawFlappyScore = function (pairs) {
    var label_width = 89;
    var label_height = 32;
    var pad = 16;
    var score_y = 520.5;
    var start = (710-89*pairs.length)/2;
    var i;

    // this.canvas.clearRect(start, score_y, label_width*pairs.length, label_height*2);
    this.canvas.drawImage(this.flappyImages['scoreboard'], (710-90*2)/2, 520);

    // this.canvas.beginPath();
    // this.canvas.strokeStyle = "#00FF00";
    // this.canvas.rect(start + 0.5, score_y, label_width*pairs.length, label_height*2);
    // this.canvas.moveTo(start+label_width+0.5, score_y);
    // this.canvas.lineTo(start+label_width+0.5, score_y+label_height*2);
    // this.canvas.moveTo(start+0.5, score_y+label_height);
    // this.canvas.lineTo(start+0.5+label_width*pairs.length, score_y+label_height);
    // this.canvas.stroke();

    this.canvas.textAlign = 'center';
    this.canvas.textBaseline = 'middle';

    // this.canvas.fillStyle = "#00FF00";
    this.canvas.fillStyle = "#FFFFFF";
    this.canvas.shadowColor = "#000000"
    this.canvas.shadowOffsetX = 2;
    this.canvas.shadowOffsetY = 2;
    this.canvas.font = "14px sans-serif";
    for (i=0; i<pairs.length; i++) {
        this.canvas.fillText(pairs[i].title, start + label_width*i + label_width/2, score_y+18);
    }

    this.canvas.font = "16px sans-serif";
    this.canvas.fillStyle = "#FFFF00";
    for (i=0; i<pairs.length; i++) {
        this.canvas.fillText(pairs[i].value.toString(), start + label_width*i + label_width/2, score_y+label_height+15);
    }
};

Game.prototype.drawFlappyBg = function () {
    var data;
    if (this.fortress.alive) data = this.bgData;
    else data = this.darkData;

    this.canvas.putImageData(data, Math.round(this.flappyTranslate.backgroundOffset), 140);
    if (this.flappyTranslate.backgroundOffset > 0)
        this.canvas.putImageData(data, Math.round(this.flappyTranslate.backgroundOffset-this.bgData.width), 140);
    else
        this.canvas.putImageData(data, Math.round(this.flappyTranslate.backgroundOffset+this.bgData.width), 140);
};

Game.prototype.drawFlappyProjectiles = function () {
    if (this.config.flappy_nest)
        this.drawFlappyNest (this.score.vulnerability);
    for (let i=0; i<this.flappyTranslate.shells.length; i++) {
        if (!collided(this.shells[i], this.fortress)) {
            this.drawFlappyLightning (this.flappyTranslate.shells[i]);
        }
    }
    if (this.config.flappy_eggs) {
        for (i=0; i<this.flappyTranslate.missiles.length; i++) {
            this.canvas.drawImage(this.flappyImages['egg'], Math.round(this.flappyTranslate.missiles[i]['x']-this.flappyImages['egg'].width/2), Math.round(this.flappyTranslate.missiles[i]['y']-this.flappyImages['egg'].height/2));
        }
    }
}

Game.prototype.drawFlappy = function () {
    this.canvas.clearRect(0, 0, 710, 626);

    this.drawFlappyBg();

    this.canvas.save();

    // this.canvas.fillStyle = '#FF0000';
    // for (let i=0; i<state['hill-points'].length; i++) {
    //     this.canvas.fillRect (state['ceiling-points'][i]['x'], state['ceiling-points'][i]['y'], 1, 1);
    //     this.canvas.fillRect (state['hill-points'][i]['x'], state['hill-points'][i]['y'], 1, 1);
    //     this.canvas.stroke();
    // }

    // bird
    // console.log('before', gp);
    this.drawFlappyBird();

    this.drawFlappyProjectiles();
    this.canvas.restore();

    this.canvas.save();
    this.canvas.translate(0,-60);

    this.drawFlappyScore([{title: 'POINTS', value: this.score.pnts},
                          {title: 'EGGS', value: this.score.vulnerability}]);
    this.canvas.restore();
};

Game.prototype.step_timers = function () {
    this.currentTick += 1;
    this.fortress.timer.tick(this.tinc);
    this.fortress.deathTimer.tick(this.tinc);
    this.fortress.vulnerabilityTimer.tick(this.tinc);
    this.ship.deathTimer.tick(this.tinc);
    this.ship.noFirePenaltyTimer.tick(this.tinc);
    this.ship.ignoreMissilesTimer.tick(this.tinc);
    this.ship.lastMissileTimer.tick(this.tinc);
    this.targetTimer.tick(this.tinc);
    this.randomRotation.delayTimer.tick(this.tinc);
};

Game.prototype.get_realtime_tinc = function () {
    this.last_tick_time = this.now;
    this.now = getCurrentTime();
    if (this.last_tick_time === null) {
        this.last_tick_time = this.now;
        this.last_keypress_time = this.now;
    }
    return this.now - this.last_tick_time;
};

Game.prototype.update_time = function () {
    // Advance the game timer but not the other timers because that's
    // how original autoturn works.
    this.gameTimer.tick(this.tinc);
};

Game.prototype.step_one_tick = function (tinc) {
    this.tinc = tinc;
    this.collisions = [];
    this.currentFrameEvents = [];
    this.update_time();
    this.process_key_state();
    this.monitor_ship_respawn();
    this.update_ship();
    this.update_fortress();
    this.update_shells();
    this.update_missiles();
    if (this.config.flappy) this.flappyTranslate.update(this);

    // console.log('alive', this.gameTimer.elapsed(), this.tinc, this.ship.deathTimer.elapsed(), this.ship.alive);

    this.recordEverything();
    this.step_timers();
};

Game.prototype.is_game_over = function () {
    return this.gameTimer.elapsed() >= this.config.game_time;
};

Game.prototype.detect_abandoned = function () {
    return this.last_tick_time - this.last_keypress_time > this.config.abandon_threshold;
};

Game.prototype.show_abandoned_message = function () {
    exp.gameResetCount += 1;
    exp.lg('detected-abandoned', {resets: exp.gameResetCount});
    // $('#screen-canvas').css('display','none');
    $('#abandon').css('display','block');
    this.cancel_redraw();
    this.clearEvents();
};

Game.prototype.reset_after_abandoned = function () {
    $('#abandon').css('display','none');

    this.ship = new Ship(this.config);
    this.fortress = new Fortress(this.config);
    Game.prototype.init_basic_game_state.call(this);

    this.now = null;
    this.last_tick_time = null;
    this.time_debt = 0;
    this.tinc = 0;
    this.targetTimer.reset();

    this.request_redraw();
    this.addEventListeners();

    // this.exp.resetGameData(this.game_number);
    exp.lg('reset-after-abandoned');
    this.recordEverything();
};


Game.prototype.cancel_redraw = function () {
    window.cancelAnimationFrame(this.timer);
    this.timer = null;
};

Game.prototype.request_redraw = function () {
    this.timer = window.requestAnimationFrame($.proxy(this.tick, this));
};

Game.prototype.tick = function (ts) {
    // var start_ts = getCurrentTime();
    // Do as many game ticks that can fit in the time between the last
    // frame and this one. time_debt is carried over to the next
    // update.
    var delta = this.get_realtime_tinc();
    // console.log('tick', ms, this.time_debt);
    this.tickFn_delta = delta;
    var ms = delta + this.time_debt;
    var dur = 1000/60;
    // Limit the number of steps per screen update to 60.
    var count = 0;
    while (ms > 0 && count < 60) {
        this.step_one_tick(dur);
        ms -= dur;
        count += 1;
    }
    // Limit the time debt to 1s.
    if (ms > 1000) ms = 1000;
    this.time_debt = ms;
    this.draw();

    if (this.detect_abandoned()) {
        this.show_abandoned_message();
    } else if (this.is_game_over()) {
        this.exp.nextScreen();
    } else {
        this.request_redraw();
    }
};

Game.prototype.calculate_bonus = function () {
    this.bonus = Math.ceil((this.score.pnts / this.config.max_points) * this.config.max_bonus);
};

Game.prototype.cleanup_preamble = function () {
    // this.gui.destroy();
    this.calculate_bonus();
    this.exp.gameReward = this.bonus;
    this.exp.gamePoints = this.score.pnts;
    this.exp.gameScores[this.game_number-1] = this.score.pnts;
    this.exp.addReward(this.bonus);
};

Game.prototype.cleanup_main = function () {
    if (this.config.staircase.enabled) {
        // Update hex sizes for next game
        if (this.shipDeaths <= 1) {
            this.exp.bigHex -= this.config.staircase.hexContraction;
            this.exp.smallHex += this.config.staircase.hexContraction;
            // Don't make it too small.
            if (this.exp.bigHex - this.exp.smallHex < this.config.staircase.minHexDistance) {
                this.exp.bigHex += this.config.staircase.hexContraction;
                this.exp.smallHex -= this.config.staircase.hexContraction;
            }
        } else {
            this.exp.bigHex += this.config.staircase.hexExpansion;
            this.exp.smallHex -= this.config.staircase.hexExpansion;
            // don't exceed original size
            if (this.exp.bigHex > this.config.bigHex) {
                this.exp.bigHex = this.config.bigHex;
            }
            if (this.exp.smallHex < this.config.smallHex) {
                this.exp.smallHex = this.config.smallHex;
            }
        }
    }
};

Game.prototype.cleanup_finish = function () {
    // Send it all to the server
    var stats = {'deaths': this.shipDeaths, 'bonus': this.bonus, 'points': this.score.pnts, 'rawpnts': this.score.raw_pnts};
    // this.exp.updateGameData(this.score.pnts, this.bonus);
    // this.exp.lgEndScreen(stats);
    this.exp.gameLogFooter(this.game_number, stats);
};

Game.prototype.cleanup = function () {
    this.cleanup_preamble();
    this.cleanup_main();
    this.cleanup_finish();
};

exports.Game = Game;
exports.Ship = Ship;
exports.Vector = Vector;
exports.V = V;
exports.Entity = Entity;

exports.TURN_CODES = TURN_CODES;
exports.KEY_CODES = KEY_CODES;

}) (typeof exports === 'undefined' ? this['autoorbitv4']={}:exports);

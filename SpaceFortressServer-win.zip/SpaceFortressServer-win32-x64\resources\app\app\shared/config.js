"use strict";

(function (exports) {

var util = typeof require === 'undefined' ? window.util:require('./util');

var GAMETIME = 180000;

function Config() {
    Object.call(this);
    this.game_type = "none";

    this.screen_width = 710;
    this.screen_height = 626;
    this.game_time = 60000;
    this.fps = 30;

    this.destroy_fortress = 100;
    this.ship_death_penalty = 100;
    this.missile_penalty = 2;

    this.max_points = 3000;
    this.max_bonus = 60;

    this.auto_turn = false;

    this.fortress = {};
    this.fortress.sectorSize = 10;
    this.fortress.lockTime = 1000;
    this.fortress.vlnerTime = 250;
    this.fortress.vlnerThreshold = 10;
    this.fortress.collisionRadius = 18;
    this.fortress.explodeDuration = 1000;

    // Hexagons

    this.bigHex = 200;
    this.smallHex = 40;

    this.staircase = {};
    this.staircase.enabled = false;
    this.staircase.hexContraction = 5;
    this.staircase.hexExpansion = 15;
    this.staircase.minHexDistance = 20;
    this.staircase.fortressPointsPerContraction = 10;
    this.staircase.bigHexStartRadius = 200;
    this.staircase.smallHexStartRadius = 40;

    this.ship = {};
    this.ship.startAngle = 0;
    this.ship.turnSpeed = 6;
    this.ship.acceleration = 0.3;
    this.ship.collisionRadius = 10;
    this.ship.explodeDuration = 1000;
    this.ship.startPosition = {x: 235, y: 315};
    this.ship.startVelocity = {x: Math.cos(util.deg2rad(60)), y: Math.sin(util.deg2rad(60))};

    this.missiles = {};
    this.missiles.collisionRadius = 5;
    this.missiles.speed = 20;

    this.shells = {};
    this.shells.collisionRadius = 3;
    this.shells.speed = 6;

    this.nav = {};
    this.nav.staircase = false;
    this.nav.staircase_delta = 15;
    this.nav.staircase_decrease_threshold = 1; //Decrease half_width if deaths exceed this
    this.nav.staircase_increase_threshold = 1; //Increase half_width if deaths exceed this
    this.nav.rect_width = 110;
    this.nav.enter_rectangle = 25;
    this.nav.min_angle = 30;
    this.nav.max_angle = 150;
    this.nav.min_rect_width = 50;

    this.flappy = false;
    this.flappy_nest = true;
    this.flappy_eggs = true;

    return this;
}

function YouturnConfig() {
    Config.call(this);
    this.game_type = "explode";
    this.game_time = GAMETIME;
    this.auto_turn = false;
    return this;
}

function FlappyYouturnConfig() {
    YouturnConfig.call(this);
    this.game_type = "flappy_youturn";
    this.flappy = true;
    this.max_bonus = 120;
    return this;
}

function AutoturnConfig() {
    Config.call(this);
    this.game_type = "autoturn";
    this.game_time = GAMETIME;
    this.auto_turn = true;
    return this;
}

function FlappyAutoturnConfig() {
    AutoturnConfig.call(this);
    this.game_type = "flappy_autoturn";
    this.flappy = true;
    return this;
}

function StaircasePracticeConfig() {
    Config.call(this);
    this.game_type = "staircase_practice";
    this.auto_turn = true;
    return this;
}

function StaircaseConfig() {
    Config.call(this);
    this.game_type = "staircase";
    this.game_time = 60000;
    this.auto_turn = true;
    this.staircase.enabled = true;

    return this;
}

function NavConfig() {
    Config.call(this);
    this.game_type = "nav";
    this.game_time = GAMETIME;
    this.max_points = 1000;
    this.max_bonus = 30;
    this.ship.startPosition = {x:350, y:350};
    this.ship.startVelocity = {x:0.5, y:0};
    return this;
}

function SpacetrackV6NoStopConfig() {
    NavConfig.call(this);

    this.game_type = "spacetrack";
    this.fps = 60;
    this.abandon_threshold = 0;

    this.ship.acceleration = 0.1;
    this.ship.turnSpeed = 3;
    this.ship.instantFlip = false;
    this.ship.tapToFlip = false;
    this.ship.flipTurnSpeed = 6;
    this.ship.color = '#FFFF00';

    this.nav.min_angle = 30;
    this.nav.max_angle = 150;
    this.nav.min_rect_width = 50;
    this.nav.stop_speed_threshold = 0.4; //0.8;
    this.nav.stop_required = false;
    this.nav.startSpeed = 0.5;
}

function SpacetrackV6StopConfig() {
    SpacetrackV6NoStopConfig.call(this);
    this.nav.stop_required = true;
}

function AutoOrbitBaseLineConfig() {
    Config.call(this);
    this.game_type = "auto-orbit.baseline";

    this.fps = 60;
    this.game_time = GAMETIME;
    this.abandon_threshold = 0;

    this.max_points = 1000;
    this.max_bonus = 20;

    this.speedMultiplier = 1;

    this.orbit = {};
    this.orbit.enabled = true;
    this.orbit.radius = 120;
    this.orbit.noFirePenaltyThreshold = 750;
    this.orbit.noFireBleedRate = 0.1;
    this.orbit.speed = 0.5;
    this.orbit.distractionDuration = 25000;
    this.orbit.distractionRange = 2000;
    this.orbit.randomRotations = [19000,20000,21000,22000,22000,23000,24000,25000];
    this.orbit.minRotation = 60;
    this.orbit.maxRotation = 120;
    this.orbit.distractionBuffer = 2000;
    this.orbit.scoreY = 390;

    this.ship.turnSpeed = 15;
    this.ship.acceleration = 0.15;
    this.ship.startVelocity = {x:Math.cos(Math.PI/3) * 0.5, y:Math.sin(Math.PI/3) * 0.5};
    this.ship.color = '#FFFF00';

    this.missiles.speed = 10;

    return this;
}

function AutoOrbitSpeedConfig() {
    AutoOrbitBaseLineConfig.call(this);
    this.game_type = "auto-orbit-v2.speed";
    this.orbit.speed = 1.0;
    this.destroy_fortress = 100;
}

function AutoOrbitIntervalConfig() {
    AutoOrbitBaseLineConfig.call(this);
    this.game_type = "auto-orbit-v2.interval";
    this.speedMultiplier = 0.5;
    this.destroy_fortress = 200;
}

function AutoOrbitV3BaseConfig() {
    Config.call(this);
    this.game_type = "auto-orbit-v3.base";

    this.fps = 60;
    this.screen_width = 710;
    this.screen_height = 626;
    this.game_time = 180000;
    this.abandon_threshold = 20000;

    this.destroy_fortress = 100;
    this.ship_death_penalty = 100;
    this.missile_penalty = 2;

    this.max_points = 1000;
    this.max_bonus = 20;

    this.auto_turn = false;

    this.speedMultiplier = 1;

    this.orbit = {};
    this.orbit.enabled = true;
    this.orbit.radius = 120;
    this.orbit.noFirePenaltyThreshold = 600;
    this.orbit.noFireBleedRate = 0.1;
    this.orbit.speed = 1.0;
    this.orbit.minRotation = 60;
    this.orbit.maxRotation = 120;
    this.orbit.distractionBuffer = 2000;
    this.orbit.scoreY = 390;
    this.orbit.rotationProbabilityNumerator = 1;
    this.orbit.rotationProbabilityDenominator = 3;
    this.orbit.rotationDelayMinDuration = 1000;
    this.orbit.rotationDelayMaxDuration = 4000;


    // this.orbit.distractionBonus = 50;
    // this.orbit.distractionOffDuration = 10000;
    // this.orbit.distractionOnDuration = 5000;

    this.fortress = {};
    this.fortress.sectorSize = 10;
    this.fortress.lockTime = 1000;
    this.fortress.vlnerTime = 250;
    this.fortress.vlnerThreshold = 10;
    this.fortress.collisionRadius = 18;
    this.fortress.explodeDuration = 1000;

    this.fortress.borderColor = '#E8E807';
    this.fortress.ballColor = '#CA5414';

    // Hexagons

    this.bigHex = 200;
    this.smallHex = 40;
    this.hexColor = '#E8E807';

    this.ship = {};
    this.ship.startAngle = 0;
    this.ship.turnSpeed = 15;
    this.ship.acceleration = 0.15;
    this.ship.collisionRadius = 10;
    this.ship.explodeDuration = 1000;
    this.ship.startPosition = {x:235, y:315};
    this.ship.startVelocity = {x:Math.cos(Math.PI/3) * 0.5, y:Math.sin(Math.PI/3) * 0.5};
    this.ship.color = '#FFFF00';

    this.missiles = {};
    this.missiles.collisionRadius = 5;
    this.missiles.speed = 10;

    this.shells = {};
    this.shells.collisionRadius = 3;
    this.shells.speed = 3;

    this.nav = {};
    this.nav.staircase = false;
    this.nav.staircase_delta = 15;
    this.nav.staircase_decrease_threshold = 1; //Decrease half_width if deaths exceed this
    this.nav.staircase_increase_threshold = 1; //Increase half_width if deaths exceed this
    this.nav.rect_width = 110;
    this.nav.enter_rectangle = 25;
    this.nav.min_angle = 30;
    this.nav.max_angle = 150;
    this.nav.min_rect_width = 50;

    this.flappy = false;
    this.flappy_nest = true;
    this.flappy_eggs = true;

    return this;
}

function AutoOrbitSlowConfig() {
    AutoOrbitV3BaseConfig.call(this);
    this.game_type = "auto-orbit-v3.slow";
    this.speedMultiplier = 0.25;
    this.destroy_fortress = 300;
    this.missile_penalty = 6;
}

function AutoOrbitMediumConfig() {
    AutoOrbitV3BaseConfig.call(this);
    this.game_type = "auto-orbit-v3.medium";
    this.speedMultiplier = 0.5;
    this.destroy_fortress = 200;
    this.missile_penalty = 4;
}

function AutoOrbitFastConfig() {
    AutoOrbitV3BaseConfig.call(this);
    this.game_type = "auto-orbit-v3.fast";
    this.speedMultiplier = 1.0;
    this.destroy_fortress = 100;
    this.missile_penalty = 2;
}



exports.NavConfig = NavConfig;
exports.SpacetrackV6StopConfig = SpacetrackV6StopConfig;
exports.SpacetrackV6NoStopConfig = SpacetrackV6NoStopConfig;
exports.AutoturnConfig = AutoturnConfig;
exports.FlappyAutoturnConfig = FlappyAutoturnConfig;
exports.YouturnConfig = YouturnConfig;
exports.FlappyYouturnConfig = FlappyYouturnConfig;
exports.StaircaseConfig = StaircaseConfig;

exports.AutoOrbitBaseLineConfig = AutoOrbitBaseLineConfig;
exports.AutoOrbitSpeedConfig = AutoOrbitSpeedConfig;
exports.AutoOrbitIntervalConfig = AutoOrbitIntervalConfig;

exports.AutoOrbitSlowConfig = AutoOrbitSlowConfig;
exports.AutoOrbitMediumConfig = AutoOrbitMediumConfig;
exports.AutoOrbitFastConfig = AutoOrbitFastConfig;

}) (typeof exports === 'undefined' ? this['config']={}:exports);

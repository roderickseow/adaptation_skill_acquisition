(function (exports) {

var util = typeof require === 'undefined' ? window.util:require("./util");
var gamelib = typeof require === 'undefined' ? window.game:require("./spacetrack-v6-game");
var trackAngles = typeof require === 'undefined' ? window.game:require("./spacetrack-v6-trackangles");
var TickManager = require('./spacetrack-v6-tickmanager.js');

var KEY_CODES = gamelib.KEY_CODES;

var lines_intersection_point = util.lines_intersection_point;
var point_inside_rect = util.point_inside_rect;

var Game = gamelib.Game;
var Ship = gamelib.Ship;
var V = util.V;
var Vector = util.Vector;
var Entity = gamelib.Entity;
var dotProduct = util.dotProduct;
var angle_to = util.angle_to;
var mod = util.mod;

function Segment(start,end,margin,ghost) {
    Entity.call(this);
    this.start = start;
    this.end = end;
    this.margin = margin;
    this.ghost = ghost;
    this.calcCorners();
    return this;
}

Segment.prototype.contains = function(pos) {
    var seg_dir = this.direction();
    var recentered_pos = pos.duplicate().sub(this.start);

    //At start point or close enough to cause roundoff errors?
    if (recentered_pos.norm() <= 0) {
        return true;
    }

    //Project current position onto main segment axis and check it is in bounds
    var par = dotProduct(seg_dir,recentered_pos) / seg_dir.norm();
    if (par < -this.margin || par > (seg_dir.norm()+this.margin)) {
        return false;
    } else {
        //Use Pythagorean theorem to find square of coordinate perpendicular to
        //segment direction
        var perp = Math.pow(recentered_pos.norm(),2) - Math.pow(par,2);
        if (perp > Math.pow(this.margin,2)) {
            return false;
        } else {
            return true;
        }
    }
}

Segment.prototype.shortContains = function(pos) {
    var seg_dir = this.direction();
    var recentered_pos = pos.duplicate().sub(this.start)

    // //At start point or close enough to cause roundoff errors?
    // if (recentered_pos.norm() <= 0) {
    //     return true;
    // }

    var in_start_circle = recentered_pos.norm() < this.margin;
    var in_end_circle = pos.duplicate().sub(this.end).norm() < this.margin;

    //Project current position onto main segment axis and check it is in bounds
    var par = dotProduct(seg_dir,recentered_pos) / seg_dir.norm();
    if (in_start_circle || in_end_circle) {
        return true;
    } else if (par > 0 && par < seg_dir.norm()) {
        //Use Pythagorean theorem to find square of coordinate perpendicular to
        //segment direction
        var perp = Math.pow(recentered_pos.norm(),2) - Math.pow(par,2);
        if (perp > Math.pow(this.margin,2)) {
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
}

Segment.prototype.copy = function() {
    // console.log('segment copy', this.start, this.end);
    return new Segment(this.start.duplicate(),this.end.duplicate(),this.margin,this.ghost);
}

Segment.prototype.calcCorners = function() {
    var seg_dir = this.direction();
    var par = seg_dir.normalize();
    par.scalar_mult(this.margin);

    var normal = V(seg_dir.y,-seg_dir.x);
    normal.normalize();
    normal.scalar_mult(this.margin);

    start1 = this.start.duplicate().add(normal).sub(par);
    start2 = this.start.duplicate().sub(normal).sub(par);
    end1 = this.end.duplicate().add(normal).add(par);
    end2 = this.end.duplicate().sub(normal).add(par);
    this.corners = [start1, end1, end2, start2];
    this.shortCorners = [this.start.duplicate().add(normal),
                         this.end.duplicate().add(normal),
                         this.end.duplicate().sub(normal),
                         this.start.duplicate().sub(normal)];
}

Segment.prototype.draw = function(canvas) {
    canvas.save();
    // if (this.ghost) {
    //     canvas.strokeStyle = '#0000FF';
    // } else {
    //     canvas.strokeStyle = '#60FF60';
    // }
    canvas.strokeStyle = '#999999';
    canvas.lineWidth = 1.0;
    canvas.beginPath();
    canvas.moveTo(this.corners[0].x, this.corners[0].y);
    for (var i=1; i<this.corners.length; i++) {
        canvas.lineTo(this.corners[i].x, this.corners[i].y);
    }
    canvas.closePath();
    canvas.stroke();
    canvas.restore();
}

Segment.prototype.direction = function() {
    var retVal = this.end.duplicate();
    retVal.sub(this.start);
    return retVal;
}

Segment.prototype.width = function() {
    return 2*this.margin;
}

Segment.prototype.length = function() {
    return 2*this.margin+this.direction().norm();
}

Segment.prototype.dumpForLog = function() {
    return {'start': this.start,
            'end': this.end,
            'shortCorners': this.shortCorners,
            'corners': this.corners};
}

/* Suppose we are working with a 'scissor' arrangement of two segments which share
   the same start point, the same length, and the same width, with some angle between
   their main axes.

   Define a 'non-cutting' line to be the line with the following properties:
   - It runs along an inner segment main edge (the edges that are parallel to the segment axis)
   - It starts at the end of an inner segment main edge closest to the shared start of the two segments
   - It ends at the 'cutting point'/point of intersection of the two inner edges

   Given the width of the two segments, the angle between their main axes, and the
   ratio of the length of a 'non-cutting' line to the length of a segment's main edge,
   find the length of a segment's main axis

   This is a case where a picture would be worth a lot :/

   Angle should be in radians

   It would be nice to put this in a geometry object, or perhaps an object that
   solved algebra problems in scissor situations */
function solveForScissorAxisLength(width,angle,ratio) {
    /*WLOG we can assume the start point is at the origin and one of the segments is parallel to the x-axis
      Express the inner segment edge that is NOT parallel to the x-axis as a line of the form ax+b*/
    var a = Math.abs(Math.tan(angle)); var b = -Math.abs(1/Math.cos(angle))*(width/2);
    var intersectionX = (width/2 - b) / a; //Solve ax+b for x when y = width/2
    var nonCuttingLineLength = intersectionX+width/2;

    //We want ratio = nonCuttingLineLength / (axisLength + width)
    return nonCuttingLineLength/ratio- width;

}

function Stars(center_pos) {

    var Star = function(pos,grid_x,grid_y) {
        this.x = pos.x;
        this.y = pos.y;
        this.r = 1+Math.floor(Math.random()*3),
        this.gx = grid_x;
        this.gy = grid_y;

        Star.prototype.draw = function(canvas) {
            canvas.fillStyle = '#EEEEEE';
            canvas.beginPath();
            canvas.arc(this.x, this.y, this.r, 0, 2*Math.PI, false);
            canvas.fill();
            canvas.fillStyle = '#000000';
        }

        Star.prototype.inside = function(xmin,xmax,ymin,ymax) {
            return (xmin <= (this.x-this.r)) & ((this.x+this.r) <= xmax) & (ymin <= (this.y-this.r)) & ((this.y+this.r) <= ymax);
        }

        Star.prototype.insideGrid = function (xmin,xmax,ymin,ymax) {
            return (xmin <= this.gx) & (this.gx <= xmax) & (ymin <= this.gy) & (this.gy <= ymax);
        }

        Star.prototype.update = function(motion) {
            this.x -= motion.x;
            this.y += motion.y;
        }

        Star.prototype.shift_grid_cell = function(dh,dv) {
            this.gx += dh;
            this.gy += dv;
        }

        Star.prototype.toString = function() {
            return 'star @' + this.gx + ',' + this.gy;
        }
    }

    var StarSet = new Set();
    //one star per starbox_size (px) x starbox_size (px) grid cell
    var starbox_size = 100;
    var grid_size = 15;
    var cx = center_pos.x;
    var cy = center_pos.y;

    //screen center starts in the middle of a grid cell
    var screen_center_x = 15;
    var screen_center_y = 15;

    var addStar = function(i,j,set) {
        var basex = cx-screen_center_x + starbox_size*(i-Math.floor(grid_size/2)),
            basey = cy-screen_center_y + starbox_size*(j-Math.floor(grid_size/2)),
            star_pos = V(basex + starbox_size*Math.random(),basey+starbox_size*Math.random());
        set.add(new Star(star_pos,i,j));
    }

    for (var i = 0; i < grid_size; i++) {
        for (var j = 0; j < grid_size; j++) {
            addStar(i,j,StarSet);
        }
    }

    var addBorderStars = function(vertical_sweep_x,horizontal_sweep_y) {
        if (vertical_sweep_x !== undefined) {
            for (var i = 1; i < grid_size - 1; i++) {
                addStar(vertical_sweep_x,i,StarSet);
            }
        }

        if (horizontal_sweep_y !== undefined) {
            for (let i = 1; i < grid_size - 1; i++) {
                addStar(i,horizontal_sweep_y,StarSet);
            }
        }

        if (vertical_sweep_x === 0 || horizontal_sweep_y === 0) {
            addStar(0,0,StarSet);
        }
        if (vertical_sweep_x === 0 || horizontal_sweep_y === grid_size-1) {
            addStar(0,grid_size-1,StarSet);
        }
        if (vertical_sweep_x === grid_size-1 || horizontal_sweep_y === 0) {
            addStar(grid_size-1,0,StarSet);
        }
        if (vertical_sweep_x === grid_size-1 || horizontal_sweep_y === grid_size-1) {
            addStar(grid_size-1,grid_size-1,StarSet);
        }
    }

    Stars.prototype.update = function(motion) {

        var delta_vertical = 0,
            delta_horizontal = 0,
            horizontal_sweep_y,
            vertical_sweep_x,
            i,
            entry;

        screen_center_x -= motion.x;
        screen_center_y += motion.y;

        if (screen_center_x < 0) {
            delta_horizontal = -1;
            vertical_sweep_x = grid_size-1;
        } else if (screen_center_x > starbox_size) {
            delta_horizontal = 1;
            vertical_sweep_x = 0;
        }

        if (screen_center_y < 0) {
            delta_vertical = -1;
            horizontal_sweep_y = grid_size-1;
        } else if (screen_center_y > starbox_size) {
            delta_vertical = 1;
            horizontal_sweep_y = 0;
        }

        StarSet.forEach(function (val) {
            val.shift_grid_cell(delta_horizontal,delta_vertical);
            val.update(motion);
        });

        addBorderStars(vertical_sweep_x,horizontal_sweep_y);

        for (var entry of StarSet) {
            if (! entry.insideGrid(0,grid_size-1,0,grid_size-1)) {
                StarSet.delete(entry);
            }
        }

        // console.log('Number of stars: ' + StarSet.size);
        screen_center_x = mod(screen_center_x, starbox_size);
        screen_center_y = mod(screen_center_y, starbox_size);

    }

    Stars.prototype.draw = function(canvas) {
        for (var entry of StarSet) {
            if (entry.inside(0,screen_width,0,screen_height)) {
                entry.draw(canvas);
            }
        }
    }
}

function Nav(exp, config, gnum) {
    Object.call(this);

    this.exp = exp;

    this.screen_id = 'spacetrack';
    this.config = config;
    this.game_number = gnum;

    if (gnum > 0 && gnum <= trackAngles.length)
        this.angleList = trackAngles[gnum-1];
    else
        this.angleList = [];

    this.stars = config.stars ? new Stars(V(350,350)) : undefined;

    return this;
}

Nav.prototype = {};

Nav.prototype.init_basic_game_state = function() {
    Game.prototype.init_basic_game_state.call(this);

    this.ship.startVelocity.x = this.config.nav.startSpeed;
    this.ship.startVelocity.y = 0;
    this.in_transition = false;

    this.angleListIndex = 0;
}

Nav.prototype.lengthFromWidth = function(width) {
    var min_angle = util.deg2rad(this.config.nav.min_angle);
    var max_angle = util.deg2rad(this.config.nav.max_angle);
    var maximizing_angle = Math.min(Math.abs(min_angle), Math.abs(Math.PI-max_angle));

    return solveForScissorAxisLength(width,maximizing_angle,0.55);
}

Nav.prototype.getNextRectAngle = function() {
    if (this.angleListIndex < this.angleList.length) {
        var a = this.angleList[this.angleListIndex];
        // console.log('new angle', a);
        this.angleListIndex += 1;
        return util.deg2rad(a);
    } else {
        var angle_range = this.max_angle - this.min_angle;
        var parity = 1-2*Math.floor(2*Math.random());
        return (this.min_angle + Math.random()*angle_range)*parity;
    }
}

Nav.prototype.genStartSegments = function() {

    this.min_angle = util.deg2rad(this.config.nav.min_angle);
    this.max_angle = util.deg2rad(this.config.nav.max_angle);

    this.segment = new Segment(V(350,350),V(350+this.rect_length,350),this.half_width,false);

    var phi = this.getNextRectAngle();

    var begin = this.segment.end.duplicate();
    var margin = this.half_width;
    var old_dir = this.segment.direction();
    var theta = Math.atan2(old_dir.y,old_dir.x);
    var diff_x = this.rect_length*Math.cos(phi+theta);
    var diff_y = this.rect_length*Math.sin(phi+theta);
    var end = begin.duplicate().add(V(diff_x,diff_y));
    this.next_segment = new Segment(begin,end,margin,true);

    this.track = this.segments_to_curved_path_points(this.segment, this.next_segment);
}

Nav.prototype.initCanvas = function (canvas, images) {
    this.canvas = canvas.getContext('2d');
};

Nav.prototype.getHeaderData = function () {
    return {'type': this.config.game_type,
            'version': 2,
            'config': this.config,
            'log': ['game_clock', 'ship_alive', 'ship_x', 'ship_y', 'ship_vx', 'ship_vy', 'ship_angle', 'points', 'thrust_flag', 'turn_flag', 'stop_mark', 'events'],
            'rect_width': 2*this.half_width,
            'rect_length': this.rect_length,
            'segment1': this.segment.dumpForLog(),
            'segment2': this.next_segment.dumpForLog(),
            'trackPath': this.track};
};

Nav.prototype.coreInit = function () {
    this.init_basic_game_state();
    if (!this.config.nav.staircase || !this.exp.rect_width || ! this.exp.rect_length) {
        this.exp.rect_width = this.config.nav.rect_width;
        this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);
    }

    this.half_width = this.exp.rect_width/2;
    this.rect_length = this.exp.rect_length;
    this.genStartSegments();

    this.last_tick_time = null;
    this.tinc = 0;

    this.exp.resetGameData(this.game_number);

    var header = this.getHeaderData();
    header.gnum = this.game_number;

    this.exp.lgStartScreen(header);
    this.recordEverything();
};

Nav.prototype.addGUI = function () {
    this.gui = new dat.GUI();

    this.gui.add(this.config.ship, 'instantFlip');
    this.gui.add(this.config.ship, 'tapToFlip');
    this.gui.add(this.config.ship, 'flipTurnSpeed');
    this.gui.add(this.config.ship, 'acceleration');
    this.gui.add(this.config.ship, 'turnSpeed');
    this.gui.add(this.config.nav, 'startSpeed');
}


Nav.prototype.init = function () {
    $("#experiment_area").html('<canvas id="screen-canvas" width="' + this.config.screen_width + '" height="' + this.config.screen_height + '"></canvas>'+
                               '<div id="abandon" style="display: none; position: absolute; left:50%; top: 50%; text-align:center; background-color: rgb(230,240,255); border: 5px solid red; font-family: sans-serif; width: 400px; margin-left: -200px; margin-top: -75px"><div syle=""><p>When you are ready to return to the game, click the button to restart from the beginning.<p><button id="restart">Ready To Restart</div></div>');

    // this.addGUI();

    $('#restart').on('click', $.proxy(this.reset_after_abandoned, this));

    this.initCanvas (document.getElementById('screen-canvas'), {});

    this.tickManager = new TickManager();

    console.log('blaaarg', this.tickManager);

    this.requestRedraw();
    this.addEventListeners();

    this.coreInit();
};

Nav.prototype.addEventListeners = Game.prototype.addEventListeners;
Nav.prototype.clearEvents = Game.prototype.clearEvents;
Nav.prototype.play = Game.prototype.play;
Nav.prototype.keydown_event = Game.prototype.keydown_event;
Nav.prototype.keyup_event = Game.prototype.keyup_event;

Nav.prototype.getWorldState = function () {
    var line = [this.gameTimer.elapsed(),
                // ship
                this.ship.alive?1:0,
                Math.round(this.ship.position.x.toFixed(3)),
                Math.round(this.ship.position.y.toFixed(3)),
                // We want 3 decimals of precision
                Math.round(this.ship.velocity.x.toFixed(3)),
                Math.round(this.ship.velocity.y.toFixed(3)),
                Math.floor(this.ship.angle),
		// Math.round(this.segment.start.x * 1000),
                // Math.round(this.segment.start.y * 1000),
                // Math.round(this.segment.end.x * 1000),
                // Math.round(this.segment.end.y * 1000),
		// Math.round(this.next_segment.start.x * 1000),
                // Math.round(this.next_segment.start.y * 1000),
                // Math.round(this.next_segment.end.x * 1000),
                // Math.round(this.next_segment.end.y * 1000),
                this.score.pnts,
                // key state
                this.ship.thrust_flag?1:0,
                gamelib.TURN_CODES.indexOf(this.ship.turn_flag),
                // this.keyState.keys['thrust']?1:0,
                // this.keyState.keys['left']?1:0,
                // this.keyState.keys['right']?1:0,
                // this.keyState.keys['fire']?1:0
               ];

    // if (this.currentFrameEvents.length > 0) {
        line.push(this.ship.fullStoppedInTransition?1:0);
        line.push(this.currentFrameEvents);
    // } else if (this.ship.fullStoppedInTransition) {
    //     line.push(this.ship.fullStoppedInTransition?1:0);
    // }

    return line;
};

Nav.prototype.getKeyState = Game.prototype.getKeyState;

Nav.prototype.commonFixWorldStateForModel = Game.prototype.commonFixWorldStateForModel;

Nav.prototype.getWorldStateForModel = function () {
    var keys = this.getKeyState()
    var state = {time: this.gameTimer.elapsed(),
                 ship: {alive: this.ship.alive,
                        x: this.ship.position.x,
                        y: this.ship.position.y,
                        vx: this.ship.velocity.x,
                        vy: this.ship.velocity.y,
                        orientation: this.ship.angle,
                        // These keys are for compatibility with
                        // sf-module.lisp.
                        speed: this.ship.velocity.norm(),
                        'distance-from-fortress': 0,
                        vdir: 0
                       },
                 rectangle1: this.segment.corners,
                 'short-rectangle1': this.segment.shortCorners,
                 rectangle2: this.next_segment.corners,
                 'short-rectangle2': this.segment.shortCorners,
                 pnts: this.score.pnts,
                 keys: keys,
                 collisions: this.collisions
                 // events: this.currentFrameEvents
                };
    this.commonFixWorldStateForModel(state);
    return state;
};

Nav.prototype.recordEverything = Game.prototype.recordEverything;

Nav.prototype.addEvent = Game.prototype.addEvent;

Nav.prototype.penalize = Game.prototype.penalize;

Nav.prototype.reward = Game.prototype.reward;

Nav.prototype.monitor_ship_respawn = function () {
    if (this.ship.alive === false && this.ship.deathTimer.elapsed() >= 1000) {
        this.ship.reset();
        this.ship.fullStoppedInTransition = false;
        this.addEvent('ship-respawn');
    }
};

Nav.prototype.process_key_state = Game.prototype.process_key_state;

Nav.prototype.process_key_event = function (evt) {
    if (evt['type'] == 1) {
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.autoorient_flag = false;
            this.ship.turn_flag = evt['key'];
            // this.tickManager.setLastKeyPress();
        } else if (evt['key'] == 'thrust') {
            this.ship.autoorient_flag = false;
            this.ship.thrust_flag = true;
            // this.tickManager.setLastKeyPress();
        } else if (evt['key'] == 'flip') {
            if (this.config.ship.instantFlip)
                this.flip_ship();
            else
                this.ship.autoorient_flag = true;
            // this.tickManager.setLastKeyPress();
        }
    } else {
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.turn_flag = null;
        } else if (evt['key'] == 'thrust') {
            this.ship.thrust_flag = false;
        } else if (evt['key'] == 'flip') {
            if (!this.config.ship.instantFlip && !this.config.ship.tapToFlip)
                this.ship.autoorient_flag = false;
        }
    }
};

Nav.prototype.kill_ship = function () {
    if (this.ship.alive) {
        this.penalize(this.config.ship_death_penalty);
        this.ship.alive = false;
        this.shipDeaths += 1;
        this.ship.deathTimer.reset();
    }
};

Nav.prototype.move_ship = Game.prototype.move_ship;

Nav.prototype.reset_ship_full_stop_status = function () {
    this.ship.fullStoppedInTransition = false;
    // this.ship.enterTransitionVelocity = null;
}

Nav.prototype.flip_ship = function () {
    if (this.ship.velocity.norm() > 0.05) {
        console.log('norm', this.ship.velocity.norm());
        var a = Math.atan2(this.ship.velocity.y, this.ship.velocity.x);
        this.ship.angle = util.std_360(util.rad2deg(a)+180);
        this.addEvent('flip');
    }
}

Nav.prototype.update_ship = function () {
    if (this.ship.alive) {


        this.move_ship();

        // var in_seg1 = this.segment.contains(this.ship.position);
        // var in_seg2 = this.next_segment.contains(this.ship.position);

        var in_seg1 = this.segment.shortContains(this.ship.position);
        var in_seg2 = this.next_segment.shortContains(this.ship.position);
        var inside = in_seg1 || in_seg2;
        var insideTransition = in_seg1 && in_seg2;

        if (!inside) {
            this.addEvent('explode-rectangle');
            this.collisions.push('ship-rectangle');
            this.kill_ship();
        } else if (insideTransition &&
                   this.ship.lastVelocity.norm() > this.config.nav.stop_speed_threshold && //this.ship.velocity.norm() &&
                   this.ship.velocity.norm() <= this.config.nav.stop_speed_threshold) {
            if (!this.ship.fullStoppedInTransition) this.addEvent('show-stop-mark');
            this.ship.fullStoppedInTransition = true;
            this.addEvent('full-stop');
            // console.log('fullstop');
        }
    }
};

Nav.prototype.create_next_rectangle = function(prev_segment) {
    var phi = this.getNextRectAngle();
    var l = this.rect_length;
    var w = this.half_width;
    var begin = prev_segment.end.duplicate();
    var old_dir = prev_segment.direction();
    var theta = Math.atan2(old_dir.y,old_dir.x);
    var next_end_diff
        = V(l*Math.cos(phi+theta),l*Math.sin(phi+theta));
    return new Segment(begin,next_end_diff.add(begin),w,true);
};

Nav.prototype.segments_to_curved_path_points = function(seg1, seg2) {
    var v1 = this.segment.start.duplicate().sub(this.segment.end);
    var v2 = this.next_segment.end.duplicate().sub(this.next_segment.start);
    var a = util.angle_diff(v1.angle(),v2.angle());

    var seg1_sa = seg1.shortCorners[3].duplicate().sub(seg1.start).angle();
    var seg1_ea = seg1.shortCorners[0].duplicate().sub(seg1.start).angle();

    var seg2_sa = this.next_segment.shortCorners[2].duplicate().sub(this.next_segment.end).angle();
    var seg2_ea = this.next_segment.shortCorners[1].duplicate().sub(this.next_segment.end).angle();


    if (a < 0) {
        var transition_sa = this.next_segment.shortCorners[0].duplicate().sub(this.segment.end).angle();
        var transition_ea = this.segment.shortCorners[1].duplicate().sub(this.segment.end).angle();

        var outer_pt = lines_intersection_point(seg1.corners[3], seg1.shortCorners[2],
                                                seg2.shortCorners[3], seg2.corners[2]);

        var inner_pt = lines_intersection_point(this.segment.corners[0], this.segment.shortCorners[1],
                                                this.next_segment.corners[1], this.next_segment.shortCorners[0]);

        return {transition: [{tag: 'm', p: seg2.shortCorners[1]},
                             {tag: 'l', p: seg2.shortCorners[0]},
                             {tag: 'a', p: seg1.end, r: seg1.margin, sa: transition_sa, ea: transition_ea, ccw: true},
                             {tag: 'l', p: seg1.shortCorners[0]}],
                border: [{tag: 'm', p: seg1.shortCorners[3]},
                         {tag: 'l', p: seg1.shortCorners[2]},
                         {tag: 'at', p1: outer_pt[1], p2: seg2.shortCorners[3], r: seg2.margin},
                         {tag: 'l', p: seg2.shortCorners[2]},
                         {tag: 'a', p: seg2.end, r: seg2.margin, sa: seg2_sa, ea: seg2_ea, ccw:true},
                         {tag: 'l', p: inner_pt[1]},
                         {tag: 'l', p: seg1.shortCorners[0]},
                         {tag: 'm', p: seg1.shortCorners[3]},
                         {tag: 'a', p: seg1.start, r: seg1.margin, sa: seg1_sa, ea: seg1_ea}]};
    } else {
        var transition_sa = this.next_segment.shortCorners[3].duplicate().sub(this.segment.end).angle();
        var transition_ea = this.segment.shortCorners[2].duplicate().sub(this.segment.end).angle();

        var inner_pt = lines_intersection_point(this.segment.corners[3], this.segment.shortCorners[2],
                                                this.next_segment.shortCorners[3], this.next_segment.corners[2]);

        var outer_pt = lines_intersection_point(this.next_segment.corners[1], this.next_segment.shortCorners[0],
                                                this.segment.corners[0], this.segment.shortCorners[1]);

        return {transition: [{tag: 'm', p: seg2.shortCorners[2]},
                             {tag: 'l', p: seg2.shortCorners[3]},
                             {tag: 'a', p: seg1.end, r: seg1.margin, sa: transition_sa, ea: transition_ea},
                             {tag: 'l', p: seg1.shortCorners[3]}],
                border: [{tag: 'm', p: seg1.shortCorners[3]},
                         {tag: 'l', p: inner_pt[1]},
                         {tag: 'l', p: seg2.shortCorners[2]},
                         {tag: 'a', p: seg2.end, r: seg2.margin, sa: seg2_sa, ea: seg2_ea, ccw:true},
                         {tag: 'l', p: seg2.shortCorners[0]},
                         {tag: 'at', p1: outer_pt[1], p2: seg1.shortCorners[1], r: seg2.margin},

                         {tag: 'l', p: seg1.shortCorners[0]},
                         {tag: 'm', p: seg1.shortCorners[3]},
                         {tag: 'a', p: seg1.start, r: seg2.margin, sa: seg1_sa, ea: seg1_ea}]};
    }
}

Nav.prototype.update_rectangles = function() {
    if (this.ship.alive) {
        var in_seg1 = this.segment.shortContains(this.ship.position);
        var in_seg2 = this.next_segment.shortContains(this.ship.position);
        if (in_seg1 && in_seg2) {
            if (!this.in_transition) this.addEvent('enter-transition');
            this.in_transition = true;
        } else {
            if (this.in_transition) this.addEvent('leave-transition');
            this.in_transition = false;
        }

        //should probably switch the order of the update and the if statement
        //currently doesn't preserve the invariant that the ship is either in the green rectangle or not alive
        if (in_seg2 && !in_seg1) {
 	    // console.log("I'm in a new rectangle.");
            this.in_transition = false;
            this.segment = this.next_segment;
            this.segment.ghost = false;
            this.next_segment = this.create_next_rectangle(this.segment);
            this.track = this.segments_to_curved_path_points(this.segment, this.next_segment);

            if ((this.config.nav.stop_required && this.ship.fullStoppedInTransition) ||
                (!this.config.nav.stop_required && !this.ship.fullStoppedInTransition)) {
                this.reward(this.config.nav.enter_rectangle);
            }

            this.ship.startPosition.x = this.segment.start.x;
            this.ship.startPosition.y = this.segment.start.y;
            this.ship.startVelocity = this.segment.direction();
            this.ship.startVelocity.y = -this.ship.startVelocity.y;
            var vnorm = this.ship.startVelocity.norm();
            this.ship.startVelocity.x = this.ship.startVelocity.x / vnorm * this.config.nav.startSpeed;
            this.ship.startVelocity.y = this.ship.startVelocity.y / vnorm * this.config.nav.startSpeed;
            this.ship.startAngle = util.rad2deg(Math.atan2(-this.segment.direction().y,this.segment.direction().x));
            this.addEvent('leave-seg1', {stopped: this.ship.fullStoppedInTransition?1:0});
            this.addEvent('segment', {nextSegment: this.next_segment.dumpForLog(),
                                      trackPath: this.track});

            this.reset_ship_full_stop_status();
        }
    }
};

Nav.prototype.draw_score = Game.prototype.draw_score;

Nav.prototype.draw_path = function (path) {
    this.canvas.moveTo(path[0].x, path[0].y);
    for (var i=1; i<path.length; i++) {
        this.canvas.lineTo(path[i].x, path[i].y);
    }
}

Nav.prototype.number_path = function (path, color) {
    this.canvas.textAlign = 'center';
    this.canvas.textBaseline = 'middle';
    this.canvas.font = "12px sans-serif";
    for (var i=0; i<path.length; i++) {
        this.canvas.beginPath();
        this.canvas.arc(path[i].x, path[i].y, 10, 0, Math.PI*2, true);
        this.canvas.fillStyle = color;
        this.canvas.fill();
        this.canvas.fillStyle = "#FFFFFF";
        this.canvas.fillText((i+1).toString(), path[i].x, path[i].y);
    }
}

Nav.prototype.draw_path_lines = function () {
    this.canvas.save();
    this.canvas.lineWidth = 2.4;
    this.canvas.strokeStyle = "#00FF00";

    this.canvas.beginPath();
    this.draw_path(this.fat_inner);
    this.canvas.stroke();

    // this.canvas.strokeStyle = "#008800";
    this.canvas.beginPath();
    this.draw_path(this.fat_outer);
    this.canvas.stroke();

    // this.number_path(this.fat_inner, "#880000");
    // this.number_path(this.fat_outer, "#008800");

    // this.number_path(this.segment.corners, "#880000");
    // this.number_path(this.next_segment.corners, "#008800");

    this.canvas.restore();

}

Nav.prototype.draw_path_lines_with_circular_transition = function () {
    // this.canvas.beginPath();
    // this.canvas.arc(this.segment.end.x, this.segment.end.y,
    //                 55, 0, Math.PI*2);
    // this.canvas.strokeStyle = '#999999';
    // this.canvas.stroke();

    this.canvas.beginPath();
    // this.canvas.moveTo(this.segment.shortCorners[0].x,this.segment.shortCorners[0].y);
    // this.canvas.lineTo(this.segment.shortCorners[1].x,this.segment.shortCorners[1].y);
    // this.canvas.moveTo(this.segment.shortCorners[3].x,this.segment.shortCorners[3].y);
    // this.canvas.lineTo(this.segment.shortCorners[2].x,this.segment.shortCorners[2].y);

    // this.canvas.moveTo(this.next_segment.shortCorners[0].x,this.next_segment.shortCorners[0].y);
    // this.canvas.lineTo(this.next_segment.shortCorners[1].x,this.next_segment.shortCorners[1].y);
    // this.canvas.lineTo(this.next_segment.shortCorners[2].x,this.next_segment.shortCorners[2].y);
    // this.canvas.moveTo(this.next_segment.shortCorners[3].x,this.next_segment.shortCorners[3].y);


    this.canvas.save();


    var v1 = this.segment.start.duplicate().sub(this.segment.end);
    var v2 = this.next_segment.end.duplicate().sub(this.next_segment.start);
    var a = util.angle_diff(v1.angle(),v2.angle());
    // console.log(Math.round(a));
    if (a < 0) {
        // Draw transition
        this.canvas.beginPath();
        this.canvas.moveTo(this.next_segment.shortCorners[1].x,this.next_segment.shortCorners[1].y);
        this.canvas.lineTo(this.next_segment.shortCorners[0].x,this.next_segment.shortCorners[0].y);

        var sa = this.next_segment.shortCorners[0].duplicate().sub(this.segment.end).angle();
        var ea = this.segment.shortCorners[1].duplicate().sub(this.segment.end).angle();
        this.canvas.moveTo(this.next_segment.shortCorners[0].x, this.next_segment.shortCorners[0].y);
        this.canvas.arc(this.segment.end.x, this.segment.end.y, this.next_segment.margin, util.deg2rad(sa), util.deg2rad(ea), true);

        this.canvas.lineTo(this.segment.shortCorners[0].x,this.segment.shortCorners[0].y);

        this.canvas.strokeStyle = '#999999';
        this.canvas.stroke();

        this.canvas.beginPath();


        this.canvas.moveTo(this.segment.shortCorners[3].x, this.segment.shortCorners[3].y);
        this.canvas.lineTo(this.segment.shortCorners[2].x, this.segment.shortCorners[2].y);

        this.canvas.lineTo(this.segment.shortCorners[2].x, this.segment.shortCorners[2].y);
        // this.canvas.lineTo(this.next_segment.shortCorners[1].x, this.next_segment.shortCorners[1].y);

        var pt = lines_intersection_point(this.segment.corners[3], this.segment.shortCorners[2],
                                          this.next_segment.shortCorners[3], this.next_segment.corners[2]);

        this.canvas.arcTo(pt[1].x, pt[1].y,
                          this.next_segment.shortCorners[3].x, this.next_segment.shortCorners[3].y,
                          this.next_segment.margin
                          // this.segment.shortCorners[2].duplicate().sub(this.next_segment.shortCorners[1]).norm()
                         );

        this.canvas.lineTo(this.next_segment.shortCorners[2].x, this.next_segment.shortCorners[2].y);

        var sa = this.next_segment.shortCorners[2].duplicate().sub(this.next_segment.end).angle();
        var ea = this.next_segment.shortCorners[1].duplicate().sub(this.next_segment.end).angle();
        this.canvas.moveTo(this.next_segment.shortCorners[2].x, this.next_segment.shortCorners[2].y);
        this.canvas.arc(this.next_segment.end.x, this.next_segment.end.y, this.next_segment.margin, util.deg2rad(sa), util.deg2rad(ea), true);


        // this.canvas.lineTo(this.next_segment.corners[1].x, this.next_segment.corners[1].y);

        // calc intersection point
        var pt = lines_intersection_point(this.segment.corners[0], this.segment.shortCorners[1],
                                          this.next_segment.corners[1], this.next_segment.shortCorners[0]);
        this.canvas.lineTo(pt[1].x, pt[1].y);
        this.canvas.lineTo(this.segment.shortCorners[0].x, this.segment.shortCorners[0].y);

    } else {
        // Draw transition
        this.canvas.beginPath();
        this.canvas.moveTo(this.next_segment.shortCorners[2].x,this.next_segment.shortCorners[2].y);
        this.canvas.lineTo(this.next_segment.shortCorners[3].x,this.next_segment.shortCorners[3].y);

        var sa = this.next_segment.shortCorners[3].duplicate().sub(this.segment.end).angle();
        var ea = this.segment.shortCorners[2].duplicate().sub(this.segment.end).angle();
        this.canvas.moveTo(this.next_segment.shortCorners[3].x, this.next_segment.shortCorners[3].y);
        this.canvas.arc(this.segment.end.x, this.segment.end.y, this.next_segment.margin, util.deg2rad(sa), util.deg2rad(ea));

        this.canvas.lineTo(this.segment.shortCorners[3].x,this.segment.shortCorners[3].y);

        this.canvas.strokeStyle = '#999999';
        this.canvas.stroke();

        this.canvas.beginPath();



        this.canvas.moveTo(this.segment.shortCorners[3].x, this.segment.shortCorners[3].y);

        var pt = lines_intersection_point(this.segment.corners[3], this.segment.shortCorners[2],
                                          this.next_segment.shortCorners[3], this.next_segment.corners[2]);
        this.canvas.lineTo(pt[1].x, pt[1].y);

        this.canvas.lineTo(this.next_segment.shortCorners[2].x, this.next_segment.shortCorners[2].y);

        var sa = this.next_segment.shortCorners[2].duplicate().sub(this.next_segment.end).angle();
        var ea = this.next_segment.shortCorners[1].duplicate().sub(this.next_segment.end).angle();
        this.canvas.moveTo(this.next_segment.shortCorners[2].x, this.next_segment.shortCorners[2].y);
        this.canvas.arc(this.next_segment.end.x, this.next_segment.end.y, this.next_segment.margin, util.deg2rad(sa), util.deg2rad(ea), true);

        // this.canvas.lineTo(this.next_segment.corners[1].x, this.next_segment.corners[1].y);

        this.canvas.lineTo(this.next_segment.shortCorners[0].x, this.next_segment.shortCorners[0].y);

        var pt = lines_intersection_point(this.next_segment.corners[1], this.next_segment.shortCorners[0],
                                          this.segment.corners[0], this.segment.shortCorners[1]);

        // this.canvas.lineTo(pt[1].x, pt[1].y);

        this.canvas.arcTo(pt[1].x, pt[1].y,
                          this.segment.shortCorners[1].x, this.segment.shortCorners[1].y,
                          this.segment.margin
                          // this.segment.shortCorners[2].duplicate().sub(this.next_segment.shortCorners[1]).norm()
                         );
        // this.canvas.lineTo(this.segment.shortCorners[1].x, this.segment.shortCorners[1].y);
        this.canvas.lineTo(this.segment.shortCorners[0].x, this.segment.shortCorners[0].y);

    }
    // this.canvas.stroke();

    // this.canvas.beginPath();
    var sa = this.segment.shortCorners[3].duplicate().sub(this.segment.start).angle();
    var ea = this.segment.shortCorners[0].duplicate().sub(this.segment.start).angle();

    this.canvas.moveTo(this.segment.shortCorners[3].x, this.segment.shortCorners[3].y);
    this.canvas.arc(this.segment.start.x, this.segment.start.y, this.segment.margin, util.deg2rad(sa), util.deg2rad(ea));

    // this.canvas.arc(this.next_segment.end.x, this.next_segment.end.y, 55);

    this.canvas.lineWidth = 2.4;
    this.canvas.strokeStyle = "#00FF00";
    this.canvas.stroke();

    this.canvas.restore();

}

Nav.prototype.draw_track_pieces = function(pieces) {
    this.canvas.beginPath();
    for (let i=0; i<pieces.length; i++) {
        if (pieces[i].tag === 'a') {
            this.canvas.arc(pieces[i].p.x, pieces[i].p.y, pieces[i].r, util.deg2rad(pieces[i].sa), util.deg2rad(pieces[i].ea), pieces[i].ccw);
        } else if (pieces[i].tag === 'l') {
            this.canvas.lineTo(pieces[i].p.x, pieces[i].p.y);
        } else if (pieces[i].tag === 'm') {
            this.canvas.moveTo(pieces[i].p.x, pieces[i].p.y);
        } else if (pieces[i].tag === 'at') {
            this.canvas.arcTo(pieces[i].p1.x, pieces[i].p1.y,
                              pieces[i].p2.x, pieces[i].p2.y,
                              pieces[i].r);
        } else if (pieces[i].tag === 'c') {
            this.canvas.closePath();
        }
    }
}

Nav.prototype.draw_track = function() {
    // this.canvas.save();
    this.draw_track_pieces(this.track.transition);
    this.canvas.strokeStyle = '#999999';
    this.canvas.stroke();

    this.draw_track_pieces(this.track.border);
    this.canvas.lineWidth = 2.4;
    this.canvas.strokeStyle = "#00FF00";
    this.canvas.stroke();
    // this.canvas.restore();
}

function drawXMark (ctx, x, y) {
    // this.canvas.fillStyle = "#009900";
    // this.canvas.fillText('\u{2713}', x, y);
    var r = 15;

    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = "#990000";
    ctx.lineCap = 'round';
    ctx.lineWidth = 9;

    ctx.moveTo(x-r,y-r)
    ctx.lineTo(x+r,y+r)
    ctx.moveTo(x+r,y-r)
    ctx.lineTo(x-r,y+r)
    ctx.stroke();

    ctx.restore();
}

function drawCheckMark (ctx, x, y) {
    // this.canvas.fillStyle = "#990000";
    // ctx.fillText('\u{2717}', x, y);

    var r1 = 12, r2 = {x:22,y:30};
    var ofsx = -8, ofsy = 8;

    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = "#009900";
    ctx.lineCap = 'round';
    ctx.lineWidth = 9;

    ctx.moveTo(x-r1+ofsx,y-r1+ofsy)
    ctx.lineTo(x+ofsx,y+ofsy)
    ctx.lineTo(x+r2.x+ofsx,y-r2.y+ofsy)
    ctx.stroke();

    // ctx.beginPath();
    // ctx.arc(x,y,5,0,Math.PI*2);
    // ctx.fillStyle = '#FFFFFF';
    // ctx.fill();

    ctx.restore();
}

function drawShipThrust(ctx, x, y, angle) {
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x+Math.cos(util.deg2rad(angle))*-24,
                    y+Math.sin(util.deg2rad(angle))*-24);
    ctx.lineTo(x+Math.cos(util.deg2rad(angle))*-36,
                    y+Math.sin(util.deg2rad(angle))*-36);
    ctx.strokeStyle = '#FF0000';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x+Math.cos(util.deg2rad(angle))*-24,
                    y+Math.sin(util.deg2rad(angle))*-24);
    ctx.lineTo(x+Math.cos(util.deg2rad(angle))*-30,
                    y+Math.sin(util.deg2rad(angle))*-30);
    ctx.strokeStyle = '#FFCC00';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x+Math.cos(util.deg2rad(angle))*-24,
                    y+Math.sin(util.deg2rad(angle))*-24);
    ctx.lineTo(x+Math.cos(util.deg2rad(angle))*-25,
                    y+Math.sin(util.deg2rad(angle))*-25);
    ctx.strokeStyle = '#FFFFFF';
    ctx.stroke();

    ctx.lineCap = 'butt';
}

Nav.prototype.draw = function () {
    this.canvas.fillStyle = '#000000';
    this.canvas.fillRect(0, 0, 710, 626);

    this.canvas.save();
    // this.canvas.translate(0,-50);

    this.canvas.translate(-(this.ship.position.x-355), -(this.ship.position.y-313));

    this.draw_track();

    if (this.ship.fullStoppedInTransition) {
        this.canvas.textAlign = 'center';
        this.canvas.textBaseline = 'middle';
        this.canvas.font = "48px sans-serif";
        //this.canvas.fillStyle = "#FF00FF";
        if (this.config.nav.stop_required) {
            drawCheckMark(this.canvas, this.segment.end.x, this.segment.end.y);
        } else {
            drawXMark(this.canvas, this.segment.end.x, this.segment.end.y);
        }
    }

    this.canvas.lineWidth = 2;

    this.ship.draw(this.canvas);
    if (this.ship.thrust_flag && this.ship.alive)
        drawShipThrust(this.canvas, this.ship.position.x, this.ship.position.y, -this.ship.angle);


    this.canvas.restore();

    this.draw_score([{title: 'PNTS', value: this.score.pnts}]);
};

Nav.prototype.step_timers = function () {
    this.currentTick += 1;
    this.ship.deathTimer.tick(this.tinc);
};

Nav.prototype.update_time = Game.prototype.update_time;

Nav.prototype.get_realtime_tinc = Game.prototype.get_realtime_tinc;

Nav.prototype.step_one_tick = function (tinc) {
    this.tinc = tinc;
    this.collisions = [];
    this.currentFrameEvents = [];
    this.update_time();
    this.process_key_state();
    this.monitor_ship_respawn();
    
    this.update_ship();
    this.update_rectangles();
    this.stars ? this.stars.update(this.ship.velocity) : undefined;
    // console.log('alive', this.gameTimer.elapsed(), this.tinc, this.ship.deathTimer.elapsed(), this.ship.alive);
    
    this.recordEverything();
    this.step_timers();
};

Nav.prototype.is_game_over = Game.prototype.is_game_over;

Nav.prototype.requestRedraw = Game.prototype.requestRedraw;
Nav.prototype.cancelRedraw = Game.prototype.cancelRedraw;

Nav.prototype.tick = Game.prototype.tick;

Nav.prototype.calculate_bonus = Game.prototype.calculate_bonus;

Nav.prototype.cleanup_main = function () {
    if (this.config.nav.staircase) {
        if (this.shipDeaths > this.config.nav.staircase_increase_threshold) {
            var next = this.exp.rect_width+this.config.nav.staircase_delta;
            this.exp.rect_width = Math.min(next,this.config.nav.rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        } else if (this.shipDeaths < this.config.nav.staircase_decrease_threshold) {
            var next = this.exp.rect_width-this.config.nav.staircase_delta;
            this.exp.rect_width = Math.max(next,this.config.nav.min_rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        }
    }
};

Nav.prototype.cleanup_preamble = Game.prototype.cleanup_preamble;

Nav.prototype.cleanup_main = function () {
    if (this.config.nav.staircase) {
        if (this.shipDeaths > this.config.nav.staircase_increase_threshold) {
            var next = this.exp.rect_width+this.config.nav.staircase_delta;
            this.exp.rect_width = Math.min(next,this.config.nav.rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        } else if (this.shipDeaths < this.config.nav.staircase_decrease_threshold) {
            var next = this.exp.rect_width-this.config.nav.staircase_delta;
            this.exp.rect_width = Math.max(next,this.config.nav.min_rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        }
    }
}

Nav.prototype.cleanup_finish = function () {
    if (this.gui) { this.gui.destroy(); this.gui = null; }
    // Send it all to the server
    stats = {'bonus': this.bonus, 'points': this.score.pnts, 'rawPoints': this.score.raw_pnts};
    this.exp.lgEndScreen(stats);
};

Nav.prototype.cleanup = Game.prototype.cleanup;

Nav.prototype.reset_after_abandoned = function () {
    $('#abandon').css('display','none');

    this.init_basic_game_state();

    this.genStartSegments();
    this.tickManager.reset();
    this.tinc = 0;

    this.requestRedraw();
    this.addEventListeners();

    this.exp.lg('reset-after-abandoned',
                {'segment1': this.segment.dumpForLog(),
                 'segment2': this.next_segment.dumpForLog(),
                 'trackPath': this.track});

    this.recordEverything();
};

Nav.prototype.show_abandoned_message = Game.prototype.show_abandoned_message;

Nav.prototype.detect_abandoned = function () {
    return this.tickManager.last_tick_time - this.tickManager.last_keypress_time > this.config.abandon_threshold;
};


exports.Nav = Nav;
exports.drawXMark = drawXMark;
exports.drawCheckMark = drawCheckMark;
exports.drawShipThrust = drawShipThrust;

}) (typeof exports === 'undefined' ? this['spacetrack-roderick-v6']={}:exports);

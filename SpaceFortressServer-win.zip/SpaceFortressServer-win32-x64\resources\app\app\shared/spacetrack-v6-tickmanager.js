function TickManager () {
    TickManager.prototype.reset.call(this);
}

TickManager.prototype = {};

TickManager.prototype.tickPattern = [16,17,17];

TickManager.prototype.reset = function () {
    this.last_tick_time = null;
    this.last_keypress_time = null;
    this.now = null;
    this.time_debt = 0;
    this.ticks = 0;
}

TickManager.prototype.setLastKeyPress = function () {
    this.last_keypress_time = this.last_tick_time;
}

TickManager.prototype.getTimeIncrement = function () {
    this.last_tick_time = this.now;
    this.now = getCurrentTime();
    if (this.last_tick_time === null) {
        this.last_tick_time = this.now;
        this.last_keypress_time = this.now;
    }
    return this.now - this.last_tick_time;
}

TickManager.prototype.tick = function(stepCallback) {
    // Do as many game ticks that can fit in the time between the last
    // frame and this one. time_debt is carried over to the next
    // update.
    var delta = this.getTimeIncrement();
    // console.log('tick', ms, this.time_debt);
    var ms = delta + this.time_debt;
    var dur = 1000/60;
    // Limit the number of steps per screen update to 60.
    var count = 0;
    while (ms > 0 && count < 60) {
        stepCallback(this.tickPattern[(this.ticks+count)%this.tickPattern.length]);
        ms -= dur;
        count += 1;
    }
    // Limit the time debt to 1s.
    if (ms > 1000) ms = 1000;
    this.time_debt = ms;
    this.ticks += count;
};

module.exports = TickManager;

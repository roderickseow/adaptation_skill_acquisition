(function (exports) {

var TURN_CODES = [null, 'left', 'right'];

var POLAR_A_SCALE = 2;
var POLAR_R_SCALE = 1.3;

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;
  while (0 !== currentIndex) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

function deg2rad(deg) {
    return deg * Math.PI / 180;
}

function rad2deg(rad) {
    return rad / Math.PI * 180;
}

function angle_diff(angle1, angle2) {
    // It finally works--don't touch it!
    if (angle1 < 90) {
        if (angle2 > angle1+180) return 360-angle2 + angle1;
        else return angle1 - angle2;
    } else if (angle1 < 180) {
        if (angle2 > angle1+180) return 360-angle2 + angle1;
        else return angle1 - angle2;
    } else if (angle1 < 270) {
        if (angle2 < angle1-180) return -(angle2 + 360-angle1);
        else return angle1 - angle2;
    } else {
        if (angle2 < angle1-180) return -(angle2 + 360-angle1);
        else return angle1 - angle2;
    }
}

function cartesian_360(a) {
    a = mod(-a+90,360);
    if (a < 0) a += 360;
    return a;
}

function std_360(a) {
    a = mod(a,360)
    if (a < 0) a += 360;
    return a;
}

function std_angle(a) {
    a = mod(a, 360);
    if (a >= 180) a -= 360;
    else if (a <= -180) a += 360;
    return a;
}

function mod(x,y) {
    return ((x%y)+y)%y;
}

function dotProduct (v1, v2) {
    return v1.x * v2.x + v1.y * v2.y;
}

function projection(a, b) {
    return dotProduct(a,b) / b.norm();
}

function angle_to(v1, v2) {
    var a = Math.atan2(-(v2.y-v1.y),
                       v2.x-v1.x);
    if (a < 0) { a += Math.PI*2; }
    return rad2deg(a);
}

function Vector(x,y) {
    Object.call(this);
    this.x = x;
    this.y = y;
    return this;
}

function V(x,y) {
    return new Vector(x,y);
}

Vector.prototype = {};

Vector.prototype.add = function (v) {
    this.x += v.x;
    this.y += v.y;
    return this;
};

Vector.prototype.sub = function(v) {
  this.x -= v.x;
  this.y -= v.y;
  return this;
};

Vector.prototype.mul = function(v) {
  this.x *= v.x;
  this.y *= v.y;
  return this;
};

Vector.prototype.scalar_mult = function(alpha) {
  this.x *= alpha;
  this.y *= alpha;
  return this;
};

Vector.prototype.copy = function (v) {
    this.x = v.x;
    this.y = v.y;
};

Vector.prototype.angle = function () {
    return std_360(rad2deg(Math.atan2(this.y, this.x)));
};

Vector.prototype.duplicate = function() {
  return new Vector(this.x,this.y);
};

Vector.prototype.norm = function() {
  return Math.sqrt(Math.pow(this.x,2) + Math.pow(this.y,2));
};

Vector.prototype.normalize = function() {
  var norm = this.norm();
  if (norm > 0) {
    this.x /= norm;
    this.y /= norm;
  }
  return this;
};

Vector.prototype.eq = function(v) {
    return this.x === v.x && this.y === v.y;
};

Vector.prototype.polar = function(relative) {
    // var v= V(mod(rad2deg(Math.atan2(315-this.y, 355-this.x)),360)-180,
    //          Math.sqrt(Math.pow(355-this.x,2) + Math.pow(315-this.y,2)));

    // var v= V((mod(rad2deg(Math.atan2(315-this.y, 355-this.x)),360)-180) * POLAR_A_SCALE,
    //          Math.sqrt(Math.pow(355-this.x,2) + Math.pow(315-this.y,2)) * POLAR_R_SCALE);

    // var v= V((rad2deg(Math.atan2(315-this.y, 355-this.x))-180) * POLAR_A_SCALE,
    //          Math.sqrt(Math.pow(355-this.x,2) + Math.pow(315-this.y,2)) * POLAR_R_SCALE);

    var a = rad2deg(Math.atan2(315-this.y, 355-this.x));
    var ra = rad2deg(Math.atan2(315-relative.y, 355-relative.x));

    var v= V(360 + std_angle(angle_diff(a,ra)) * POLAR_A_SCALE,
             Math.sqrt(Math.pow(355-this.x,2) + Math.pow(315-this.y,2)) * POLAR_R_SCALE);

    return v;
}

function distance(v1, v2) {
    return Math.sqrt(Math.pow(v1.x - v2.x, 2) + Math.pow(v1.y - v2.y, 2));
}

function point_inside_rect(p, corners) {
    var i;
    for (i=0; i<corners.length; i++) {
        var nx, ny, dx, dy;
        nx = -(corners[(i+1)%corners.length].y - corners[i].y);
        ny =   corners[(i+1)%corners.length].x - corners[i].x;
        dx = p.x - corners[i].x;
        dy = p.y - corners[i].y;
        if (nx * dx + ny * dy < 0) {
            return false;
        }
    }
    return true;
}

function lines_intersect(a, b, c, d) {
    var den = ((b.x - a.x) * (d.y - c.y)) - ((b.y - a.y) * (d.x - c.x));
    var num1 = ((a.y - c.y) * (d.x - c.x)) - ((a.x - c.x) * (d.y - c.y));
    var num2 = ((a.y - c.y) * (b.x - a.x)) - ((a.x - c.x) * (b.y - a.y));

    if (den == 0) return num1 == 0 && num2 == 0;

    var r = num1 / den;
    var s = num2 / den;

    return (r >= 0 && r <= 1) && (s >= 0 && s <= 1);
}

var LINES_PARALLEL = 0;
var INTERSECTION_INSIDE = 1;
var LINES_COINCIDE = 2;
var INTERSECTION_OUTSIDE_SEG1 = 3;
var INTERSECTION_OUTSIDE_SEG2 = 4;
var INTERSECTION_OUTSIDE_BOTH = 5;

// http://paulbourke.net/geometry/lineline2d/
function lines_intersection_point(p1, p2, p3, p4) {
    var out;
    var eps = 0.000000000001;

    var denom  = (p4.y-p3.y) * (p2.x-p1.x) - (p4.x-p3.x) * (p2.y-p1.y);
    var numera = (p4.x-p3.x) * (p1.y-p3.y) - (p4.y-p3.y) * (p1.x-p3.x);
    var numerb = (p2.x-p1.x) * (p1.y-p3.y) - (p2.y-p1.y) * (p1.x-p3.x);

    if ( (-eps < numera && numera < eps) &&
         (-eps < numerb && numerb < eps) &&
         (-eps < denom  && denom  < eps) ) {
        out = new Vector((p1.x + p2.x) * 0.5, (p1.y + p2.y) * 0.5);
        return [LINES_COINCIDE, out];
    }

    if (-eps < denom  && denom  < eps) {
	return [LINES_PARALLEL, null];
    }

    var mua = numera / denom;
    var mub = numerb / denom;

    out = new Vector(p1.x + mua * (p2.x - p1.x),
                     p1.y + mua * (p2.y - p1.y));
    var out1 = mua < 0 || mua > 1;
    var out2 = mub < 0 || mub > 1;

    if ( out1 & out2) {
	return [INTERSECTION_OUTSIDE_BOTH, out];
    } else if ( out1) {
	return [INTERSECTION_OUTSIDE_SEG1, out];
    } else if ( out2) {
	return [INTERSECTION_OUTSIDE_SEG2, out];
    } else {
	return [INTERSECTION_INSIDE, out];
    }
}

function distance_from_line (point, start, end) {
    var seg = end.duplicate().sub(start);
    var pt = point.duplicate().sub(start);
    var seg_unit = seg.duplicate().normalize();
    var proj = dotProduct(pt, seg_unit);
    var closest = seg_unit.scalar_mult(proj).add(start);
    closest.sub(point);
    return closest.norm();
}

function distance_from_line_segment (point, start, end) {
    var seg = end.duplicate().sub(start);
    var pt = point.duplicate().sub(start);
    var seg_unit = seg.duplicate().normalize();
    var proj = dotProduct(pt, seg_unit);
    var closest;
    if (proj <= 0) {
        closest = start.duplicate();
    } else if (proj >= seg.norm()) {
        closest = end.duplicate();
    } else {
        closest = seg_unit.scalar_mult(proj).add(start);
    }

    closest.sub(point);

    return closest.norm();
}

function line_intersects_others(start, end, others) {
    for (var i=1; i<others.length; i++) {
        if (start.eq(others[i]) || start.eq(others[i-1]) ||
            end.eq(others[i]) || end.eq(others[i-1])) {
            // console.log('skip', start, end, others[i], others[i-1]);
            continue;
        }
        if (lines_intersect(start, end, others[i-1], others[i])) {
            // console.log('hit', start, end, others[i-1], others[i]);
            return true;
        }
    }
    return false;
}

exports.shuffle = shuffle;
exports.deg2rad = deg2rad;
exports.rad2deg = rad2deg;
exports.angle_diff = angle_diff;
exports.cartesian_360 = cartesian_360;
exports.std_360 = std_360;
exports.std_angle = std_angle;
exports.dotProduct = dotProduct;
exports.angle_to = angle_to;
exports.mod = mod;
exports.Vector = Vector;
exports.V = V;
exports.distance = distance;
exports.point_inside_rect = point_inside_rect;
exports.lines_intersection_point = lines_intersection_point;

exports.LINES_PARALLEL = LINES_PARALLEL;
exports.INTERSECTION_INSIDE = INTERSECTION_INSIDE;
exports.LINES_COINCIDE = LINES_COINCIDE;
exports.INTERSECTION_OUTSIDE_SEG1 = INTERSECTION_OUTSIDE_SEG1;
exports.INTERSECTION_OUTSIDE_SEG2 = INTERSECTION_OUTSIDE_SEG2;
exports.INTERSECTION_OUTSIDE_BOTH = INTERSECTION_OUTSIDE_BOTH;

exports.POLAR_R_SCALE = POLAR_R_SCALE;
exports.POLAR_A_SCALE = POLAR_A_SCALE;
exports.TURN_CODES = TURN_CODES;

}) (typeof exports === 'undefined' ? this['util']={}:exports);

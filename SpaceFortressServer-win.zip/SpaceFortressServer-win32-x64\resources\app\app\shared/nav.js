(function (exports) {

var util = typeof require === 'undefined' ? window.util:require("./util");
var gamelib = typeof require === 'undefined' ? window.game:require("./game");

var KEY_CODES = gamelib.KEY_CODES;

var lines_intersection_point = util.lines_intersection_point;
var point_inside_rect = util.point_inside_rect;

var Game = gamelib.Game;
var Ship = gamelib.Ship;
var V = util.V;
var Vector = util.Vector;
var Entity = gamelib.Entity;
var dotProduct = util.dotProduct;
var angle_to = util.angle_to;
var mod = util.mod;

function Segment(start,end,margin,ghost) {
    Entity.call(this);
    this.start = start;
    this.end = end;
    this.margin = margin;
    this.ghost = ghost;
    this.calcCorners();
    return this;
}

Segment.prototype.contains = function(pos) {
    var seg_dir = this.direction();
    var recentered_pos = pos.duplicate().sub(this.start)

    //At start point or close enough to cause roundoff errors?
    if (recentered_pos.norm() <= 0) {
        return true;
    }

    //Project current position onto main segment axis and check it is in bounds
    var par = dotProduct(seg_dir,recentered_pos) / seg_dir.norm();
    if (par < -this.margin || par > (seg_dir.norm()+this.margin)) {
        return false;
    } else {
        //Use Pythagorean theorem to find square of coordinate perpendicular to
        //segment direction
        var perp = Math.pow(recentered_pos.norm(),2) - Math.pow(par,2);
        if (perp > Math.pow(this.margin,2)) {
            return false;
        } else {
            return true;
        }
    }
}

Segment.prototype.copy = function() {
    // console.log('segment copy', this.start, this.end);
    return new Segment(this.start.duplicate(),this.end.duplicate(),this.margin,this.ghost);
}

Segment.prototype.calcCorners = function() {
    var seg_dir = this.direction();
    var par = seg_dir.normalize();
    par.scalar_mult(this.margin);

    var normal = V(seg_dir.y,-seg_dir.x);
    normal.normalize();
    normal.scalar_mult(this.margin);

    start1 = this.start.duplicate().add(normal).sub(par);
    start2 = this.start.duplicate().sub(normal).sub(par);
    end1 = this.end.duplicate().add(normal).add(par);
    end2 = this.end.duplicate().sub(normal).add(par);
    this.corners = [start1, end1, end2, start2];
}

Segment.prototype.draw = function(canvas) {
    canvas.save();
    // if (this.ghost) {
    //     canvas.strokeStyle = '#0000FF';
    // } else {
    //     canvas.strokeStyle = '#60FF60';
    // }
    canvas.strokeStyle = '#999999';
    canvas.lineWidth = 1.0;
    canvas.beginPath();
    canvas.moveTo(this.corners[0].x, this.corners[0].y);
    for (var i=1; i<this.corners.length; i++) {
        canvas.lineTo(this.corners[i].x, this.corners[i].y);
    }
    canvas.closePath();
    canvas.stroke();
    canvas.restore();
}

Segment.prototype.direction = function() {
    var retVal = this.end.duplicate();
    retVal.sub(this.start);
    return retVal;
}

Segment.prototype.width = function() {
    return 2*this.margin;
}

Segment.prototype.length = function() {
    return 2*this.margin+this.direction().norm();
}

/* Suppose we are working with a 'scissor' arrangement of two segments which share
   the same start point, the same length, and the same width, with some angle between
   their main axes.

   Define a 'non-cutting' line to be the line with the following properties:
   - It runs along an inner segment main edge (the edges that are parallel to the segment axis)
   - It starts at the end of an inner segment main edge closest to the shared start of the two segments
   - It ends at the 'cutting point'/point of intersection of the two inner edges

   Given the width of the two segments, the angle between their main axes, and the
   ratio of the length of a 'non-cutting' line to the length of a segment's main edge,
   find the length of a segment's main axis

   This is a case where a picture would be worth a lot :/

   Angle should be in radians

   It would be nice to put this in a geometry object, or perhaps an object that
   solved algebra problems in scissor situations */
function solveForScissorAxisLength(width,angle,ratio) {
    /*WLOG we can assume the start point is at the origin and one of the segments is parallel to the x-axis
      Express the inner segment edge that is NOT parallel to the x-axis as a line of the form ax+b*/
    var a = Math.abs(Math.tan(angle)); var b = -Math.abs(1/Math.cos(angle))*(width/2);
    var intersectionX = (width/2 - b) / a; //Solve ax+b for x when y = width/2
    var nonCuttingLineLength = intersectionX+width/2;

    //We want ratio = nonCuttingLineLength / (axisLength + width)
    return nonCuttingLineLength/ratio- width;

}

function Stars(center_pos) {

    var Star = function(pos,grid_x,grid_y) {
        this.x = pos.x;
        this.y = pos.y;
        this.r = 1+Math.floor(Math.random()*3),
        this.gx = grid_x;
        this.gy = grid_y;

        Star.prototype.draw = function(canvas) {
            canvas.fillStyle = '#EEEEEE';
            canvas.beginPath();
            canvas.arc(this.x, this.y, this.r, 0, 2*Math.PI, false);
            canvas.fill();
            canvas.fillStyle = '#000000';
        }

        Star.prototype.inside = function(xmin,xmax,ymin,ymax) {
            return (xmin <= (this.x-this.r)) & ((this.x+this.r) <= xmax) & (ymin <= (this.y-this.r)) & ((this.y+this.r) <= ymax);
        }

        Star.prototype.insideGrid = function (xmin,xmax,ymin,ymax) {
            return (xmin <= this.gx) & (this.gx <= xmax) & (ymin <= this.gy) & (this.gy <= ymax);
        }

        Star.prototype.update = function(motion) {
            this.x -= motion.x;
            this.y += motion.y;
        }

        Star.prototype.shift_grid_cell = function(dh,dv) {
            this.gx += dh;
            this.gy += dv;
        }

        Star.prototype.toString = function() {
            return 'star @' + this.gx + ',' + this.gy;
        }
    }

    var StarSet = new Set();
    //one star per starbox_size (px) x starbox_size (px) grid cell
    const starbox_size = 100;
    const grid_size = 15;
    const cx = center_pos.x;
    const cy = center_pos.y;

    //screen center starts in the middle of a grid cell
    var screen_center_x = 15;
    var screen_center_y = 15;

    var addStar = function(i,j,set) {
        var basex = cx-screen_center_x + starbox_size*(i-Math.floor(grid_size/2)),
            basey = cy-screen_center_y + starbox_size*(j-Math.floor(grid_size/2)),
            star_pos = V(basex + starbox_size*Math.random(),basey+starbox_size*Math.random());
        set.add(new Star(star_pos,i,j));
    }

    for (let i = 0; i < grid_size; i++) {
        for (let j = 0; j < grid_size; j++) {
            addStar(i,j,StarSet);
        }
    }

    var addBorderStars = function(vertical_sweep_x,horizontal_sweep_y) {
        if (vertical_sweep_x !== undefined) {
            for (let i = 1; i < grid_size - 1; i++) {
                addStar(vertical_sweep_x,i,StarSet);
            }
        }

        if (horizontal_sweep_y !== undefined) {
            for (let i = 1; i < grid_size - 1; i++) {
                addStar(i,horizontal_sweep_y,StarSet);
            }
        }

        if (vertical_sweep_x === 0 || horizontal_sweep_y === 0) {
            addStar(0,0,StarSet);
        }
        if (vertical_sweep_x === 0 || horizontal_sweep_y === grid_size-1) {
            addStar(0,grid_size-1,StarSet);
        }
        if (vertical_sweep_x === grid_size-1 || horizontal_sweep_y === 0) {
            addStar(grid_size-1,0,StarSet);
        }
        if (vertical_sweep_x === grid_size-1 || horizontal_sweep_y === grid_size-1) {
            addStar(grid_size-1,grid_size-1,StarSet);
        }
    }

    Stars.prototype.update = function(motion) {

        var delta_vertical = 0,
            delta_horizontal = 0,
            horizontal_sweep_y,
            vertical_sweep_x,
            i,
            entry;

        screen_center_x -= motion.x;
        screen_center_y += motion.y;

        if (screen_center_x < 0) {
            delta_horizontal = -1;
            vertical_sweep_x = grid_size-1;
        } else if (screen_center_x > starbox_size) {
            delta_horizontal = 1;
            vertical_sweep_x = 0;
        }

        if (screen_center_y < 0) {
            delta_vertical = -1;
            horizontal_sweep_y = grid_size-1;
        } else if (screen_center_y > starbox_size) {
            delta_vertical = 1;
            horizontal_sweep_y = 0;
        }

        StarSet.forEach(function (val) {
            val.shift_grid_cell(delta_horizontal,delta_vertical);
            val.update(motion);
        });

        addBorderStars(vertical_sweep_x,horizontal_sweep_y);

        for (var entry of StarSet) {
            if (! entry.insideGrid(0,grid_size-1,0,grid_size-1)) {
                StarSet.delete(entry);
            }
        }

        // console.log('Number of stars: ' + StarSet.size);
        screen_center_x = mod(screen_center_x, starbox_size);
        screen_center_y = mod(screen_center_y, starbox_size);

    }

    Stars.prototype.draw = function(canvas) {
        for (var entry of StarSet) {
            if (entry.inside(0,screen_width,0,screen_height)) {
                entry.draw(canvas);
            }
        }
    }
}

function Nav(exp, config, gnum) {
    Object.call(this);

    this.exp = exp;

    this.screen_id = 'nav';
    this.config = config;
    this.game_number = gnum;

    Game.prototype.init_basic_game_state.call(this);

    this.ship = new Ship(config);
    this.stars = config.stars ? new Stars(V(350,350)) : undefined;

    this.in_next_segment = false;

    return this;
}

Nav.prototype = {};

Nav.prototype.lengthFromWidth = function(width) {
    var min_angle = util.deg2rad(this.config.nav.min_angle);
    var max_angle = util.deg2rad(this.config.nav.max_angle);
    var maximizing_angle = Math.min(Math.abs(min_angle), Math.abs(Math.PI-max_angle));

    return solveForScissorAxisLength(width,maximizing_angle,0.55);
}

Nav.prototype.genStartSegments = function() {

    this.min_angle = util.deg2rad(this.config.nav.min_angle);
    this.max_angle = util.deg2rad(this.config.nav.max_angle);

    this.segment = new Segment(V(350,350),V(350+this.rect_length,350),this.half_width,false);
    var angle_range = this.max_angle - this.min_angle;
    var parity = 1-2*Math.floor(2*Math.random());
    var phi = (this.min_angle + Math.random()*angle_range)*parity;

    var begin = this.segment.end.duplicate();
    var margin = this.half_width;
    var old_dir = this.segment.direction();
    var theta = Math.atan2(old_dir.y,old_dir.x);
    var diff_x = this.rect_length*Math.cos(phi+theta);
    var diff_y = this.rect_length*Math.sin(phi+theta);
    var end = begin.duplicate().add(V(diff_x,diff_y));
    this.next_segment = new Segment(begin,end,margin,true);

    this.old_fat_inner = [];
    this.old_fat_outer = [];
    this.rectangles_to_lines(this.segment.start, this.segment.end, this.next_segment.end);
}

Nav.prototype.initCanvas = function (canvas, images) {
    this.canvas = canvas.getContext('2d');
};

Nav.prototype.coreInit = function () {
    if (!this.config.nav.staircase || !this.exp.rect_width || ! this.exp.rect_length) {
        this.exp.rect_width = this.config.nav.rect_width;
        this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);
    }

    this.half_width = this.exp.rect_width/2;
    this.rect_length = this.exp.rect_length;
    this.genStartSegments();

    this.last_tick_time = null;
    this.tinc = 0;

    this.exp.resetGameData(this.game_number);

    // Record game specific data
    this.exp.gameLogHeader({'type': this.config.game_type,
                            'version': 2,
                            'config': this.config,
                            'rect_width': 2*this.half_width,
                            'rect_length': this.rect_length,
                            'segment1': {'start': this.segment.start,
                                         'end': this.segment.end,
                                         'corners': this.segment.corners},
                            'segment2': {'start': this.next_segment.start,
                                         'end': this.next_segment.end,
                                         'corners': this.next_segment.corners}});
    this.recordEverything();

    this.exp.lg('start', {'n': this.game_number, 'rect_width': 2*this.half_width, 'rect_length': this.rect_length});
};

Nav.prototype.init = function () {
    $("#experiment_area").html('<div class="canvasarea"><canvas id="screen-canvas" width="' + this.config.screen_width + '" height="' + this.config.screen_height + '"></canvas></div>');

    this.initCanvas (document.getElementById('screen-canvas'), {});
    this.timer = window.setInterval($.proxy(this.tick, this), 33);
    this.addEventListeners();

    // this.canvas.lineWidth = 1.4;

    this.coreInit();
};

Nav.prototype.addEventListeners = Game.prototype.addEventListeners;
Nav.prototype.clearEvents = Game.prototype.clearEvents;
Nav.prototype.play = Game.prototype.play;
Nav.prototype.keydown_event = Game.prototype.keydown_event;
Nav.prototype.keyup_event = Game.prototype.keyup_event;

Nav.prototype.getWorldState = function () {
    var line = [this.gameTimer.elapsed(),
                // ship
                this.ship.alive?1:0,
                Math.round(this.ship.position.x*1000),
                Math.round(this.ship.position.y*1000),
                // We want 3 decimals of precision
                Math.round(this.ship.velocity.x * 1000),
                Math.round(this.ship.velocity.y * 1000),
                Math.floor(this.ship.angle),
		// Math.round(this.segment.start.x * 1000),
                // Math.round(this.segment.start.y * 1000),
                // Math.round(this.segment.end.x * 1000),
                // Math.round(this.segment.end.y * 1000),
		// Math.round(this.next_segment.start.x * 1000),
                // Math.round(this.next_segment.start.y * 1000),
                // Math.round(this.next_segment.end.x * 1000),
                // Math.round(this.next_segment.end.y * 1000),
                this.score.pnts,
                // key state
                this.ship.thrust_flag?1:0,
                gamelib.TURN_CODES.indexOf(this.ship.turn_flag),
                // this.keyState.keys['thrust']?1:0,
                // this.keyState.keys['left']?1:0,
                // this.keyState.keys['right']?1:0,
                // this.keyState.keys['fire']?1:0
               ];

    if (this.currentFrameEvents.length > 0) {
        line.push(this.currentFrameEvents);
    }

    return line;
};

Nav.prototype.getKeyState = Game.prototype.getKeyState;

Nav.prototype.commonFixWorldStateForModel = Game.prototype.commonFixWorldStateForModel;

Nav.prototype.getWorldStateForModel = function (next_clock) {
    var keys = this.getKeyState()
    var state = {time: next_clock,
                 'current-time': this.gameTimer.elapsed(),
                 ship: {alive: this.ship.alive,
                        x: this.ship.position.x,
                        y: this.ship.position.y,
                        vx: this.ship.velocity.x,
                        vy: this.ship.velocity.y,
                        orientation: this.ship.angle,
                        // These keys are for compatibility with
                        // sf-module.lisp.
                        speed: this.ship.velocity.norm(),
                        'distance-from-fortress': 0,
                        vdir: 0
                       },
                 rectangle1: this.segment.corners,
                 rectangle2: this.next_segment.corners,
                 pnts: this.score.pnts,
                 keys: keys,
                 collisions: this.collisions
                 // events: this.currentFrameEvents
                };
    this.commonFixWorldStateForModel(state);
    return state;
};

Nav.prototype.recordEverything = Game.prototype.recordEverything;

Nav.prototype.addEvent = Game.prototype.addEvent;

Nav.prototype.penalize = Game.prototype.penalize;

Nav.prototype.reward = Game.prototype.reward;

Nav.prototype.monitor_ship_respawn = function () {
    if (this.ship.alive === false && this.ship.deathTimer.elapsed() >= 1000) {
        this.ship.reset();
        this.addEvent('ship-respawn');
    }
};

Nav.prototype.process_key_state = Game.prototype.process_key_state;

Nav.prototype.process_key_event = function (evt) {
    if (evt['type'] == 1) {
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.turn_flag = evt['key'];
        } else if (evt['key'] == 'thrust') {
            this.ship.thrust_flag = true;
        } else if (evt['key'] == 'fire') {
            //this.fire_missile();
        }
    } else {
        if (evt['key'] == 'left' || evt['key'] == 'right') {
            this.ship.turn_flag = null;
        } else if (evt['key'] == 'thrust') {
            this.ship.thrust_flag = false;
        }
    }
};

Nav.prototype.kill_ship = function () {
    if (this.ship.alive) {
        this.penalize(this.config.ship_death_penalty);
        this.ship.alive = false;
        this.shipDeaths += 1;
        this.ship.deathTimer.reset();
    }
};

Nav.prototype.move_ship = Game.prototype.move_ship;

Nav.prototype.update_ship = function () {
    if (this.ship.alive) {
        this.move_ship();
        if (!this.segment.contains(this.ship.position) && !this.next_segment.contains(this.ship.position)) {
            this.addEvent('explode-rectangle');
            this.collisions.push('ship-rectangle');
            this.kill_ship();
        }
    }
};

Nav.prototype.create_next_rectangle = function(prev_segment) {
    var parity = 1-2*Math.floor(2*Math.random());
    var range = this.max_angle-this.min_angle;
    var phi = (Math.random()*range+this.min_angle)*parity;
    var l = this.rect_length;
    var w = this.half_width;
    var begin = prev_segment.end.duplicate();
    var old_dir = prev_segment.direction();
    var theta = Math.atan2(old_dir.y,old_dir.x);
    var next_end_diff
        = V(l*Math.cos(phi+theta),l*Math.sin(phi+theta));
    return new Segment(begin,next_end_diff.add(begin),w,true);
};

Nav.prototype.join_rectangles = function(a, b, c, ab_points, cb_points) {
    // var thickness = Math.random()*30+30;
    var ab_thickness = new Vector(-(b.y-a.y), b.x-a.x).normalize().scalar_mult(this.half_width);
    var cb_thickness = new Vector(-(b.y-c.y), b.x-c.x).normalize().scalar_mult(this.half_width);
    var ab = b.duplicate().sub(a);
    var cb = b.duplicate().sub(c);
    var dot = dotProduct(a.duplicate().sub(b), c.duplicate().sub(b));
    var ab_norm = ab.norm();
    var cb_norm = cb.norm();
    var ab_mid = ab.duplicate().normalize().scalar_mult(ab_norm/2).add(a);
    var cb_mid = cb.duplicate().normalize().scalar_mult(cb_norm/2).add(c);
    // var ab_points = [ab_mid.duplicate().sub(ab_thickness),
    //                  ab_mid.duplicate().add(ab_thickness),
    //                  b.duplicate().add(ab_thickness),
    //                  b.duplicate().sub(ab_thickness)];
    // var cb_points = [cb_mid.duplicate().sub(cb_thickness),
    //                  cb_mid.duplicate().add(cb_thickness),
    //                  b.duplicate().add(cb_thickness),
    //                  b.duplicate().sub(cb_thickness)];

    var out_pair1 = lines_intersection_point(ab_points[0], ab_points[1],
                                             cb_points[0], cb_points[1]);
    var out_pair2 = lines_intersection_point(ab_points[0], ab_points[1],
                                             cb_points[2], cb_points[3]);
    var in_pair1 = lines_intersection_point(ab_points[2], ab_points[3],
                                            cb_points[0], cb_points[1]);
    var in_pair2 = lines_intersection_point(ab_points[2], ab_points[3],
                                            cb_points[2], cb_points[3]);

    // return [[out_pair1[1], out_pair2[1]], [in_pair1[1], in_pair2[1]]];

    // console.log('dot', dot);
    // if (dot > 0) {
    //     return [out_pair1[1], in_pair2[1]];
    // } else {
    //     return [out_pair1[1], in_pair2[1]];
    // }
    var p1, p2;
    if (out_pair1[1].duplicate().sub(a).norm() > in_pair2[1].duplicate().sub(a).norm()) {
        // out really is the outside of the joint
        // console.log('out is outside');
        var end_pair1 = lines_intersection_point(ab_points[0], ab_points[1],
                                                 cb_points[0], cb_points[3]);
        // var end_pair2 = lines_intersection_point(cb_points[3], cb_points[2],
        //                                          ab_points[1], ab_points[2]);

        var end_pair3 = lines_intersection_point(ab_points[1], ab_points[2],
                                                 cb_points[0], cb_points[1]);
        var end_pair4 = lines_intersection_point(cb_points[1], cb_points[2],
                                                 ab_points[1], ab_points[2]);
        var end_pair5 = lines_intersection_point(cb_points[0], cb_points[3],
                                                 ab_points[1], ab_points[2]);

        p1 = out_pair2[1];
        p2 = in_pair1[1];
        var outer = [];
        var add = function (p) {
            if (p[0] === util.INTERSECTION_INSIDE) {
                outer.push(p[1])
            }
        };
        add(out_pair1);
        add(out_pair2);
        add(in_pair1);
        add(end_pair1);
        // add(end_pair2);
        add(end_pair3);
        add(end_pair4);
        add(end_pair5);
        if (!point_inside_rect(ab_points[1], cb_points)) outer.push(ab_points[1]);
        if (!point_inside_rect(ab_points[2], cb_points)) outer.push(ab_points[2]);
        if (!point_inside_rect(cb_points[3], ab_points)) outer.push(cb_points[3]);
        if (!point_inside_rect(cb_points[0], ab_points)) outer.push(cb_points[0]);

        var line = ab_points[1].duplicate().sub(ab_points[0]);

        var rel_angle = angle_to(b, ab_points[0]);

        outer.sort(function (v1, v2) {
            return mod(angle_to(b, v2)-rel_angle, 360) - mod(angle_to(b, v1)-rel_angle,360);
            // return distance(ab_points[0], a) > distance(ab_points[0], b);
            // return projection(line, a.duplicate().sub(ab_points[0])) > projection(line, b.duplicate().sub(ab_points[0]));
        });

        // for (var k=0; k<outer.length; k++) {
        //     console.log('angle', angle_to(b, outer[k]));
        // }


        // var inner = [in_pair1[1], in_pair2[1]];
        var inner = [in_pair2[1]];


        return [outer, inner];
    } else {
        // console.log('in is outside');
        // // in is the outside of the joint
        // p1 = out_pair1[1];
        // p2 = in_pair2[1];
        // return [[p1], [p2]];

        // out really is the outside of the joint
        // console.log('in is outside');
        var end_pair1 = lines_intersection_point(ab_points[0], ab_points[1],
                                                 cb_points[0], cb_points[3]);
        var end_pair2 = lines_intersection_point(cb_points[3], cb_points[2],
                                                 ab_points[1], ab_points[2]);

        var end_pair3 = lines_intersection_point(ab_points[2], ab_points[3],
                                                 cb_points[0], cb_points[3]);

        // var end_pair4 = lines_intersection_point(cb_points[0], cb_points[1],
        //                                          ab_points[1], ab_points[2]);

        var end_pair5 = lines_intersection_point(cb_points[0], cb_points[3],
                                                 ab_points[1], ab_points[2]);

        p1 = out_pair2[1];
        p2 = in_pair1[1];
        var outer = [];
        var add = function (p) {
            if (p[0] === util.INTERSECTION_INSIDE) {
                outer.push(p[1])
            }
        };
        add(in_pair2);
        add(in_pair1);
        add(out_pair2);
        add(end_pair1);
        add(end_pair2);
        add(end_pair3);
        // add(end_pair4);
        add(end_pair5);
        if (!point_inside_rect(ab_points[1], cb_points)) outer.push(ab_points[1]);
        if (!point_inside_rect(ab_points[2], cb_points)) outer.push(ab_points[2]);
        if (!point_inside_rect(cb_points[3], ab_points)) outer.push(cb_points[3]);
        if (!point_inside_rect(cb_points[0], ab_points)) outer.push(cb_points[0]);

        var line = ab_points[1].duplicate().sub(ab_points[0]);

        var rel_angle = angle_to(b, cb_points[2]);

        outer.sort(function (v1, v2) {
            return mod(angle_to(b, v1)-rel_angle,360) - mod(angle_to(b, v2)-rel_angle, 360);
            // return distance(ab_points[0], a) > distance(ab_points[0], b);
            // return projection(line, a.duplicate().sub(ab_points[0])) > projection(line, b.duplicate().sub(ab_points[0]));
        });

        // for (var k=0; k<outer.length; k++) {
        //     console.log('angle', angle_to(b, outer[k]));
        // }


        // var inner = [in_pair1[1], in_pair2[1]];
        var inner = [out_pair1[1]];


        return [inner, outer];
    }
}

Nav.prototype.rectangles_to_lines = function(a, b, c) {
    var path = [a,b,c];
    // var start_thick = thickenize(path[0], path[1], this.half_width);
    // var end_thick = thickenize(path[path.length-1], path[path.length-2], this.half_width);
    var start_thick = this.segment.corners;
    var end_thick = this.next_segment.corners;

    this.fat_inner = [start_thick[3],
                      start_thick[0]];
    this.fat_outer = [start_thick[3]];

    var pair = this.join_rectangles(a, b, c, this.segment.corners, this.next_segment.corners);
    this.fat_inner = this.fat_inner.concat(pair[0]);
    this.fat_outer = this.fat_outer.concat(pair[1]);

    this.fat_inner.push(end_thick[1]);
    this.fat_outer.push(end_thick[2]);
    this.fat_outer.push(end_thick[1]);
};

Nav.prototype.update_rectangles = function() {
    if (this.ship.alive) {
        var in_seg1 = this.segment.contains(this.ship.position);
        var in_seg2 = this.next_segment.contains(this.ship.position);
        if (in_seg2) {
            if (!this.in_next_segment) this.addEvent('enter-seg2');
            this.in_next_segment = true;
        } else {
            if (this.in_next_segment) this.addEvent('leave-seg2');
            this.in_next_segment = false;
        }
        //should probably switch the order of the update and the if statement
        //currently doesn't preserve the invariant that the ship is either in the green rectangle or not alive
        if (in_seg2 && !in_seg1) {
 	    // console.log("I'm in a new rectangle.");
            this.in_next_segment = false;
            this.segment = this.next_segment;
            this.segment.ghost = false;
            this.next_segment = this.create_next_rectangle(this.segment);
            this.reward(this.config.nav.enter_rectangle);

            this.ship.startPosition.x = this.segment.start.x;
            this.ship.startPosition.y = this.segment.start.y;
            this.ship.startVelocity = this.segment.direction();
            this.ship.startVelocity.y = -this.ship.startVelocity.y;
            this.ship.startVelocity.normalize();
            this.ship.startAngle = util.rad2deg(Math.atan2(-this.segment.direction().y,this.segment.direction().x));
            this.addEvent('leave-seg1');
            this.addEvent('segment', {'start': this.next_segment.start,
                                      'end': this.next_segment.end,
                                      'corners': this.next_segment.corners});

            this.old_fat_inner = this.fat_inner;
            this.old_fat_outer = this.fat_outer;

            this.rectangles_to_lines(this.segment.start, this.segment.end, this.next_segment.end);
        }
    }
};

Nav.prototype.draw_score = Game.prototype.draw_score;

Nav.prototype.draw_path = function (path) {
    this.canvas.moveTo(path[0].x, path[0].y);
    for (var i=1; i<path.length; i++) {
        this.canvas.lineTo(path[i].x, path[i].y);
    }
}

Nav.prototype.number_path = function (path, color) {
    this.canvas.textAlign = 'center';
    this.canvas.textBaseline = 'middle';
    this.canvas.font = "12px sans-serif";
    for (var i=0; i<path.length; i++) {
        this.canvas.beginPath();
        this.canvas.arc(path[i].x, path[i].y, 10, 0, Math.PI*2, true);
        this.canvas.fillStyle = color;
        this.canvas.fill();
        this.canvas.fillStyle = "#FFFFFF";
        this.canvas.fillText((i+1).toString(), path[i].x, path[i].y);
    }
}

Nav.prototype.draw_path_lines = function () {
    this.canvas.save();
    this.canvas.lineWidth = 2.4;
    this.canvas.strokeStyle = "#00FF00";

    this.canvas.beginPath();
    this.draw_path(this.fat_inner);
    this.canvas.stroke();

    // this.canvas.strokeStyle = "#008800";
    this.canvas.beginPath();
    this.draw_path(this.fat_outer);
    this.canvas.stroke();

    // this.number_path(this.fat_inner, "#880000");
    // this.number_path(this.fat_outer, "#008800");

    // this.number_path(this.segment.corners, "#880000");
    // this.number_path(this.next_segment.corners, "#008800");

    this.canvas.restore();

}

Nav.prototype.draw = function () {
    this.canvas.clearRect(0, 0, 710, 626);

    this.canvas.save();
    this.canvas.translate(0,-50);

    this.canvas.translate(-(this.ship.position.x-355), -(this.ship.position.y-313));



    this.stars ? this.stars.draw(this.canvas) : undefined;
    this.segment.draw(this.canvas);
    this.next_segment.draw(this.canvas);
    this.draw_path_lines();
    this.ship.draw(this.canvas);



    this.canvas.restore();

    this.draw_score([{title: 'PNTS', value: this.score.pnts}]);
};

Nav.prototype.step_timers = function () {
    this.currentTick += 1;
    this.ship.deathTimer.tick(this.tinc);
};

Nav.prototype.update_time = Game.prototype.update_time;

Nav.prototype.get_realtime_tinc = Game.prototype.get_realtime_tinc;

Nav.prototype.step_one_tick = function (tinc) {
    this.tinc = tinc;
    this.collisions = [];
    this.currentFrameEvents = [];
    this.update_time();
    this.process_key_state();
    this.monitor_ship_respawn();
    
    this.update_ship();
    this.update_rectangles();
    this.stars ? this.stars.update(this.ship.velocity) : undefined;
    // console.log('alive', this.gameTimer.elapsed(), this.tinc, this.ship.deathTimer.elapsed(), this.ship.alive);
    
    this.recordEverything();
    this.step_timers();
};

Nav.prototype.is_game_over = Game.prototype.is_game_over;

Nav.prototype.tick = Game.prototype.tick;

Nav.prototype.calculate_bonus = Game.prototype.calculate_bonus;

Nav.prototype.cleanup_main = function () {
    if (this.config.nav.staircase) {
        if (this.shipDeaths > this.config.nav.staircase_increase_threshold) {
            var next = this.exp.rect_width+this.config.nav.staircase_delta;
            this.exp.rect_width = Math.min(next,this.config.nav.rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        } else if (this.shipDeaths < this.config.nav.staircase_decrease_threshold) {
            var next = this.exp.rect_width-this.config.nav.staircase_delta;
            this.exp.rect_width = Math.max(next,this.config.nav.min_rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        }
    }
};

Nav.prototype.cleanup_preamble = Game.prototype.cleanup_preamble;

Nav.prototype.cleanup_main = function () {
    if (this.config.nav.staircase) {
        if (this.shipDeaths > this.config.nav.staircase_increase_threshold) {
            var next = this.exp.rect_width+this.config.nav.staircase_delta;
            this.exp.rect_width = Math.min(next,this.config.nav.rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        } else if (this.shipDeaths < this.config.nav.staircase_decrease_threshold) {
            var next = this.exp.rect_width-this.config.nav.staircase_delta;
            this.exp.rect_width = Math.max(next,this.config.nav.min_rect_width);
            this.exp.rect_length = this.lengthFromWidth(this.exp.rect_width);

        }
    }
}

Nav.prototype.cleanup_finish = function () {
    // Send it all to the server
    stats = {'bonus': this.bonus, 'points': this.score.pnts, 'rawpnts': this.score.raw_pnts};
    this.exp.gameLogFooter(this.game_number, stats);
    this.exp.lg('end', stats);
};

Nav.prototype.cleanup = Game.prototype.cleanup;

exports.Nav = Nav;

}) (typeof exports === 'undefined' ? this['nav']={}:exports);

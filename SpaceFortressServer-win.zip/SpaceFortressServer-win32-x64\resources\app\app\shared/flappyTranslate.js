// Code to translate from sf space to flappy space

(function (exports) {
var util = typeof require === 'undefined' ? window.util:require('./util');
var V = util.V;
var TURN_CODES = util.TURN_CODES;

function FlappyTranslate () {
    this.ship = {};
    this.ship.x = 0;
    this.ship.y = 0;
    this.ship.orientation = 0;
    this.ship.vx = 0;
    this.ship.vy = 0;
    this.ship.collisionEllipseX = 0;
    this.ship.collisionEllipseY = 0;
    //
    this.fortress = {};
    this.fortress.x = 0;
    this.fortress.y = 0;
    this.fortress. orientation = 0;
    //
    this.missiles = [];
    this.shells = [];
    // Do a little dance to reduce garbage collection
    var len = 12;
    this.ceilingPoints = Array(len);
    this.hillPoints = Array(len);
    // for (let i=0; i<len; i++) {
    //     this.ceilingPoints[i] = {x:0,y:0};
    //     this.hillPoints[i] = {x:0,y:0};
    // }
    this.backgroundOffset = 0;
    this.backgroundVelocity = 0;
    //
    return this;
}

FlappyTranslate.prototype = {};

FlappyTranslate.prototype.polarVelocity = function (p, v, relative) {
    var p1 = p.polar(relative);
    var tmp = p.duplicate();
    tmp.x += v.x;
    tmp.y -= v.y;
    var p2 = tmp.polar(relative);
    p2.sub (p1);
    return p2;
};

FlappyTranslate.prototype.getCollisionEllipse = function (p, radius, relative) {
    var a = Math.atan2 (315-p.y, 355-p.x);
    var p1 = V(Math.cos(a) * radius, Math.sin(a) * radius);
    var p2 = V(-1,-1).mul(p1);
    var p3 = V(Math.cos(a+Math.PI/4) * radius, Math.sin(a+Math.PI/4) * radius);
    var p4 = V(-1,-1).mul(p3);
    p1.add(p);
    p2.add(p);
    p3.add(p);
    p4.add(p);
    p1 = p1.polar(relative);
    p2 = p2.polar(relative);
    p3 = p3.polar(relative);
    p4 = p4.polar(relative);
    return V(util.distance(p3,p4), util.distance(p1,p2))
};

FlappyTranslate.prototype.update = function (game) {
    var ofsy = 140;
    var relative = game.ship.position;
    var missiles = [], shells = [];
    var i;

    // var ship_polar = game.ship.position.polar (relative);
    var ship_polar = V(235,315).polar (relative);
    var ship_pos = game.ship.position.polar (relative);
    // console.log('ship', game.ship.position, 'polar', ship_polar);

    var ship_polar_vel;
    if (game.ship.alive) {
        ship_polar_vel = this.polarVelocity (game.ship.position, game.ship.velocity, relative);
    } else {
        ship_polar_vel = V(0,0);
    }
    var ship_collision_ellipse = this.getCollisionEllipse(game.ship.position, game.ship.collision_radius, game.ship.position);

    // FIXME: reuse the list
    this.missiles = [];
    for (i=0; i<game.missiles.length; i++) {
        var p = game.missiles[i].position.polar (relative);
        var v = this.polarVelocity (game.missiles[i].position, game.missiles[i].velocity, relative);
        this.missiles.push({x: p.x,
                       y: p.y+ofsy,
                       vx: v.x,
                       vy: v.y,
                       orientation: util.cartesian_360(util.angle_diff (game.missiles[i].angle,
                                                                        util.angle_to (game.missiles[i].position, game.fortress.position)))});
    }
    // FIXME: reuse the list
    this.shells = [];
    for (i=0; i<game.shells.length; i++) {
        var p = game.shells[i].position.polar (relative);
        var v = this.polarVelocity (game.shells[i].position, game.shells[i].velocity, relative);
        var e = this.getCollisionEllipse (game.shells[i].position, game.shells[i].collision_radius, relative);
        this.shells.push({x: p.x,
                          y: p.y+ofsy,
                          vx: v.x,
                          vy: v.y,
                          orientation: util.cartesian_360(util.angle_diff (game.shells[i].angle,
                                                                           util.angle_to (game.shells[i].position, game.fortress.position))),
                          'collision-ellipse-x': e.x,
                          'collision-ellipse-y': e.y
                         });
    }

    var start = util.mod(ship_polar.x, 120);
    var idx = 0;
    for (let i=0; i<6; i++) {
        var x1 = start + i * 120;
        var x2 = x1 + 60;
        // trough
        if (x1 > 0 && x1 < 720) {
            this.hillPoints[idx] = {x: x1, y: 277+ofsy};
            this.ceilingPoints[idx] = {x: x1, y: 44 + 11+ofsy};
            idx += 1;
        }
        // peak
        if (x2 > 0 && x2 < 720) {
            this.hillPoints[idx] = {x: x2, y: 277 - 49+ofsy};
            this.ceilingPoints[idx] = {x: x2, y: 44+ofsy};
            idx += 1;
        }
    }
    this.hillPoints.length = idx;
    this.ceilingPoints.length = idx;

    this.backgroundOffset = util.mod(ship_polar.x, 120);
    this.backgroundVelocity = -ship_polar_vel.x;
    this.ship.x = 360;
    this.ship.y = ship_pos.y+ofsy,
    this.ship.vx = 0;
    this.ship.vy = ship_polar_vel.y;
    this.ship.orientation = util.cartesian_360(util.angle_diff (game.ship.angle,
                                                                util.angle_to (game.ship.position, game.fortress.position)));
    this.ship.collisionEllipseX = ship_collision_ellipse.x;
    this.ship.collisionEllipseY = ship_collision_ellipse.y;

    this.fortress.x = 360;
    this.fortress.y = ofsy;
    this.fortress.orientation =  270;
};

FlappyTranslate.prototype.getWorldStateForWeb = function (game) {
    var missiles = [], shells = [];
    var i;

    for (i=0; i<this.missiles.length; i++) {
        missiles.push([Math.round(this.missiles[i].x*1000), Math.round(this.missiles[i].y*1000), Math.round(this.missiles[i].orientation * 10)
                      ]);
    }

    for (i=0; i<this.shells.length; i++) {
        shells.push([Math.round(this.shells[i].x*1000), Math.round(this.shells[i].y*1000), Math.round(this.shells[i].orientation * 10)
                    ]);
    }

    var line = [game.gameTimer.elapsed(),
                // ship
                game.ship.alive?1:0,
                Math.round(this.ship.y*1000),
                // We want 2 decimals of precision
                Math.round(this.backgroundOffset * 1000),
                Math.round(this.backgroundVelocity * 1000),
                Math.round(this.ship.vy * 1000),
                Math.floor(this.ship.orientation * 10),
                // fortress
                game.fortress.alive?1:0,
                // missiles
                missiles,
                // shells
                shells,
                // score
                game.score.pnts,
                game.score.vulnerability,
                // key state
                game.ship.thrust_flag?1:0,
                TURN_CODES.indexOf(game.ship.turn_flag)
               ];

    if (game.currentFrameEvents.length > 0) {
        line.push(game.currentFrameEvents);
    }

    return line;
};

FlappyTranslate.prototype.getWorldState = function (game) {
    var line = {'time': game.gameTimer.elapsed(),
                'background-offset': this.backgroundOffset,
                'background-velocity': this.backgroundVelocity,

                'ceiling-points': this.ceilingPoints,
                'hill-points': this.hillPoints,
                // ship
                'ship': {'alive': game.ship.alive,
                         'x': this.ship.x,
                         'y': this.ship.y,
                         'vx': -this.backgroundVelocity,
                         'vy': this.ship.vy,
                         'orientation': this.ship.orientation,
                         'collision-ellipse-x': this.ship.collisionEllipseX,
                         'collision-ellipse-y': this.ship.collisionEllipseY,
                        },
                'fortress': {'alive': game.fortress.alive,
                             'x': this.fortress.x,
                             'y': this.fortress.y,
                             'orientation': this.fortress.orientation},
                'missiles': this.missiles,
                'shells': this.shells,
                'rawpnts': game.score.raw_pnts,
                'pnts': game.score.pnts,
                'vlner': game.score.vulnerability,
                'keys': game.getKeyState(),
                'events': game.currentFrameEvents};
    return line;
};

FlappyTranslate.prototype.getWorldStateForModel = function (game, next_clock) {
    var state = this.getWorldState(game);
    game.commonFixWorldStateForModel(state);
    // backwards compatibility
    delete state['events'];
    state['current-time'] = state['time'];
    state['time'] = next_clock
    state['isomorph'] = 'flappy';
    state['game'] = 'fortress';
    state['active'] = true;

    state['ship']['speed'] = Math.abs(state['ship']['vy']);
    state['ship']['distance-from-fortress'] = state['ship']['y'] - 23 - 140;
    state['ship']['vdir'] = 0;
    state['ship']['angle'] = 0;

    return state;
};

exports.FlappyTranslate = FlappyTranslate;

}) (typeof exports === 'undefined' ? this['flappyTranslate']={}:exports);

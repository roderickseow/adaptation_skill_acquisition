var app = require('electron').remote.app;
var dialog = require('electron').remote.dialog;
var path = require('path');
var settings = require('electron-settings');
var server = require('./server');
var dat = require('./dat.gui.min');
var configs = require('./shared/config');
var lbc = require('./loopbackClient');

var g_gui;
var g_configs = server.configs;

var flappyImages = {};

function loadImage(name) {
    flappyImages[name] = new Image();
    flappyImages[name].src = "shared/sprites/"+name+".png";

}

function loadImages() {
    loadImage('bird');
    loadImage('ceiling');
    loadImage('hills');
    loadImage('tube-top');
    loadImage('tube-middle');
    loadImage('egg');
    loadImage('hatchedegg');
    loadImage('nest');
    loadImage('bricks');
    loadImage('darkbricks');
    loadImage('scoreboard');
    loadImage('cloud');
    loadImage('pedestal');
    loadImage('topclouds');
    loadImage('lightning');
    loadImage('scorchedbird');
    loadImage('deadbird');

    flappyImages['bg'] = new Image();
    flappyImages['bg'].src = "shared/sprites/background.png";
}

function addTab(name) {
    var tabbut = name.toString()+'-tab-button';
    var tabarea = name.toString()+'-tab-area';
    var butdom = document.createElement('span');
    var alert = document.createElement('span');
    alert.setAttribute('class', 'alert');
    alert.setAttribute('id', name + '_alert');
    alert.innerHTML = '1';

    butdom.setAttribute('id', tabbut);
    butdom.classList.add('tab');
    butdom.innerHTML = name.toString();
    butdom.appendChild(alert);
    butdom.classList.add('hiddentab');

    var areadom = document.createElement('div');
    areadom.setAttribute('id', tabarea);
    areadom.classList.add("tab-area");
    areadom.style.display = 'none';

    butdom.addEventListener('click', function () {activateTabDom(butdom, areadom);});

    document.getElementById('tab-buttons').appendChild(butdom);
    document.getElementById('tab-area').appendChild(areadom);
}

function renameTab(oldName, newName) {
    var but = document.getElementById(oldName + '-tab-button');
    var area = document.getElementById(oldName + '-tab-area');

    but.setAttribute('id', newName + '-tab-button');
    but.innerHTML = newName.toString();
    area.setAttribute('id', newName + '-tab-area');
}

function delTab(name) {
    var but = document.getElementById(name + '-tab-button');
    var area = document.getElementById(name + '-tab-area');
    but.parentNode.removeChild(but);
    area.parentNode.removeChild(area);
}

function activateTab(name) {
    var tabbut = name.toString()+'-tab-button';
    var tabarea = name.toString()+'-tab-area';
    activateTabDom(document.getElementById(tabbut),
                   document.getElementById(tabarea));
}

function activateTabDom(butdom, areadom) {
    var buts = document.querySelectorAll('span.tab');
    var area = document.querySelectorAll('div.tab-area');
    for (var i=0; i<buts.length; i++) {
        buts[i].classList.remove('activetab');
        buts[i].classList.add('hiddentab');
    }
    for (var i=0; i<area.length; i++) {
        area[i].style.display = 'none';
    }
    butdom.classList.add('activetab');
    areadom.style.display = 'block';
    butdom.children[0].innerHTML = '0';
    butdom.children[0].style.visibility = 'hidden';
}

function logMsg (name, msg, type) {
    var time = new Date().toLocaleTimeString();
    if (type === 'error') {
        document.getElementById(name + '-log').innerHTML += time + ' | <span class="error">' + msg + '\n' + '</span>';
        var tabarea = document.getElementById(name.toString()+'-tab-area');
        if (tabarea.style.display === 'none') {
            var a = document.getElementById(name.toString()+'_alert');
            a.innerHTML = parseInt(a.innerHTML)+1;
            a.style.visibility = 'visible';
        }
    } else {
        document.getElementById(name + '-log').innerHTML += time + ' | ' + msg + '\n';
    }
}

function GUIClient (socket, name, opts) {
    server.Client.call(this, socket, name, {dataPath: settings.get('datadir'),
                                            condition: settings.get('condition'),
                                            logFormat: settings.get('logFormat'),
                                            lineEnding: opts.lineEnding});
}

GUIClient.prototype = Object.create(server.Client.prototype, {
    constructor: {
        value: GUIClient,
        enumerable: false
    }});

GUIClient.prototype.createTab = function () {
    addTab(this.name);
    activateTab(this.name);

    var tabarea = document.getElementById(this.name + '-tab-area');
    tabarea.innerHTML = '<div id="'+this.name+'-title" class="title">'+this.name+'</div><canvas class="game" id="'+this.name+'-canvas" width="710px" height="626px"></canvas><pre id="'+this.name+'-log"></pre>';
    this.canvas = document.getElementById(this.name + '-canvas');
    this.log = document.getElementById(this.name + '-log');
};

GUIClient.prototype.updateTab = function (oldName, newName) {
        renameTab (oldName, newName);
        this.canvas.setAttribute ('id', newName + '-canvas');
        this.log.setAttribute ('id', newName + '-log');
        var title = document.getElementById(oldName + '-title');
        title.setAttribute('id', newName + '-title');
        title.innerHTML = newName;
};

GUIClient.prototype.logMsg = function (name, msg) {
    logMsg(name, msg);
};

GUIClient.prototype.drawScoreScreen = function () {
        var ctx = this.canvas.getContext('2d');
        ctx.clearRect(0, 0, 710, 626);
        ctx.font = "16px sans-serif";
        ctx.fillStyle = "#FFFF00";
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText("Raw Points: " + this.game.score.raw_pnts.toString(), 355, 313);
};

GUIClient.prototype.drawGameNumber = function () {
        var ctx = this.canvas.getContext('2d');
        ctx.clearRect(0, 0, 710, 626);
        ctx.font = "16px sans-serif";
        ctx.fillStyle = "#FFFF00";
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText("Game " + this.gnum.toString(), 355, 313);
};

GUIClient.prototype.initGameCanvas = function () {
    this.game.initCanvas (this.canvas, flappyImages);
    if (!this.drawing) this.drawGameNumber();
};

GUIClient.prototype.drawingChanged = function () {
    if (this.drawing) {
        this.game.draw();
    } else {
        this.drawGameNumber();
    }
};

GUIClient.prototype.drawGame = function () {
    if (this.drawing) this.game.draw();
};

GUIClient.prototype.updateSubjectID = function (id) {
    this.updateTab (this.name, id);
};

GUIClient.prototype.shutdownGUI = function () {
    delTab(this.name);
    activateTab('server');
};

function globalErrorHandler(message, source, lineno, colno, error) {
    logMsg('server', message, 'error');
}

function addConfigToGUI(gui, name, config) {
    var folder = gui.addFolder(name);
    folder.add(config, 'game_type');
    folder.add(config, 'screen_width');
    folder.add(config, 'screen_height');
    folder.add(config, 'game_time');
    folder.add(config, 'auto_turn');

    var points = folder.addFolder('Points');
    points.add(config, 'destroy_fortress');
    points.add(config, 'ship_death_penalty');
    points.add(config, 'missile_penalty');
    points.add(config, 'max_points');
    points.add(config, 'max_bonus');

    var fortress = folder.addFolder('Fortress');

    fortress.add(config.fortress, 'sectorSize');
    fortress.add(config.fortress, 'lockTime');
    fortress.add(config.fortress, 'vlnerTime');
    fortress.add(config.fortress, 'vlnerThreshold');
    fortress.add(config.fortress, 'collisionRadius');
    fortress.add(config.fortress, 'explodeDuration');

    var hex = folder.addFolder('Hexagons');

    hex.add(config, 'bigHex');
    hex.add(config, 'smallHex');

    var ship = folder.addFolder('Ship');
    ship.add(config.ship, 'turnSpeed');
    ship.add(config.ship, 'acceleration');
    ship.add(config.ship, 'collisionRadius');
    ship.add(config.ship, 'explodeDuration');
    ship.add(config.ship, 'startAngle');
    var pos = ship.addFolder('StartPosition');
    pos.add(config.ship.startPosition, 'x');
    pos.add(config.ship.startPosition, 'y');
    var vel = ship.addFolder('StartVelocity');
    vel.add(config.ship.startVelocity, 'x');
    vel.add(config.ship.startVelocity, 'y');

    var shell = folder.addFolder('Shells');
    shell.add(config.shells, 'speed');
    shell.add(config.shells, 'collisionRadius');

    var missiles = folder.addFolder('Missiles');
    missiles.add(config.missiles, 'speed');
    missiles.add(config.missiles, 'collisionRadius');

    var staircase = folder.addFolder('Staircase');
    staircase.add(config.staircase, 'enabled');
    staircase.add(config.staircase, 'hexContraction');
    staircase.add(config.staircase, 'hexExpansion');
    staircase.add(config.staircase, 'minHexDistance');
    staircase.add(config.staircase, 'fortressPointsPerContraction');

    var nav = folder.addFolder('Navigation');
    // nav.add(config.nav, 'staircase');
    // nav.add(config.nav, 'staircase_delta');
    // nav.add(config.nav, 'staircase_decrease_threshold');
    // nav.add(config.nav, 'staircase_increase_threshold');
    nav.add(config.nav, 'rect_width');
    nav.add(config.nav, 'enter_rectangle');
    nav.add(config.nav, 'min_angle');
    nav.add(config.nav, 'max_angle');
    nav.add(config.nav, 'min_rect_width');

    var flappy = folder.addFolder('Flappy');
    flappy.add(config, 'flappy');
    flappy.add(config, 'flappy_nest');
    flappy.add(config, 'flappy_eggs');

    return folder;
};

function addAutoOrbitConfig(folder, config) {
    var orbit = folder.addFolder('Orbit');
    orbit.add(config, 'speedMultiplier');
    orbit.add(config.orbit, 'enabled');
    orbit.add(config.orbit, 'radius');
    orbit.add(config.orbit, 'noFirePenaltyThreshold');
    orbit.add(config.orbit, 'noFireBleedRate');
    orbit.add(config.orbit, 'speed');
    orbit.add(config.orbit, 'minRotation');
    orbit.add(config.orbit, 'maxRotation');
    orbit.add(config.orbit, 'distractionBuffer');
}

function addConfigEditor() {
    dat.GUI.TEXT_OPEN = 'Open Configs';
    dat.GUI.TEXT_CLOSED = 'Close Configs';
    g_gui = new dat.GUI();

    var autoturn = addConfigToGUI(g_gui, 'Autoturn', g_configs.autoturn.config);
    var youturn = addConfigToGUI(g_gui, 'Youturn', g_configs.youturn.config);
    var flappy_autoturn = addConfigToGUI(g_gui, 'FlappyAutoturn', g_configs.flappy_autoturn.config);
    var flappy_youturn = addConfigToGUI(g_gui, 'FlappyYouturn', g_configs.flappy_youturn.config);
    var nav = addConfigToGUI(g_gui, 'Navigation', g_configs.nav.config);

    var spacetrack_v6_stop = addConfigToGUI(g_gui, 'Spacetrack V6 Stop', g_configs.spacetrack_v6_stop.config);
    var spacetrack_v6_nostop = addConfigToGUI(g_gui, 'Spacetrack V6 No Stop', g_configs.spacetrack_v6_nostop.config);

    var staircase = addConfigToGUI(g_gui, 'Staircase', g_configs.staircase.config);

    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Baseline', g_configs.autoorbit_baseline.config), g_configs.autoorbit_baseline.config);
    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Speed', g_configs.autoorbit_speed.config), g_configs.autoorbit_speed.config);
    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Interval', g_configs.autoorbit_interval.config), g_configs.autoorbit_interval.config);

    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Slow', g_configs.autoorbit_slow.config), g_configs.autoorbit_slow.config);
    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Medium', g_configs.autoorbit_medium.config), g_configs.autoorbit_medium.config);
    addAutoOrbitConfig(addConfigToGUI(g_gui, 'Autoorbit_Fast', g_configs.autoorbit_fast.config), g_configs.autoorbit_fast.config);

    // var nosemantics = g_gui.addFolder('NoSemantics');

    g_gui.close();
}

function addUserSettings(name, defaultVal) {
    var elt = document.getElementById(name);
    if (!settings.has(name)) {
        settings.set(name, defaultVal);
    }
    elt.value = settings.get(name);
    elt.addEventListener('change', function () {
        // console.log(name + ' changed to', c.value);
        settings.set(name, elt.value);
    });

}

function setupUserSettings() {
    var dd = document.getElementById('data-dir');
    if (!settings.has('datadir')) {
        settings.set('datadir', path.join(app.getPath('userData'), 'data').toString());
    }
    dd.innerHTML = path.join(settings.get('datadir'),'/').toString();
    document.getElementById('change').addEventListener('click', function () {
        dialog.showOpenDialog({properties: ['openDirectory', 'createDirectory']},
                              function (things) {
                                  settings.set('datadir', things[0]);
                                  dd.innerHTML = path.join(things[0],'/').toString();
                              });
    });

    addUserSettings('condition', 'autoturn');
    addUserSettings('logFormat', 'native');
}

var gHumanClient;
function startHumanGame() {
    gHumanClient = new lbc.LoopbackClient();
}

setupUserSettings();
addConfigEditor();

addTab('server');
activateTab('server');
document.getElementById('server-tab-area').innerHTML = '<div class="title">Server</div><p><button id="humangame">Start Human Game</button><pre id="server-log"></pre>';

document.getElementById('humangame').addEventListener('click', startHumanGame);

loadImages();

window.onerror = globalErrorHandler;

server.startServer (logMsg, function (sock, id, opts) {
    var c = new GUIClient (sock, id, opts);
    c.createTab();
    return c;
}, {});

var sprintf = require('sprintf-js').sprintf;
var path = require('path');
var fs = require('fs');

function fmtint(x) {
    return x.toString();
}

function fmtbool(x) {
    return x ? 'y':'n';
}

function fmtfloat3(x) {
    return sprintf("%.3f", x);
}

function fmtfloat1(x) {
    return sprintf("%.1f", x);
}

function fmtprojectiles(p) {
    var ret = '[';
    for( let i=0; i<p.length; i++) {
        ret += [fmtfloat3(p[i].x),
                fmtfloat3(p[i].y),
                fmtfloat1(p[i].orientation)].join(' ');
        ret += ' ';
    }
    ret += ']';
    return ret;
}

var SpaceFortressLogFunctions = {
    closeLogFiles: function () {
    },

    openLogFiles: function () {
        // Close existing streams, if necessary
        if (this.gameLogFileStream) this.gameLogFileStream.end();
        if (this.eventLogFileStream) this.eventLogFileStream.end();
        if (this.keyLogFileStream) this.keyLogFileStream.end();

        var datdir = path.join(this.datadir, this.id);
        this.gameLogFileName = path.join(this.datadir, this.id, this.id + '-1-' + this.gameNum.toString() + '.dat');
        this.eventLogFileName = path.join(this.datadir, this.id, this.id + '-1-' + this.gameNum.toString() + '.evt');
        this.keyLogFileName = path.join(this.datadir, this.id, this.id + '-1-' + this.gameNum.toString() + '.key');
        // Create the folders if necessary.
        try { fs.mkdirSync(this.datadir); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }
        try { fs.mkdirSync(datdir); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }
        // Create stream handles
        this.gameLogFileStream = fs.createWriteStream (this.gameLogFileName);
        this.eventLogFileStream = fs.createWriteStream (this.eventLogFileName);
        this.keyLogFileStream = fs.createWriteStream (this.keyLogFileName);
    },
    gameLogHeader: function (state) {
        this.gameLogFileStream.write("# log version 1.6\n");
        this.gameLogFileStream.write("# created with node.js sf server\n");
        this.gameLogFileStream.write("# non-hashed line notation:\n");
        this.gameLogFileStream.write("# game_clock system_clock game_time ship_alive? ship_x ship_y ship_vel_x ship_vel_y ship_orientation mine_alive? mine_x mine_y fortress_alive? fortress_orientation [missile_x missile_y missile_orientation ...] [shell_x shell_y shell_orientation ...] bonus_symbol pnts cntrl vlcty vlner iff intervl speed shots thrust_key left_key right_key fire_key iff_key shots_key pnts_key game_active\n");
        this.gameLogFileStream.write("# hexagonSizes: " + state.bighex.toString() + ' ' + state.smallhex.toString() + '\n');
        var e = JSON.stringify(this.headerExtra);
        if (e.length > 2)
            this.gameLogFileStream.write("# Extra: " + e + '\n');
    },
    gameLog: function (state) {
        var missiles = fmtprojectiles (state.missiles);
        var shells = fmtprojectiles (state.shells);

        this.gameLogFileStream.write([fmtint(state.time),
                                      '0.000000',
                                      fmtint(state.time),
                                      fmtbool(state.ship.alive),
                                      fmtfloat3(state.ship.x),
                                      fmtfloat3(state.ship.y),
                                      state.ship.alive ? fmtfloat3(state.ship.vx):'-',
                                      state.ship.alive ? fmtfloat3(state.ship.vy):'-',
                                      state.ship.alive ? fmtfloat1(state.ship.orientation):'-',
                                      'n', '-', '-',
                                      fmtbool(state.fortress.alive),
                                      state.fortress.alive ? fmtfloat1(state.fortress.orientation):'-',
                                      missiles,
                                      shells,
                                      '-',
                                      fmtint(state.pnts),
                                      fmtint(0), fmtint(0),
                                      fmtint(state.vlner),
                                      '-', fmtint(0), fmtint(0), 'inf',
                                      fmtbool(state.keys.indexOf('thrust') != -1),
                                      fmtbool(state.keys.indexOf('left') != -1),
                                      fmtbool(state.keys.indexOf('right') != -1),
                                      fmtbool(state.keys.indexOf('fire') != -1),
                                      fmtbool(false),
                                      fmtbool(false),
                                      fmtbool(false),
                                      fmtbool(true)].join(' ') + '\n');

        this.eventLogFileStream.write([fmtint(state.time),
                                       '0.000000',
                                       state.events.join(',')].join(' ') + '\n');

        var keys = [];
        for( let i=0; i<state.events.length; i++) {
            var m = state.events[i].match(/(hold|release)-(thrust|left|right|fire)/);
            if( m ) {
                var code = m[1] === 'release' ? 3:2;
                var key = this.keyLookupTable[m[2]];
                keys.push([code, key, 0]);
            }
        }
        this.keyLogFileStream.write(JSON.stringify([33, keys]) + '\n');
    },

    gameLogFooter: function (gnum, score) {
        this.gameLogFileStream.write("# pnts score " + score.points.toString() + '\n');
        this.gameLogFileStream.write("# total score " + score.points.toString() + '\n');
        this.gameLogFileStream.write("# raw pnts " + score.rawpnts.toString() + '\n');
        this.gameLogFileStream.write("# bonus earned " + this.formatDollars(score.bonus) + '\n');
    },

    // Forward compatibility with new log fuctions
    lgStartScreen: function (state) { this.gameLogHeader(state); },
    lg: function (tag, state) { if (tag === undefined) this.gameLog(state); },
    lgEndScreen: function (state) { this.gameLogFooter(undefined, state); },
};

var NavLogFunctions = {
    closeLogFiles: function () {
    },

    openLogFiles: function () {
        // Close existing streams, if necessary
        if (this.gameLogFileStream) this.gameLogFileStream.end();

        var datdir = path.join(this.datadir, this.id);
        this.gameLogFileName = path.join(this.datadir, this.id, this.id + '.1.' + this.gameNum.toString() + '.log');
        // Create the folders if necessary.
        try { fs.mkdirSync(this.datadir); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }
        try { fs.mkdirSync(datdir); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }
        // Create stream handles
        this.gameLogFileStream = fs.createWriteStream (this.gameLogFileName);
    },
    gameLogHeader: function (state) {
        var s = JSON.stringify(state);
        s = s.substring(0,s.length-1);
        var e = JSON.stringify(this.headerExtra);
        e = e.substring(1);

        if (e.length > 1)
            this.gameLogFileStream.write('[' + s + ',' + e + ',\n');
        else
            this.gameLogFileStream.write('[' + s + e + ',\n');
    },
    gameLog: function (state) {
        this.gameLogFileStream.write(JSON.stringify(state) + ',\n');
        // this.gameExtra = {};
    },
    gameLogFooter: function (gnum, state) {
        this.gameLogFileStream.write(JSON.stringify(state) + ']\n');
    },

    // Forward compatibility with new log fuctions
    lgStartScreen: function (state) { this.gameLogHeader(state); },
    lg: function (tag, state) { if (tag === undefined) this.gameLog(state.s); },
    lgEndScreen: function (state) { this.gameLogFooter(undefined, state); },
};

var JSONLogFunctions = {
    closeLogFiles: function () {
        if (this.logFileStream) {
            this.logFileStream.write((this.firstScreenElem ? '':']}\n')+
                                     ']}\n' +
                                     ']\n');
            this.logFileStream.close();
            this.logFileStream = undefined;
        }
    },

    openLogFiles: function () {
        if (this.logFileStream) return;

        var filename = path.join(this.datadir, this.id + '.log');

        // Create the folders if necessary.
        try { fs.mkdirSync(this.datadir); }
        catch (e) { if (e.code !== 'EEXIST') throw e; }

        this.logFileStream = fs.createWriteStream(filename);
        this.firstScreenElem = true;

        var keys = {"model-server": true,
                    "worker-id": this.id,
                    "date": new Date().toString()};
        var s = JSON.stringify(keys);
        this.logFileStream.write('[\n{' + s.slice(1,s.length-1) + ',"body":[\n');
    },

    lgStartScreen: function (state) {
        var s = JSON.stringify(state);
        s = s.substring(1,s.length-1);
        var e = JSON.stringify(this.headerExtra);
        var comma = '';
        e = e.substring(1,e.length-1);
        if (e.length > 0) comma = ','

        this.logFileStream.write((this.firstScreenElem ? '':']},\n')+
                                 '{"screen":"'+this.screen_id+'","ts":0'+','+
                                 s + comma + e + ',"body":[\n');

        this.firstScreenElem = false;
        this.firstBodyElem = true;
    },
    lgEndScreen: function(state) {
        var s = JSON.stringify(state);
        var comma = s.length > 0 ? ',':'';
        this.logFileStream.write((this.firstBodyElem ? '':',\n')+
                                 '  {"ts":0,"tag":"end"' + comma + s.slice(1));
    },
    lg: function(tag, state) {
        var s = JSON.stringify(state);
        var comma = s.length > 0 ? ',':'';
        if (tag === undefined) {
            this.logFileStream.write((this.firstBodyElem ? '':',\n')+
                                     '  {"ts":0,"tag":"f"'+ comma + s.slice(1));
        } else {
            this.logFileStream.write((this.firstBodyElem ? '':',\n')+
                                     '  {"ts":0,"tag":"'+tag+'"'+ comma + s.slice(1));
        }
        this.firstBodyElem = false;
    },

    gameLogHeader: function (state) { this.lgStartScreen(state); },
    gameLog: function (state) { this.lg(undefined, {s:state}); },
    gameLogFooter: function (gnum, state) { this.lgEndScreen(state); }
};

function Experiment(datadir) {
    this.id = "default";
    this.gameNum = 1;
    this.datadir = datadir;
    this.com = {sendGameData: function () {}};
    this.bonus = 0;
    this.gameScores = [];
    this.headerExtra = {};
    this.gameExtra = {};

    this.keyLookupTable = {fire: 32,
                           left: 97,
                           right: 100,
                           thrust: 119};
}

Experiment.prototype = {};

Experiment.prototype.setLogFormat = function (val) {
    this.logType = val;
    if (val == 'sf') {
        this.closeLogFiles = SpaceFortressLogFunctions.closeLogFiles;
        this.openLogFiles = SpaceFortressLogFunctions.openLogFiles;
        this.gameLogHeader = SpaceFortressLogFunctions.gameLogHeader;
        this.gameLog = SpaceFortressLogFunctions.gameLog;
        this.gameLogFooter = SpaceFortressLogFunctions.gameLogFooter;

        this.lgStartScreen = SpaceFortresLogFunctions.lgStartScreen;
        this.lgEndScreen = SpaceFortresLogFunctions.lgEndScreen;
        this.lg = SpaceFortresLogFunctions.lg;
    } else if (val == 'nav') {
        this.closeLogFiles = NavLogFunctions.closeLogFiles;
        this.openLogFiles = NavLogFunctions.openLogFiles;
        this.gameLogHeader = NavLogFunctions.gameLogHeader;
        this.gameLog = NavLogFunctions.gameLog;
        this.gameLogFooter = NavLogFunctions.gameLogFooter;

        this.lgStartScreen = NavLogFunctions.lgStartScreen;
        this.lgEndScreen = NavLogFunctions.lgEndScreen;
        this.lg = NavLogFunctions.lg;
    } else if (val == 'json') {
        this.closeLogFiles = JSONLogFunctions.closeLogFiles;
        this.openLogFiles = JSONLogFunctions.openLogFiles;
        this.gameLogHeader = JSONLogFunctions.gameLogHeader;
        this.gameLog = JSONLogFunctions.gameLog;
        this.gameLogFooter = JSONLogFunctions.gameLogFooter;

        this.lgStartScreen = JSONLogFunctions.lgStartScreen;
        this.lgEndScreen = JSONLogFunctions.lgEndScreen;
        this.lg = JSONLogFunctions.lg;
    }
};

Experiment.prototype.addReward = function (amt) {
    this.bonus += amt;
};

Experiment.prototype.formatDollars = function (amt) {
    var dollars = Math.floor(amt / 100);
    var cents = Math.floor(amt % 100);
    return '$' + dollars + '.' + (cents < 10 ? '0' + cents : cents);
};

Experiment.prototype.resetGameData = function (gnum) {
    this.gameNum = gnum;
    this.openLogFiles();
};

Experiment.prototype.lg = function () {
};

exports.Experiment = Experiment;

const net = require('net');

function LoopbackClient() {
    this.socket = net.createConnection(3000, 'localhost');
    this.socket.setEncoding('utf8');
    this.socket.on('connect', LoopbackClient.prototype.onConnect.bind(this));
    this.socket.on('data', LoopbackClient.prototype.onData.bind(this));
    this.socket.on('end', LoopbackClient.prototype.onEnd.bind(this));
    this.socket.on ('error', (err) => {
        console.log('socket error', err);
        this.onEnd();
    });
    this.inGame = false;
    this.lastUpdate = null;
}

LoopbackClient.prototype = {};

LoopbackClient.prototype.close = function () {
    this.socket.end();
    this.inGame = false;
};

LoopbackClient.prototype.onConnect = function () {
    document.addEventListener('keydown', this);
    document.addEventListener('keyup', this);
};

LoopbackClient.prototype.onData = function (data) {
    if (data.match(/:screen-type "config"/)) {
        this.socket.write('continue\n');
    } else if (data.match(/:screen-type "game"/)) {
        this.inGame = true;
        var ts = parseInt(data.match(/:time (\d+)/)[1]);
        var now = new Date().getTime();
        if (this.lastUpdate) {
            var ts_diff = ts - this.lastTs;
            var diff = now - this.lastUpdate;
            var compensation = diff - this.ms;
            this.ms = ts_diff - compensation;
            if (this.ms < 0) this.ms = 0;
        } else {
            // We don't know the framerate yet.
            this.ms = 0;
        }
        this.lastTs = ts;
        this.lastUpdate = now;
        this.updateid = setTimeout(this.step.bind(this), this.ms);
    } else if (data.match(/:screen-type "score"/)) {
        console.log('got score');
        this.inGame = false;
        this.lastUpdate = null;
    } else {
        console.log('data', data);
    }
};

LoopbackClient.prototype.step = function () {
    this.socket.write('continue\n');
}

LoopbackClient.prototype.onEnd = function () {
    document.removeEventListener('keydown', this);
    document.removeEventListener('keyup', this);
    clearTimeout(this.updateid);
};


LoopbackClient.prototype.keycode2name = function (ev) {
    if (ev.which == 32) {
        return 'fire';
    } else if (ev.which == 76) {
        // autoorbit uses L for fire
        return 'fire';
    } else if (ev.which == 65) {
        return 'left';
    } else if (ev.which == 68) { // 69) {
        return 'right';
    } else if (ev.which == 87) { // 188) {
        return 'thrust';
        // } else if (ev.which == 81) {
        //     return 'quit';
    } else if (ev.which == 27) {
        return 'quit';
    } else if (ev.which == 13) {
        return 'continue';
    } else {
        return null;
    }
}

LoopbackClient.prototype.handleEvent = function (ev) {
    if (ev.type === 'keydown') this.onKeyDown(ev);
    else if (ev.type === 'keyup') this.onKeyUp(ev);
};

LoopbackClient.prototype.onKeyDown = function (ev) {
    var sym = this.keycode2name(ev);
    if (this.inGame) {
        if (sym === 'quit') {
            this.socket.write('quit\n');
            ev.preventDefault();
        } else if (sym === 'continue') {
            ev.preventDefault();
        } else if (sym) {
            this.socket.write('keydown '+sym+'\n');
            ev.preventDefault();
        }
    } else {
        if (sym) ev.preventDefault();
        if (sym === 'quit') {
            this.socket.write('quit\n');
        } else if (sym === 'continue') {
            this.socket.write('continue\n');
        }
    }
};

LoopbackClient.prototype.onKeyUp = function (ev) {
    if (this.inGame) {
        var sym = this.keycode2name(ev);
        if (sym === 'quit' || sym === 'continue') {
            ev.preventDefault();
        } else if (sym) {
            this.socket.write('keyup '+sym+'\n');
            ev.preventDefault();
        }
    }
};

exports.LoopbackClient = LoopbackClient;


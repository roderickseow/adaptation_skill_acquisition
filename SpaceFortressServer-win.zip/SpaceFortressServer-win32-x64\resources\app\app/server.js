const net = require('net');

Experiment = require("./experiment").Experiment;

var Game = require('./shared/game').Game;
var Nav = require('./shared/nav').Nav;
var SpacetrackV6 = require('./shared/spacetrack-v6-nav').Nav;
var Autoorbitv2 = require('./shared/autoorbitv2').Game;
var Autoorbitv3 = require('./shared/autoorbitv3').Game;
var config = require('./shared/config');
var MersenneTwister = require('mersenne-twister');

var defaultKeyMapping = {'thrust': 'thrust',
                         '119': 'thrust',
                         'fire': 'fire',
                         '32': 'fire',
                         'left': 'left',
                         '97': 'left',
                         'right': 'right',
                         '100': 'right'};

var spacetrackV6KeyMapping = {'thrust': 'thrust',
                              '119': 'thrust',
                              'flip': 'flip',
                              'fire': 'flip',
                              '32': 'flip',
                              'left': 'left',
                              '97': 'left',
                              'right': 'right',
                              '100': 'right'};

var allConfigs = {autoturn: {config: new config.AutoturnConfig(),
                             defaultLogFormat: 'sf',
                             validLogFormats: ['sf', 'flappy', 'json'],
                             game: Game},
                  staircase: {config: new config.StaircaseConfig(),
                              defaultLogFormat: 'sf',
                              validLogFormats: ['sf', 'flappy', 'json'],
                              game: Game},
                  flappy_autoturn: {config: new config.FlappyAutoturnConfig(),
                                    defaultLogFormat: 'sf',
                                    validLogFormats: ['sf', 'flappy', 'json'],
                                    game: Game},
                  youturn: {config: new config.YouturnConfig(),
                            defaultLogFormat: 'sf',
                            validLogFormats: ['sf', 'flappy', 'json'],
                            game: Game},
                  flappy_youturn: {config: new config.FlappyYouturnConfig(),
                                   defaultLogFormat: 'sf',
                                   validLogFormats: ['sf', 'flappy', 'json'],
                                   game: Game},
                  nav: {config: new config.NavConfig(),
                        defaultLogFormat: 'nav',
                        validLogFormats: ['nav', 'json'],
                        game: Nav},
                  spacetrack_v6_stop: {config: new config.SpacetrackV6StopConfig(),
                                       defaultLogFormat: 'json',
                                       validLogFormats: ['nav', 'json'],
                                       keyMapping: spacetrackV6KeyMapping,
                                       game: SpacetrackV6},
                  spacetrack_v6_nostop: {config: new config.SpacetrackV6NoStopConfig(),
                                         defaultLogFormat: 'nav',
                                         validLogFormats: ['nav', 'json'],
                                         keyMapping: spacetrackV6KeyMapping,
                                         game: SpacetrackV6},
                  autoorbit_baseline: {config: new config.AutoOrbitBaseLineConfig(),
                                       defaultLogFormat: 'sf',
                                       validLogFormats: ['sf', 'json'],
                                       game: Autoorbitv2},
                  autoorbit_speed: {config: new config.AutoOrbitSpeedConfig(),
                                    defaultLogFormat: 'sf',
                                    validLogFormats: ['sf', 'json'],
                                    game: Autoorbitv2},
                  autoorbit_interval: {config: new config.AutoOrbitIntervalConfig(),
                                       defaultLogFormat: 'sf',
                                       validLogFormats: ['sf', 'json'],
                                       game: Autoorbitv2},
                  autoorbit_slow: {config: new config.AutoOrbitSlowConfig(),
                                   defaultLogFormat: 'sf',
                                   validLogFormats: ['sf', 'json'],
                                   game: Autoorbitv3},
                  autoorbit_medium: {config: new config.AutoOrbitMediumConfig(),
                                     defaultLogFormat: 'sf',
                                     validLogFormats: ['sf', 'json'],
                                     game: Autoorbitv3},
                  autoorbit_fast: {config: new config.AutoOrbitFastConfig(),
                                   defaultLogFormat: 'sf',
                                   validLogFormats: ['sf', 'json'],
                                   game: Autoorbitv3}};

var defaultHost = '';
var defaultPort = 3000;

function json2sexp(json) {
    if (Array.isArray(json)) {
        var ret = '(';
        for (var i=0; i<json.length; i++) {
            if (i>=1) ret += ' ';
            ret += json2sexp(json[i]);
        }
        return ret + ')';
    } else if (typeof json == 'object') {
        var ret = '(';
        var first = true;
        for (var k in json) {
            if (json.hasOwnProperty(k)) {
                if (first) first = false;
                else ret += ' ';
                ret += ':' + k.toString();
                ret += ' ' + json2sexp(json[k]);
            }
        }
        return ret + ')';
    } else if (typeof json === 'string') {
        // special case for keyword symbols
        if (json[0] === ':')
            return json;
        else
            return '"' + json + '"';
    } else if (json === Infinity) {
        return 'inf';
    } else if (json === true) {
        return 'T';
    } else if (json === false) {
        return 'NIL';
    } else if (json === null) {
        console.log('null');
        return 'NIL';
    } else {
        return json.toString();
    }
}

function Client (socket, name, opts) {
    this.sock = socket;
    this.name = name;
    this.lineEnding = opts.lineEnding || '\r\n';
    this.mode = 'config';
    this.commands = [];
    this.logFormat = opts.logFormat || 'native';
    this.exp = new Experiment(opts.dataPath);
    this.configs = allConfigs;
    if (typeof this.configs[opts.condition] === 'undefined') {
        this.condition = 'youturn';
    } else {
        this.condition = opts.condition;
    }
    if (!Client.prototype.isValidLogFormat.call(this))
        this.logFormat = 'native';
    // Allow overriding options without altering original
    this.config = JSON.parse(JSON.stringify(this.configs[this.condition].config));
    this.gnum = 1;
    this.seed = new Date().getTime();
    this.drawing = true;
}

Client.prototype = {
    // GUI version must implement these functions
    logMsg: function (dest, msg) { console.log(dest, msg); },
    drawingChanged: function () { },
    initGameCanvas: function () { },
    drawScoreScreen: function () { },
    drawGame: function () { },
    updateSubjectID: function (id) { },
    shutdownGUI: function () { },

    getConfigScreen: function () {
        return {'screen-type': 'config',
                id: this.name,
                logFormat: this.logFormat,
                condition: this.condition,
                gnum: this.gnum,
                seed: this.seed};
    },

    isValidLogFormat: function (condition, fmt) {
        return fmt === 'native' || this.configs[condition||this.condition].validLogFormats.indexOf(fmt||this.logFormat) >= 0;
    },

    greet: function () {
        this.logMsg ('server', 'new connection from ' + this.sock.remoteAddress + ':' + this.sock.remotePort);
        this.logMsg (this.name, 'Config');

        this.sock.write(json2sexp(this.getConfigScreen()) + this.lineEnding);
    },

    parseData: function (data) {
        // console.log ('data: ' + data);
        var lines = data.split(/[\n\r]+/);
        // console.log('lines', lines);
        for(var i=0; i<lines.length; i++) {
            lines[i] = lines[i].trim();
            if (lines[i].length > 0) this.commands.push(lines[i]);
        }
    },

    decodeKey: function (str) {
        var mapping;
        if ('keyMapping' in this.configs[this.condition])
            mapping = this.configs[this.condition].keyMapping;
        else
            mapping = defaultKeyMapping;
        if (str in mapping) return mapping[str];
        else return null;
    },

    setDrawing: function(val) {
        if (val === '0') {
            this.drawing = false;
        } else {
            this.drawing = true;
        }
        if (this.mode === 'game') this.drawingChanged();
    },

    sendWorldState: function () {
        this.sock.write (json2sexp(this.game.getWorldStateForModel(Math.floor(this.clock+1000/this.game.config.fps))) + this.lineEnding);
    },

    startGame: function () {
        this.mode = 'game';
        this.clock = 0;
        // console.log(this.configs[this.condition]);

        var fmt = this.logFormat;
        if (fmt === 'native' || this.configs[this.condition].validLogFormats.indexOf(fmt) < 0)
            fmt = this.configs[this.condition].defaultLogFormat;
        this.exp.setLogFormat(fmt);
        this.game = new this.configs[this.condition].game(this.exp, this.config, this.gnum);
        this.exp.screen_id = this.game.screen_id;
        this.game.logFormat = fmt;
        this.initGameCanvas();
        this.game.coreInit();
        this.drawGame();
        this.sendWorldState();
        this.logMsg (this.name, 'Start Game ' + this.gnum.toString());
    },

    getScoreScreen: function () {
        return {'screen-type': 'score',
                total: this.game.score.pnts,
                bonus: this.game.bonus,
                'total-bonus': 0,
                'raw-pnts': this.game.score.raw_pnts,
                id: this.name,
                logFormat: this.logFormat,
                condition: this.condition,
                gnum: this.gnum,
                seed: this.seed,
               };
    },

    seedRNG: function () {
        // Use a seedable pRNG
        var m = new MersenneTwister(this.seed);
        Math.random = m.random.bind(m);
    },

    handleConfigCommand: function (data, responsefn, continuefn) {
        var line = data.split(' ');
        var cmd = line[0];
        var error = null;
        if (cmd === 'id') {
            if (line.length >= 2) {
                this.updateSubjectID(line[1]);
                this.name = line[1];
            }
            else error = cmd + ': needs one argument';
        } else if (cmd === 'condition') {
            if (line.length >= 2) {
                if (line[1] in this.configs) {
                    this.condition = line[1];
                    this.config = JSON.parse(JSON.stringify(this.configs[this.condition].config));
                    if (!this.isValidLogFormat())
                        this.logFormat = 'native';
                } else {
                    error = cmd + ': unknown condition ' + line[1];
                }
            } else {
                error = cmd + ': needs one argument';
            }
        } else if (cmd === 'quit') {
            this.shutdown('client has quit.');
            return;
        } else if (cmd === 'drawing') {
            if (line.length >= 2) this.setDrawing(line[1]);
        } else if (cmd === 'continue') {
            if (continuefn) continuefn();
            this.seedRNG();
            this.mode = 'game';
            this.exp.id = this.name;
            this.startGame();
            return;
        } else if (cmd === 'logformat') {
            if (line.length < 2) {
                error = cmd + ': needs one argument';
            } else if (!this.isValidLogFormat(this.condition, line[1])) {
                error = cmd + ': invalid log format ' + line[1];
            } else {
                this.logFormat = line[1];
            }
        } else if (cmd === 'config') {
            if (line.length >= 3) {
                var keys = line[1].split('.');
                var val;
                try { val = JSON.parse(line[2]); } catch (e) { }
                if (val === undefined) {
                    error = 'config: cannot parse JSON config value ' + line[2];
                } else if (line[1] === 'display_level') {
                    this.setDrawing(val);
                } else {
                    var obj = this.config;
                    for (let i=0; i<keys.length-1; i++) {
                        if (keys[i] in obj) {
                            obj = obj[keys[i]];
                        } else {
                            error = 'config: unknown setting config.' + keys.join('.');
                            break;
                        }
                    }
                    if (!error && keys[keys.length-1] in obj) {
                        obj[keys[keys.length-1]] = val;
                    } else {
                        error = 'config: unknown setting config.' + keys.join('.');
                    }
                }
            } else {
                error = 'config: needs 2 arguments';
            }
        } else if (cmd === 'gnum') {
            if (line.length >= 2) {
                this.gnum = parseInt(line[1]);
                if (this.gnum < 1) this.gnum = 1;
            } else {
                error = cmd + ': needs one argument';
            }
        } else if (cmd === 'seed') {
            if (line.length >= 2) {
                this.seed = parseInt(line[1]);
            } else {
                error = cmd + ': needs one argument';
            }
        } else if (cmd === 'extra') {
            if (line.length >= 2) {
                var val;
                try { val = JSON.parse(line[2]); } catch (e) { }
                if (val === undefined) {
                    error = cmd + ':cannot parse JSON value ' + line[2];
                } else {
                    this.exp.headerExtra[line[1]] = val;
                }
            } else {
                error = cmd + ': needs 2 arguments';
            }
        } else {
            error = 'unknown command: ' + cmd;
        }

        if (responsefn) { responsefn(error); }
    },

    endGame: function () {
        this.logMsg (this.name, 'Game Score ' + this.gnum.toString());
        this.mode = 'score';
        this.exp.headerExtra = {};
        this.seed = Math.floor(Math.random()*4294967296.0);
        this.gnum += 1;
        this.game.cleanup();
        this.drawScoreScreen();
        this.sock.write(json2sexp(this.getScoreScreen()) + this.lineEnding);
    },

    handleCommand: function (data) {
        // console.log('cmd', data);
        if (this.mode === 'config') {
            this.handleConfigCommand(data, (error) => {
                var c = this.getConfigScreen();
                c.result = error === null;
                c.error = error;
                this.sock.write(json2sexp(c) + this.lineEnding);
            },
                                     () => { this.logMsg ('server', this.name + ' is starting'); });
        } else if (this.mode === 'game') {
            var line = data.split(' ');
            var cmd = line[0];
            if (cmd === 'quit') {
                this.shutdown('client has quit.');
                return;
            } else if (cmd === 'drawing') {
                if (line.length >= 2) this.setDrawing(line[1]);
            } else if (cmd.toUpperCase() === 'KEYDOWN') {
                if (line.length >= 2) {
                    var k = this.decodeKey(line[1]);
                    if (k) this.game.keyState.press(k);
                }
            } else if (cmd.toUpperCase() === 'KEYUP') {
                if (line.length >= 2) {
                    var k = this.decodeKey(line[1]);
                    if (k) this.game.keyState.release(k);
                }
            } else if (cmd === 'extra') {
                if (line.length >= 2) {
                    var val;
                    try { val = JSON.parse(line[2]); } catch (e) { }
                    if (val === undefined) {
                        error = cmd + ':cannot parse JSON value ' + line[2];
                    } else {
                        this.exp.gameExtra[line[1]] = val;
                    }
                } else {
                    error = cmd + ': needs 2 arguments';
                }
            } else if (cmd === 'abort') {
                this.endGame();
            } else if (cmd === 'continue') {
                var last_clock = Math.floor(this.clock);
                this.clock += 1000/this.game.config.fps;
                // console.log(this.clock, Math.floor(this.clock) - last_clock);
                this.game.step_one_tick(Math.floor(this.clock) - last_clock);
                this.drawGame();
                // sock.write (JSON.stringify(game.getWorldState()) + this.lineEnding);
                if (this.game.is_game_over()) {
                    this.endGame();
                } else {
                    // console.log(this.game.getWorldStateForModel());
                    this.sendWorldState();
                }
            } else {
                var s = this.game.getWorldStateForModel(Math.floor(this.clock + 1000/this.game.config.fps));
                s.result = false;
                s.error = 'unknown command: ' + cmd;
                this.sock.write(json2sexp(s) + this.lineEnding);
            }
        } else if (this.mode === 'score') {
            this.handleConfigCommand(data, (error) => {
                var c = this.getScoreScreen();
                c.result = error === null;
                c.error = error;
                this.sock.write(json2sexp(c) + this.lineEnding);
            });
        }
    },

    handleData: function (data) {
        this.parseData(data);
        for(var i=0; i<this.commands.length; i++) {
            this.handleCommand(this.commands[i]);
        }
        this.commands = [];
    },

    shutdown: function (msg) {
        if (!this.hasShutdown) {
            if (this.exp.closeLogFiles) this.exp.closeLogFiles();
            this.hasShutdown = true;
            this.sock.end();
            this.sock.destroy();
            this.logMsg('server', this.name + ': ' + msg);
            this.shutdownGUI();
        } else {
            console.log('ignore multiple shutdowns.');
        }
    },

    disconnect: function () {
        this.shutdown('client has disconnected.');
    }
};


var clientNum = 0;

function startServer (logFn, clientFn, opts) {
    var port = opts.port || defaultPort;
    net.createServer (function (sock) {
        sock.setEncoding('utf8');
        sock.setNoDelay(true);

        clientNum += 1;
        var client = clientFn(sock, 'model' + clientNum, {lineEnding: opts.lineEnding});
        client.greet();
        sock.on ('data', function (data) { client.handleData(data); });
        sock.on ('error', function (err) {
            if (err.errno === 'ECONNRESET') { }
            else { console.log('socket error', err); }
        });
        sock.on ('close', function () { client.disconnect(); });
    }).listen (port, defaultHost);
    logFn ('server', 'Listening on port ' + port);
}

exports.Client = Client;
exports.startServer = startServer;
exports.configs = allConfigs;
exports.json2sexp = json2sexp;
